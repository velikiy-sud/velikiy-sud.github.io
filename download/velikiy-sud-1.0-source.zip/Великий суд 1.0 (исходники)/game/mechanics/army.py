"""Армия: набор, учения, снабжение, доктрины, производство вооружений."""
from .common import Action, Item, TabView, bar, costly

DOCTRINES = {
    "mobile": {"name": "Мобильная война",
               "desc": "Танковые клинья и глубокие прорывы. +15% к силе, быстрее операции.",
               "mult": 1.15, "op_speed": 1.2},
    "firepower": {"name": "Превосходство огня",
                  "desc": "Артиллерия решает всё. +10% к силе, меньше потерь живой силы.",
                  "mult": 1.10, "losses": 0.7},
    "mass": {"name": "Массовое наступление",
             "desc": "Числом, а не умением. Живая сила важнее вооружения.",
             "mult": 1.0, "manpower_weight": 1.35},
}


def doctrine(state):
    return DOCTRINES.get(state.vars.get("army_doctrine"), {})


def strength(state):
    """Условная боевая мощь армии (сопоставима с state['enemy_army'])."""
    d = doctrine(state)
    base = state.get("manpower") / 2 * d.get("manpower_weight", 1.0)
    eq_w = 0.4 if d.get("manpower_weight") else 0.6
    eq = (1 - eq_w) + eq_w * state.get("equipment") / 100
    tr = 0.6 + 0.8 * state.get("training") / 100
    sup = 0.5 + 0.5 * state.get("supply") / 100
    mor = 0.7 + 0.6 * state.get("morale") / 100
    elite = 2.5 * state.vars.get("ss_divisions", 2) if state.side == "burgundy" else 0.0   # дивизии СС — отборные части
    return (base + elite) * eq * tr * sup * mor * d.get("mult", 1.0) * state.mod("army_strength")


def daily(game):
    st = game.state
    if st.programs.get("training"):
        st.add("training", 0.15)
        st.add("treasury", -1.0)
    else:
        st.add("training", -0.02)
    if st.programs.get("production"):
        st.add("equipment", 0.2)
        st.add("treasury", -2.0)
    # Подрастает новый призывной контингент
    st.add("manpower", 0.05)
    # Снабжение медленно деградирует без вложений
    st.add("supply", -0.02)
    # Боевой дух тянется к 50
    st.add("morale", (55 - st.get("morale")) * 0.003)


def _toggle(game, name, on_text, off_text):
    st = game.state

    def fn():
        st.programs[name] = not st.programs.get(name)
        st.log_msg(on_text if st.programs[name] else off_text)
    return fn


def view(game):
    st = game.state
    s = strength(game.state)
    d = doctrine(st)
    header = [
        (f"БОЕВАЯ МОЩЬ: {s:6.1f}   (оценка противника: {game.enemy_estimate()})", "bright"),
        ("", "normal"),
        (f"Живая сила   {st.get('manpower'):6.0f} тыс.", "normal"),
        (f"Выучка       {bar(st.get('training'))} {st.get('training'):5.1f}", "normal"),
        (f"Снабжение    {bar(st.get('supply'))} {st.get('supply'):5.1f}", "normal"),
        (f"Вооружение   {bar(st.get('equipment'))} {st.get('equipment'):5.1f}", "normal"),
        (f"Боевой дух   {bar(st.get('morale'))} {st.get('morale'):5.1f}", "normal"),
        (f"Доктрина     {d.get('name', '— не утверждена —')}", "normal"),
        ("", "normal"),
    ]
    items = []

    def recruit():
        st.add("manpower", 15)
        st.add("equipment", -4)
        st.add("stability", -1.5)
        st.vars["recruits"] = st.vars.get("recruits", 0) + 1
        st.log_msg("Объявлен дополнительный призыв: +15 тыс. человек.")
    rcost = 25 + 5 * st.vars.get("recruits", 0)
    items.append(Item("Призыв резервистов", [costly(st, "Объявить призыв", {"treasury": rcost}, recruit)],
                      ["+15 тыс. живой силы, но вооружения на всех не хватает",
                       "(-4 вооружения) и общество недовольно (-1.5 стабильности).",
                       "Каждый следующий призыв дороже."]))

    if st.side == "burgundy":
        total = st.vars.get("ss_divisions", 2)
        busy = sum(1 for t in st.territories.values() if t.get("op") and t["op"]["type"] == "military")

        def ss():
            st.vars["ss_divisions"] = st.vars.get("ss_divisions", 2) + 1
            st.add("manpower", -5)
            st.add("equipment", -3)
            st.log_msg(f"Сформирована новая дивизия СС (всего {st.vars['ss_divisions']}).")
        items.append(Item(f"Дивизии СС: {total} (в операциях {busy})",
                          [costly(st, "Сформировать дивизию СС", {"treasury": 45 + 10 * total}, ss)],
                          ["Земли Германии и рейхскомиссариаты берут только войска СС:",
                           "одна операция занимает одну дивизию. Каждая дивизия ускоряет штурмы.",
                           "Дивизии СС усиливают армию и в большой войне.",
                           "-5 тыс. живой силы, -3 вооружения, содержание 0.3 казны в день."]))

    on = st.programs.get("training")
    items.append(Item(f"Программа учений [{'ВКЛ' if on else 'выкл'}]",
                      [Action("Выключить учения" if on else "Начать учения",
                              _toggle(game, "training", "Начаты масштабные учения.", "Учения свёрнуты."))],
                      ["Ежедневно: +0.15 выучки, -1 казны."]))

    on = st.programs.get("production")
    items.append(Item(f"Военные заводы [{'ВКЛ' if on else 'выкл'}]",
                      [Action("Остановить производство" if on else "Запустить производство",
                              _toggle(game, "production", "Военные заводы переведены на трёхсменную работу.",
                                      "Военное производство сокращено."))],
                      ["Ежедневно: +0.2 вооружения, -2 казны."]))

    def depots():
        st.add("supply", 8)
        st.log_msg("Построены новые склады и узловые станции: снабжение улучшено.")
    items.append(Item("Склады и железные дороги", [costly(st, "Строить склады", {"treasury": 40}, depots)],
                      ["+8 снабжения разово. Без вложений снабжение медленно падает."]))

    def propaganda():
        st.add("morale", 8)
        st.log_msg("Фронтовые газеты и капелланы поднимают дух войск.")
    items.append(Item("Агитация в войсках", [costly(st, "Провести агитацию", {"treasury": 15}, propaganda)],
                      ["+8 боевого духа."]))

    cur = st.vars.get("army_doctrine")
    for key, dd in DOCTRINES.items():
        mark = "■" if cur == key else "□"
        cost = {"treasury": 50} if cur is None else {"treasury": 100}

        def pick(key=key, dd=dd):
            if st.vars.get("army_doctrine"):
                st.add("training", -10)
            st.vars["army_doctrine"] = key
            st.log_msg(f"Генштаб утвердил доктрину: «{dd['name']}».")
        acts = [] if cur == key else [costly(st, "Утвердить доктрину", cost, pick)]
        items.append(Item(f"{mark} Доктрина: {dd['name']}", acts,
                          [dd["desc"], "Смена доктрины стоит 100 казны и -10 выучки."]))
    return TabView("АРМИЯ", header, items)
