"""Ядерная программа: исследования, добыча, объекты, боезапас, носители, риски."""
from .. import registry
from .common import Action, Item, TabView, bar, costly

DOCTRINE_NAMES = {"retaliation": "Только ответный удар",
                  "preventive": "Превентивный удар при угрозе",
                  "unlimited": "Неограниченное применение"}


@registry.chance("nuclear.incident_chance")
def incident_chance(state, ctx):
    if not state.programs.get("nuke_research") and not state.programs.get("warhead_production"):
        return 0.0
    base = 0.002 + (0.010 if state.has_flag("nuke_forced") else 0.0)
    return base * (1.6 - state.get("nuke_safety") / 100)


@registry.predicate("nuclear.can_strike")
def can_strike(state, ctx):
    return state.get("warheads") > 0 and (state.get("bombers") + state.get("missiles")) > 0


def research_rate(state):
    rate = 0.3 * (1 + 0.3 * state.get("nuke_facilities")) * state.mod("nuke_speed")
    if state.get("nuke_materials") < 0.05:
        rate *= 0.25
    return rate


def daily(game):
    st = game.state
    if st.programs.get("mining"):
        st.add("nuke_materials", 0.3 + 0.05 * st.get("nuke_facilities"))
        st.add("treasury", -1.5)
    if st.programs.get("nuke_research") and not st.has_flag("nuke_tested"):
        st.add("nuke_research", research_rate(st))
        st.add("nuke_materials", -0.04)
        st.add("treasury", -3.0 if st.has_flag("nuke_forced") else -2.0)
        if st.get("nuke_research") >= 100 and "EVENT_W03" not in st.fired:
            st.set_flag("nuke_tested")
            st.programs["nuke_research"] = False
            game.engine.fire("EVENT_W03")
    if st.programs.get("warhead_production"):
        if st.get("nuke_materials") >= 0.2:
            st.add("nuke_materials", -0.2)
            st.add("treasury", -2.0)
            prog = st.vars.get("warhead_progress", 0) + 0.06 * (1 + 0.2 * st.get("nuke_facilities"))
            if prog >= 1:
                prog -= 1
                st.add("warheads", 1)
                st.log_msg(f"Арсенал пополнен: боеголовок — {st.get('warheads'):.0f}.")
            st.vars["warhead_progress"] = prog
    # международная реакция медленно остывает
    st.add("world_reaction", -0.02)


def view(game):
    st = game.state
    tested = st.has_flag("nuke_tested")
    started = st.has_flag("nuke_program")
    doc = DOCTRINE_NAMES.get(st.vars.get("nuke_doctrine"), "— не определена —")
    header = [
        (f"ЯДЕРНЫЙ ПРОЕКТ: {'ИСПЫТАН — ДЕРЖАВА В КЛУБЕ' if tested else ('ИДЁТ' if started else 'НЕ НАЧАТ')}", "bright"),
        ("", "normal"),
        (f"Исследования  {bar(st.get('nuke_research'))} {st.get('nuke_research'):5.1f}%"
         + ("" if tested or not started else f"   (+{research_rate(st):.2f}/день)"), "normal"),
        (f"Материалы     {st.get('nuke_materials'):6.1f} ед.   Объекты: {st.get('nuke_facilities'):.0f}/6", "normal"),
        (f"Безопасность  {bar(st.get('nuke_safety'))} {st.get('nuke_safety'):5.1f}"
         + ("   РЕЖИМ ФОРСИРОВАНИЯ" if st.has_flag("nuke_forced") else ""), "normal"),
        (f"Боезапас: {st.get('warheads'):.0f} боеголовок   Бомбардировщики: {st.get('bombers'):.0f}"
         f"   Ракеты: {st.get('missiles'):.0f}", "bright" if tested else "dim"),
        (f"Доктрина: {doc}   Цели: {'промышленность' if st.vars.get('nuke_target') == 'industrial' else 'военные объекты'}",
         "normal" if tested else "dim"),
        (f"Риск инцидента: {incident_chance(st, {}) * 100:.2f}% в день   Мировое осуждение: {st.get('world_reaction'):.0f}",
         "normal"),
        ("", "normal"),
    ]
    items = []
    if not started:
        def found():
            st.set_flag("nuke_program")
            st.programs["nuke_research"] = True
            st.add("nuke_materials", 3)
            st.log_msg("Учреждён секретный ядерный проект.")
            game.engine.fire("EVENT_W01")
        items.append(Item("Учредить ядерный проект", [costly(st, "Выделить средства", {"treasury": 80}, found)],
                          ["Первые вложения: собрать учёных, получить лаборатории.",
                           "Ежедневно программа съедает 2-3 казны."]))
    elif not tested:
        on = st.programs.get("nuke_research")

        def toggle_r():
            st.programs["nuke_research"] = not st.programs.get("nuke_research")
        items.append(Item(f"Исследования [{'ВКЛ' if on else 'пауза'}]",
                          [Action("Приостановить" if on else "Возобновить", toggle_r)],
                          ["Скорость растёт с числом объектов. Без материалов — в 4 раза медленнее."]))

    if started:
        on = st.programs.get("mining")

        def toggle_m():
            st.programs["mining"] = not st.programs.get("mining")
            st.log_msg("Рудники урана работают." if st.programs["mining"] else "Добыча урана остановлена.")
        items.append(Item(f"Добыча урана [{'ВКЛ' if on else 'выкл'}]", [Action("Переключить", toggle_m)],
                          ["Ежедневно: +0.3 материалов (+ от объектов), -1.5 казны."]))

        n = st.get("nuke_facilities")
        cost = {"treasury": 70 + 30 * n}

        def build():
            st.add("nuke_facilities", 1)
            st.log_msg(f"Введён в строй ядерный объект №{st.get('nuke_facilities'):.0f}.")
        items.append(Item(f"Строительство объектов ({n:.0f}/6)",
                          [costly(st, "Строить реактор/завод", cost, build, n < 6, "достигнут предел")],
                          ["Каждый объект: +30% к скорости исследований и производства."]))

        def safety():
            st.add("nuke_safety", 12)
            st.log_msg("Введены новые меры радиационной безопасности.")
        items.append(Item("Меры безопасности", [costly(st, "Профинансировать", {"treasury": 30}, safety)],
                          ["+12 безопасности: меньше аварий и утечек."]))

    if tested:
        on = st.programs.get("warhead_production")

        def toggle_w():
            st.programs["warhead_production"] = not st.programs.get("warhead_production")
        items.append(Item(f"Сборка боеголовок [{'ВКЛ' if on else 'выкл'}]", [Action("Переключить", toggle_w)],
                          ["Расход: 0.2 материалов и 2 казны в день. ~1 боеголовка в 2 недели."]))

        def bomber():
            st.add("bombers", 1)
            st.log_msg("Сформирована эскадрилья стратегических бомбардировщиков.")
        items.append(Item(f"Носители: авиация ({st.get('bombers'):.0f})",
                          [costly(st, "Сформировать эскадрилью", {"treasury": 45}, bomber)],
                          ["Бомбардировщики дешевле, но их можно перехватить."]))

        def missile():
            st.add("missiles", 1)
            st.add("tension", 2)
            st.log_msg("На боевое дежурство встала баллистическая ракета.")
        items.append(Item(f"Носители: ракеты ({st.get('missiles'):.0f})",
                          [costly(st, "Построить шахту", {"treasury": 90}, missile,
                                  st.get("nuke_facilities") >= 3, "нужно 3 ядерных объекта")],
                          ["Ракеты не перехватить. Каждая шахта нервирует противника (+2 напряжённости)."]))

        def target(kind):
            def fn():
                st.vars["nuke_target"] = kind
                st.log_msg("План удара пересмотрен: " + ("промышленные центры." if kind == "industrial" else "военные объекты."))
            return fn
        items.append(Item("Планирование целей",
                          [Action("Цели: военные объекты", target("military")),
                           Action("Цели: промышленные центры", target("industrial"))],
                          ["Заранее подготовленный план усиливает удар выбранного типа на 25%."]))
    return TabView("ЯДЕРНАЯ ПРОГРАММА", header, items)
