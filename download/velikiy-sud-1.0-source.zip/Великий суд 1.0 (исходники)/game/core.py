"""Партия целиком: состояние + движок ивентов + механики. Не зависит от pygame."""
import json
import os

from . import config
from .events.engine import EventEngine
from .game_state import GameState
from .mechanics import army, diplomacy, expansion, nuclear, war, world


def load_json(name):
    with open(os.path.join(config.DATA_DIR, name), encoding="utf-8") as f:
        return json.load(f)


# Вкладки боковой панели: ключ -> (название, функция представления или None для спец-вкладок)
TAB_ORDER = ["map", "log", "diplomacy", "army", "nuclear", "absorption", "france", "unification", "war"]
TAB_NAMES = {"map": "Карта Европы", "log": "Журнал событий", "diplomacy": "Дипломатия",
             "army": "Армия", "nuclear": "Ядерная программа",
             "absorption": "Поглощение Германии", "france": "Захват Франции", "unification": "Объединение России",
             "war": "Война"}


class Game:
    def __init__(self, side=None, seed=None, state=None):
        self.scenario = load_json("scenario.json")
        self.territory_data = load_json("territories.json")
        new = state is None
        self.state = state or GameState(side, self.scenario, seed)
        side = self.state.side
        self.side_cfg = self.scenario["sides"][side]
        self.expansion_cfg = self.territory_data[side]
        if not self.state.ai_territories:   # старые сохранения
            expansion.init_ai(self.state, self.territory_data)
        self.engine = EventEngine(self.state)
        self.state.engine = self.engine
        self.state.game = self
        if new:
            expansion.init_territories(self.state, self.territory_data)
            self.engine.daily()   # ивенты первого дня

    @classmethod
    def load(cls, path):
        scenario = load_json("scenario.json")
        return cls(state=GameState.load(path, scenario))

    # ---------- симуляция ----------
    def tick(self):
        """Один игровой день."""
        st = self.state
        if st.ending:
            return
        st.day += 1
        world.daily(self)
        army.daily(self)
        nuclear.daily(self)
        expansion.daily(self)
        expansion.ai_daily(self)
        war.daily(self)
        self.engine.daily()

    # ---------- вкладки ----------
    def tabs(self):
        return [t for t in TAB_ORDER if t in self.state.tabs]

    def view(self, tab):
        return {"diplomacy": diplomacy.view, "army": army.view, "nuclear": nuclear.view,
                "absorption": expansion.view, "unification": expansion.view,
                "france": lambda g: expansion.view(g, "france"),
                "war": war.view}[tab](self)

    # ---------- оценки разведки ----------
    def _fuzz(self, value, salt):
        err = (100 - self.state.get("intel")) / 100 * 0.45
        if err < 0.05:
            return f"{value:.0f}"
        lo = value * (1 - err)
        hi = value * (1 + err)
        return f"{lo:.0f}–{hi:.0f}"

    def enemy_estimate(self):
        return self._fuzz(war.enemy_power(self.state), 1)

    def enemy_nukes_estimate(self):
        st = self.state
        if not st.has_flag("enemy_nuke_tested"):
            return "нет данных" if st.get("intel") < 40 else f"нет (проект {st.get('enemy_nuke_research'):.0f}%)"
        if st.get("intel") >= 50:
            return f"{st.get('enemy_nukes'):.0f} боеголовок"
        return "есть, число неизвестно"
