"""Гербы сторон для экрана выбора: картинки assets/emblems/*.png (белый силуэт, тонируется в зелёный).

Символьные варианты BURGUNDY / LEAGUE остались на случай, если картинки не загрузятся."""
import os

import pygame

from .. import config

_CACHE = {}


def image(key, height, color):
    """Герб высотой height пикселей в цвете color (или None, если картинки нет)."""
    k = (key, height, color)
    if k not in _CACHE:
        try:
            src = pygame.image.load(os.path.join(config.ASSETS_DIR, "emblems", key + ".png"))
            w = round(src.get_width() * height / src.get_height())
            img = pygame.transform.smoothscale(src.convert_alpha() if pygame.display.get_surface() else src, (w, height))
            img.fill(color + (255,), special_flags=pygame.BLEND_RGBA_MULT)
            _CACHE[k] = img
        except Exception:
            _CACHE[k] = None
    return _CACHE[k]

BURGUNDY = [  # бургундский крест — сучковатые ветви крест-накрест — в круге
    "           ▗▄▄▄▄▄▄▄▄▖         ",
    "        ▄▟█▀▀▀    ▀▀▀█▙▄      ",
    "      ▟█▀           ▗▄ ▀█▙    ",
    "    ▗█▀▜█▙▖         ▐███▛▀█▖  ",
    "   ▗█▘  ███▙▖       ▟██▘  ▝█▖ ",
    "   █▌   █▀▀██▄▟█▛ ▄██▀     ▐█ ",
    "  ▐█        ▀██▙▄████▄      █▌",
    "  ▐█       ▐▙▖████          █▌",
    "  ▐█       ▝███▀▀██▄        █▌",
    "   █▌     ▗▟█▛   ████▄   ▗ ▐█ ",
    "   ▝█▖  ▗▟██▘   ▐▀▘ ▜███▛▘▗█▘ ",
    "    ▝█▄▟█▛▀▜▙▖       ▝▜█▙▄█▘  ",
    "      ▜█▄              ▄█▛    ",
    "        ▀▜█▄▄▄    ▄▄▄█▛▀      ",
    "           ▝▀▀▀▀▀▀▀▀▘         ",
]

LEAGUE = [  # пятиугольник Чёрной Лиги со звездой и двуглавым орлом
    "              ▗▄▄▖              ",
    "            ▄▟████▙▄            ",
    "           ▐███▛▜███▌           ",
    "          ▗▟██▄  ▄██▙▖          ",
    "    ▄▄▄ ▄█████▙▟▙▟█████▄ ▄▄▄    ",
    " ▄▟█████▛▜████████████▛▜█████▙▄ ",
    "▝███████  ▀█▙▄ ▜▛ ▄▟█▀  ███████▘",
    " ▐██████    ▐█▘  ▝█▌    ██████▌ ",
    "  ▜█████▖   ▝▘    ▝▘   ▗█████▛  ",
    "     ▝███▄▖          ▗▄███▘     ",
    "      ▜█████▛ ▗▖▗▖ ▜█████▛      ",
    "    ▗▄████▀▙▟▀▀  ▀▀▙▟▀████▄▖    ",
    "    ▝████████▄▄  ▄▄████████▘    ",
    "     ▜██████▛▀▀▀▀▀▀▜██████▛     ",
    "      ▀▀▀▀▀▀▘      ▝▀▀▀▀▀▀      ",
]


EMBLEMS = {"burgundy": lambda: BURGUNDY, "league": lambda: LEAGUE}
