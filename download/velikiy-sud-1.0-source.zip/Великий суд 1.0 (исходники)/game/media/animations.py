"""Процедурные ASCII-«видео» для суперивентов.

frame(media_cfg, t, w, h) -> Canvas: сетка символов и стилей.
Стили: ' ' нет, 'f' едва видно, 'd' тускло, 'n' норма, 'b' ярко, 'i' инверсия (вспышка).
Внизу кадра ничего не бежит: вся высота отдана картинке.
"""
import math
import random

DENSITY = " .:-=+*#%@"


class Canvas:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.chars = [[" "] * w for _ in range(h)]
        self.styles = [["f"] * w for _ in range(h)]
        self.ox = self.oy = 0      # тряска камеры

    def plot(self, x, y, ch, st="n"):
        x, y = int(x) + self.ox, int(y) + self.oy
        if 0 <= x < self.w and 0 <= y < self.h:
            self.chars[y][x] = ch
            self.styles[y][x] = st

    def text(self, x, y, s, st="n"):
        for i, ch in enumerate(s):
            self.plot(x + i, y, ch, st)

    def center(self, y, s, st="b"):
        self.text((self.w - len(s)) // 2, y, s, st)

    def fill(self, ch, st):
        for y in range(self.h):
            for x in range(self.w):
                self.chars[y][x] = ch
                self.styles[y][x] = st


# крупные буквы 5x5 для заголовков ("#" -> "██")
BIG = {
    "В": ["####.", "#...#", "####.", "#...#", "####."], "О": [".###.", "#...#", "#...#", "#...#", ".###."],
    "Й": ["..#..", "#...#", "#..##", "#.#.#", "##..#"], "Н": ["#...#", "#...#", "#####", "#...#", "#...#"],
    "А": [".###.", "#...#", "#####", "#...#", "#...#"], "П": ["#####", "#...#", "#...#", "#...#", "#...#"],
    "У": ["#...#", "#...#", ".####", "....#", ".###."], "С": [".####", "#....", "#....", "#....", ".####"],
    "К": ["#...#", "#..#.", "###..", "#..#.", "#...#"], "Д": ["..##.", ".#.#.", ".#.#.", "#####", "#...#"],
    "Р": ["####.", "#...#", "####.", "#....", "#...."], " ": [".....", ".....", ".....", ".....", "....."],
    "0": [".###.", "#..##", "#.#.#", "##..#", ".###."], "1": ["..#..", ".##..", "..#..", "..#..", ".###."],
    "2": [".###.", "#...#", "..##.", ".#...", "#####"], "3": ["####.", "....#", "..##.", "....#", "####."],
    "4": ["#...#", "#...#", "#####", "....#", "....#"], "5": ["#####", "#....", "####.", "....#", "####."],
    "6": [".###.", "#....", "####.", "#...#", ".###."], "7": ["#####", "...#.", "..#..", ".#...", ".#..."],
    "8": [".###.", "#...#", ".###.", "#...#", ".###."], "9": [".###.", "#...#", ".####", "....#", ".###."],
    ":": [".....", "..#..", ".....", "..#..", "....."],
    "М": ["#...#", "##.##", "#.#.#", "#...#", "#...#"], "Е": ["#####", "#....", "####.", "#....", "#####"],
    "Т": ["#####", "..#..", "..#..", "..#..", "..#.."], "Ь": ["#....", "#....", "####.", "#...#", "####."],
    "Л": ["..###", ".#..#", ".#..#", ".#..#", "#...#"], "И": ["#...#", "#..##", "#.#.#", "##..#", "#...#"],
    "Б": ["#####", "#....", "####.", "#...#", "####."], "Г": ["#####", "#....", "#....", "#....", "#...."],
    "Я": [".####", "#...#", ".####", ".#..#", "#...#"], "Ч": ["#...#", "#...#", ".####", "....#", "....#"], "Ё": ["#.#.#", "#####", "####.", "#....", "#####"],
}


def big_text(c, y, text, st="b", ch="█"):
    """Крупная надпись по центру кадра (каждая буква 10x5 символов)."""
    width = len(text) * 12 - 2
    x0 = (c.w - width) // 2
    for k, letter in enumerate(text):
        rows = BIG.get(letter, BIG[" "])
        for r, row in enumerate(rows):
            for col, px in enumerate(row):
                if px == "#":
                    c.plot(x0 + k * 12 + col * 2, y + r, ch, st)
                    c.plot(x0 + k * 12 + col * 2 + 1, y + r, ch, st)


def _blast(c, x, y, r, rng, st="b"):
    """Разрыв снаряда: кольцо осколков радиуса r."""
    for a in range(0, 360, 20):
        rr = r * (0.7 + 0.5 * rng.random())
        c.plot(x + 2 * rr * math.cos(math.radians(a)), y + rr * math.sin(math.radians(a)),
               rng.choice("*'`.,%"), st)
    c.plot(x, y, "@", "b")


def _grain(c, rng, amount=0.02):
    for _ in range(int(c.w * c.h * amount)):
        c.plot(rng.randrange(c.w), rng.randrange(c.h), rng.choice(".,'`"), "f")


def _skyline(c, seed, ground, ruined=False, burning=0.0, t=0.0, rng=None):
    r = random.Random(seed)
    x = 0
    while x < c.w:
        bw = r.randint(3, 8)
        bh = r.randint(2, max(3, c.h // 2 - 1))
        if ruined:
            bh = max(1, bh - r.randint(0, bh))
        for xx in range(x, min(c.w, x + bw)):
            top = ground - bh
            if ruined:
                top += r.randint(0, 1)
            for yy in range(top, ground):
                win = (yy - top) % 2 == 1 and (xx - x) % 2 == 1 and not ruined
                c.plot(xx, yy, ":" if win else ("▓" if ruined else "█"), "d")
            if burning and rng and rng.random() < burning:
                c.plot(xx, top - 1, rng.choice("^*()"), "b")
                if rng.random() < 0.5:
                    c.plot(xx + rng.randint(-1, 1), top - 2 - int((t * 3 + xx) % 3), "░", "d")
        x += bw + r.randint(0, 2)
    for xx in range(c.w):
        c.plot(xx, ground, "▀", "d")


# ---------------- стили ----------------
def newsreel(cfg, t, w, h):
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    _grain(c, rng, 0.03)
    if rng.random() < 0.3:
        x = rng.randrange(w)
        for y in range(h - 1):
            c.plot(x, y, "|", "f")
    ground = h - 2
    _skyline(c, 42, ground, burning=0.18, t=t, rng=rng)
    # силуэт купола в центре
    cx = w // 2
    for dx in range(-6, 7):
        top = ground - 6 - int(3 * math.sqrt(max(0, 1 - (dx / 6.5) ** 2)))
        for y in range(top, ground):
            c.plot(cx + dx, y, "█", "n")
    for dx in range(-8, 9):
        c.plot(cx + dx, ground - 6, "▀", "n")
    if int(t * 2) % 2 == 0:
        c.center(1, "■ ЭКСТРЕННЫЙ ВЫПУСК ■", "b")
    c.center(2, cfg.get("caption", ""), "n")
    if t > 3:
        c.text(2, 4, "ДИКТОР: «...повторяем: лидер Рейха скончался этой ночью...»"[: int((t - 3) * 20)], "n")
    return c


def war(cfg, t, w, h):
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    horizon = h // 3
    for x in range(w):
        c.plot(x, horizon, "_", "f")
    for _ in range(4):
        if rng.random() < 0.6:
            fx = rng.randrange(w)
            c.plot(fx, horizon - 1, "*", "b")
            c.plot(fx, horizon - 2, "'", "n")
    tank = ["   ▄▄██▄▄═════", " ▐██████████▌", "  o o o o o o"]
    for k in range(4):
        x = int(w - ((t * 9 + k * 30) % (w + 20)))
        y = horizon + 2 + (k % 2) * 4
        for i, row in enumerate(tank):
            c.text(x, y + i, row, "n")
    for x in range(w):
        c.plot(x, h - 2, "▀", "d")
    if int(t * 2) % 2 == 0:
        c.center(1, "■ " + cfg.get("caption", "") + " ■", "b")
    return c


def _mushroom(c, cx, ground, tt, scale=1.0, rng=None):
    if tt < 0:
        return
    grow = min(1.0, tt / 4.0)
    rx = (4 + 14 * grow) * scale
    ry = max(1.5, rx * 0.28)
    cy = ground - (2 + (c.h * 0.62) * grow) * scale
    # ножка
    stem_w = max(1, int(2 * scale + grow * 2))
    for y in range(int(cy + ry * 0.5), ground):
        for dx in range(-stem_w, stem_w + 1):
            ch = DENSITY[5 + (rng.randrange(3) if rng else 0)]
            c.plot(cx + dx, y, ch, "n")
    # юбка у земли
    skirt = rx * 1.2
    for dx in range(-int(skirt), int(skirt) + 1):
        d = abs(dx) / max(1, skirt)
        c.plot(cx + dx, ground - 1, DENSITY[max(1, int(6 * (1 - d)))], "d")
    # шляпка
    for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
        for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
            d = ((x - cx) / max(1, rx)) ** 2 + ((y - cy) / max(1, ry)) ** 2
            if d <= 1.0:
                k = int((1 - d) * 6) + 3
                if rng:
                    k += rng.randrange(-1, 2)
                st = "b" if d < 0.35 else "n"
                c.plot(x, y, DENSITY[max(1, min(9, k))], st)


def nuke(cfg, t, w, h):
    c = Canvas(w, h)
    rng = random.Random(int(t * 15))
    variant = cfg.get("variant", "test")
    ground = h - 2
    t0 = 2.4 if variant == "test" else 3.0
    cx = w // 2
    if t < t0:
        if variant == "test":
            for x in range(w):
                c.plot(x, ground, "_", "d")
            for k, tx in enumerate((10, 25, w - 26, w - 11)):
                for y in range(ground - 4, ground):
                    c.plot(tx, y, "‡" if y == ground - 4 else "|", "n")
            n = 3 - int(t / 0.6)
            c.center(3, f"ОТСЧЁТ:  {max(0, n)}", "b")
        else:
            _skyline(c, 7, ground)
            if int(t * 3) % 2 == 0:
                c.center(2, "▲ ВОЗДУШНАЯ ТРЕВОГА ▲", "b")
        return c
    tt = t - t0
    if tt < 0.35:
        c.fill("█", "i")
        return c
    if tt < 0.6:
        c.fill("▓", "b")
        return c
    if tt < 0.85:
        c.fill("▒", "n")
        return c
    if variant == "test":
        for x in range(w):
            c.plot(x, ground, "_", "d")
        wave = tt * 22
        for tx in (10, 25, w - 26, w - 11):
            if abs(tx - cx) > wave:
                for y in range(ground - 4, ground):
                    c.plot(tx, y, "‡" if y == ground - 4 else "|", "n")
            else:
                c.plot(tx + (1 if tx > cx else -1), ground - 1, "/" if tx > cx else "\\", "d")
        for s in (-1, 1):
            c.plot(cx + s * wave, ground - 1, "~", "b")
            c.plot(cx + s * (wave - 1), ground - 1, "~", "n")
    else:
        _skyline(c, 7, ground, ruined=tt > 1.5, burning=0.25 if tt > 1.5 else 0, t=t, rng=rng)
        if tt > 3.5:
            _mushroom(c, w // 5, ground, tt - 3.5, 0.5, rng)
    _mushroom(c, cx, ground, tt - 0.85, 1.0, rng)
    return c


def launch(cfg, t, w, h):
    c = Canvas(w, h)
    rng = random.Random(int(t * 15))
    ground = h - 2
    for x in range(w):
        c.plot(x, ground, "▀", "d")
    sprite = [" ^ ", "/█\\", "|█|", "|█|", "/|\\"]
    for k, (mx, ts) in enumerate(((w // 6, 1.5), (w // 3, 2.3), (w // 2 - 4, 3.1))):
        if t < ts:
            c.text(mx - 1, ground - 1, "[▄]", "n")
            continue
        alt = (t - ts) ** 2 * 1.6
        y = ground - 5 - int(alt)
        for i, row in enumerate(sprite):
            c.text(mx - 1, y + i, row, "b")
        for j in range(1, 8):
            yy = y + 4 + j
            if yy < ground:
                c.plot(mx + rng.randint(-1, 1) * (j > 2), yy, rng.choice("*░▒") if j < 3 else "░",
                       "b" if j < 3 else "d")
    # радар справа
    rcx, rcy, rr = w - 18, h // 2, min(h // 2 - 1, 7)
    for a in range(0, 360, 8):
        c.plot(rcx + 2 * rr * math.cos(math.radians(a)), rcy + rr * math.sin(math.radians(a)), "·", "d")
    ang = t * 2.5
    for r in range(1, rr):
        c.plot(rcx + 2 * r * math.cos(ang), rcy + r * math.sin(ang), "─" if abs(math.cos(ang)) > 0.7 else "/", "n")
    for k in range(min(8, int(t * 1.5))):
        a = 1.0 + k * 0.7
        rad = rr * (1 - ((t * 0.08 + k * 0.1) % 1.0))
        c.plot(rcx + 2 * rad * math.cos(a), rcy + rad * math.sin(a), "◆" if k % 2 else "●", "b")
    c.text(rcx - 6, rcy + rr + 1, "РАДАР ПРОТИВНИКА", "d")
    if int(t * 3) % 2 == 0:
        c.center(1, "■ " + cfg.get("caption", "") + " ■", "b")
    return c


def ash(cfg, t, w, h):
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    ground = h - 2
    _skyline(c, 99, ground, ruined=True, burning=0.05, t=t, rng=rng)
    pr = random.Random(5)
    for k in range(int(w * h * 0.06)):
        x0 = pr.uniform(0, w)
        sp = pr.uniform(0.6, 1.6)
        y = (pr.uniform(0, h) + t * sp * 1.5) % (ground)
        x = (x0 + t * 2.5 * sp) % w
        c.plot(x, y, pr.choice(".,'·"), "d" if sp > 1.2 else "f")
    if 1.0 < t < 1.2 or 6.0 < t < 6.15:
        c.fill("▒", "n")
    if int(t * 1.5) % 2 == 0:
        c.center(2, cfg.get("caption", ""), "b")
    return c


def flag(cfg, t, w, h):
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    variant = cfg.get("variant", "victory")
    ground = h - 2
    _skyline(c, 3, ground, ruined=variant != "victory", burning=0.04, t=t, rng=rng)
    px = w // 2 - 10
    if variant == "berlin":
        # силуэт ворот с колоннадой
        for x in range(px - 8, px + 9):
            c.plot(x, ground - 6, "▀", "n")
        for x in range(px - 7, px + 8, 3):
            for y in range(ground - 5, ground):
                c.plot(x, y, "║", "n")
        base = ground - 7
    elif variant == "kremlin":
        for y in range(ground - 7, ground):
            for x in range(px - 3, px + 4):
                c.plot(x, y, "█", "n")
        for k in range(4):
            for x in range(px - 2 + k // 2, px + 3 - k // 2):
                c.plot(x, ground - 8 - k, "▲" if k == 3 else "█", "n")
        base = ground - 12
    else:
        base = ground - 1
    top = 2
    for y in range(top, base + 1):
        c.plot(px, y, "│", "b")
    rise = min(1.0, t / (cfg.get("duration", 8) * 0.6))
    fy = int(base - 4 - (base - 4 - top) * rise)
    for r in range(4):
        for x in range(1, 19):
            wave = int(round(math.sin(t * 4 - x * 0.5) * 0.6))
            ch = "▒" if r in (1, 2) and 6 <= x <= 12 else "█"
            c.plot(px + x, fy + r + wave, ch, "b")
    if rise >= 1.0:
        c.center(1, "■ " + cfg.get("caption", "") + " ■", "b")
    return c


def purge(cfg, t, w, h):
    """Тёмный коридор в перспективе, двери по сторонам захлопываются одна за другой, зернистая хроника."""
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    cx, cy = w // 2, h // 2
    depth = 7
    for d in range(depth, 0, -1):          # рамки коридора от дальней к ближней
        k = d / depth
        hw, hh = int(cx * k), int((cy - 1) * k)
        x0, x1, y0, y1 = cx - hw, cx + hw, cy - hh, cy + hh
        st = "f" if d > 4 else "d"
        for x in range(x0, x1 + 1):
            c.plot(x, y0, "─", st)
            c.plot(x, y1, "─", st)
        for y in range(y0, y1 + 1):
            c.plot(x0, y, "│", st)
            c.plot(x1, y, "│", st)
    for d in range(1, depth):               # двери по стенам: закрываются со временем
        k0, k1 = d / depth, (d + 0.6) / depth
        shut = t > 1.0 + (depth - d) * 1.0
        for side in (-1, 1):
            xa, xb = cx + side * int(cx * k0), cx + side * int(cx * k1)
            lo, hi = sorted((xa, xb))
            top, bot = cy - int((cy - 1) * k0 * 0.7), cy + int((cy - 1) * k0)
            for x in range(lo, hi + 1):
                for y in range(top, bot):
                    if shut:
                        c.plot(x, y, "█", "d")
                    elif x in (lo, hi):
                        c.plot(x, y, "│", "n")
                    else:
                        c.plot(x, y, "░" if rng.random() < 0.3 else " ", "b")
    # силуэт в конце коридора уходит прочь
    fig = max(1, 4 - int(t / 2.5))
    for y in range(fig):
        c.plot(cx, cy + 1 - y, "█" if y else "▀", "n")
    _grain(c, rng, 0.06)
    if rng.random() < 0.25:
        x = rng.randrange(w)
        for y in range(h - 1):
            c.plot(x, y, "|", "f")
    if int(t * 2) % 2 == 0:
        c.center(1, "■ " + cfg.get("caption", "") + " ■", "b")
    return c


def night_clash(cfg, t, w, h):
    """Правительственный квартал ночью: вспышки выстрелов, бегущие фигуры, трассеры."""
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    ground = h - 3
    _skyline(c, 77, ground, burning=0.04 + min(0.15, t * 0.02), t=t, rng=rng)
    cx = w // 2   # здание правительства с колоннадой
    for y in range(ground - 9, ground):
        for x in range(cx - 12, cx + 13):
            col = (x - cx) % 4 == 0 and y > ground - 7
            c.plot(x, y, "║" if col else ("▓" if y == ground - 9 else " "), "n")
    for x in range(cx - 13, cx + 14):
        c.plot(x, ground - 9, "▄", "n")
    for _ in range(6):                       # дульные вспышки и трассеры
        if rng.random() < 0.7:
            fx, fy = rng.randrange(w), rng.randrange(ground - 6, ground)
            c.plot(fx, fy, rng.choice("*✱+"), "b")
            dx = rng.choice((-1, 1))
            for k in range(1, rng.randint(3, 9)):
                c.plot(fx + dx * k * 2, fy - k // 3, "-", "n")
    for k in range(5):                       # бегущие фигуры
        x = int((t * (6 + k * 2) + k * 23) % (w + 10)) - 5
        if k % 2:
            x = w - x
        y = ground - 1
        c.plot(x, y - 1, "o", "b")
        c.plot(x, y, "λ" if int(t * 6 + k) % 2 else "Λ", "b")
    for x in range(w):
        c.plot(x, ground, "▀", "d")
    _grain(c, rng, 0.02)
    if int(t * 2) % 2 == 0:
        c.center(1, "■ " + cfg.get("caption", "") + " ■", "b")
    return c


def war_start(cfg, t, w, h):
    """Начало войны: тревога и крупное «ВОЙНА», артиллерийский вал, затем танки и самолёты через границу."""
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    ground = h - 2
    if t < 2.6:   # сцена 1: тревога
        if int(t * 4) % 2 == 0:
            c.fill(" ", "f")
            big_text(c, h // 2 - 3, "ВОЙНА", "b")
        else:
            c.fill("░", "f")
            big_text(c, h // 2 - 3, "ВОЙНА", "i")
        c.center(1, "▲ БОЕВАЯ ТРЕВОГА ▲  ВСЕ ЧАСТИ — НА ИСХОДНЫЕ  ▲ БОЕВАЯ ТРЕВОГА ▲", "b")
        c.center(h - 2, "ОБЪЯВЛЕНА ВСЕОБЩАЯ МОБИЛИЗАЦИЯ", "n")
        return c
    if t < 6.2:   # сцена 2: артиллерийский вал на рассвете
        tt = t - 2.6
        c.ox = rng.randint(-1, 1) if rng.random() < 0.5 else 0
        for x in range(w):
            c.plot(x, ground, "▀", "d")
        border = w // 2
        for y in range(2, ground):
            if y % 2 == 0:
                c.plot(border, y, "┊", "d")
        for k in range(8):   # орудия слева
            gx = 4 + k * 6
            c.text(gx, ground - 1, "▄▟═", "n")
            if rng.random() < 0.35:
                c.plot(gx + 3, ground - 2, "*", "b")
        for k in range(14):   # снаряды по дугам
            ph = (tt * 0.9 + k * 0.137) % 1.0
            x0, x1 = 6 + (k * 7) % 44, border + 6 + (k * 13) % (w - border - 10)
            for s in range(7):   # снаряд и светящийся след
                q = max(0.0, ph - s * 0.018)
                x = x0 + (x1 - x0) * q
                y = ground - 1 - (ground - 3) * 4 * q * (1 - q)
                c.plot(x, y, "●" if s == 0 else ("•" if s < 3 else "·"), "b" if s < 2 else ("n" if s < 4 else "d"))
            if ph < 0.05:
                c.plot(x0 + 2, ground - 2, "✱", "b")
                c.plot(x0 + 3, ground - 3, "*", "b")
            if ph > 0.88:
                _blast(c, x1, ground - 1, 1 + (ph - 0.88) * 35, rng)
                for dy in range(1, 4):
                    c.plot(x1 + rng.randint(-1, 1), ground - 1 - dy, rng.choice("▒░*"), "b")
        for _ in range(int(tt * 6)):    # пожары по ту сторону границы
            fx = border + 3 + rng.randrange(max(1, w - border - 5))
            c.plot(fx, ground - 1 - rng.randint(0, 2), rng.choice("^*()"), "b")
        if rng.random() < 0.12:
            c.fill("▒", "n")
        c.center(1, "■ " + cfg.get("caption", "") + " ■", "b")
        return c
    # сцена 3: танки и авиация переходят границу
    tt = t - 6.2
    for x in range(w):
        c.plot(x, ground, "▀", "d")
    for k in range(3):     # прожекторы
        bx = 15 + k * 40
        ang = math.sin(t * 0.8 + k) * 0.6
        for r in range(1, ground - 2):
            c.plot(bx + r * math.sin(ang) * 2, ground - 1 - r, "╱" if ang > 0 else "╲", "f")
    tank = ["  ▄▄██▄▄═════", "▐███████████▌", " ◦◦◦◦◦◦◦◦◦◦ "]
    for k in range(6):
        x = int(-15 + ((tt * 11 + k * 22) % (w + 30)))
        y = ground - 3 - (k % 2) * 4
        for i, row in enumerate(tank):
            c.text(x, y + i, row, "n" if k % 2 else "b")
        for d in range(1, 6):
            c.plot(x - d - rng.randint(0, 2), y + 2, "░", "f")
    plane = ["▄▀═╦═>", ]
    for k in range(5):
        x = int(((tt * 26 + k * 25) % (w + 20)) - 10)
        y = 3 + (k % 3) * 2
        c.text(x, y, plane[0], "b")
        if (x + k) % 9 < 3:
            for d in range(1, 4):
                c.plot(x + 2, y + d + int(tt * 3) % 2, "¦", "n")
    if int(t * 2) % 2 == 0:
        c.center(1, "■ " + cfg.get("caption2", "ГРАНИЦА ПЕРЕЙДЕНА") + " ■", "b")
    return c


def launch2(cfg, t, w, h):
    """Пуск: ключи и отсчёт в бункере, открытие шахт, взлёт ракет, траектории над картой."""
    c = Canvas(w, h)
    rng = random.Random(int(t * 15))
    ground = h - 2
    if t < 3.4:   # сцена 1: бункер, ключи, отсчёт
        lamp = int(t * 5) % 2 == 0
        c.text(3, 1, "ПУЛЬТ БОЕВОГО УПРАВЛЕНИЯ  // РЕЖИМ: ПУСК", "n")
        c.text(3, 2, "КОДЫ ПОДТВЕРЖДЕНЫ ....... ДА", "d")
        c.text(3, 3, "ЦЕЛИ ВВЕДЕНЫ ............ ДА", "d")
        for k, kx in enumerate((6, 26)):
            turned = t > 0.6 + k * 0.5
            c.text(kx, 6, "┌──────────┐", "n")
            c.text(kx, 7, "│  КЛЮЧ " + str(k + 1) + "  │", "n")
            c.text(kx, 8, "│    " + ("─╋─" if turned else " ┃ ") + "   │", "b" if turned else "n")
            c.text(kx, 9, "└──────────┘", "n")
        c.text(6, 11, ("● ПУСК РАЗРЕШЁН ●" if lamp else "○ ПУСК РАЗРЕШЁН ○"), "b" if lamp else "d")
        n = max(1, 3 - int(max(0.0, t - 1.4) / 0.67))
        big_text(c, 4, str(n), "b")
        c.text(w - 30, 2, "ГОТОВНОСТЬ НОСИТЕЛЕЙ", "n")
        for k in range(6):
            c.text(w - 30, 4 + k, f"ШАХТА {k + 1}  ▮▮▮▮▮▮ ГОТОВ", "b" if lamp or k % 2 else "n")
        return c
    if t < 8.2:   # сцена 2: шахты открываются, ракеты уходят вверх
        tt = t - 3.4
        c.ox = rng.randint(-1, 1) if tt > 0.8 and tt < 3.5 else 0
        for x in range(w):
            c.plot(x, ground, "▀", "d")
        silos = [w // 2 - 30, w // 2, w // 2 + 30]
        for k, sx in enumerate(silos):
            gap = int(3 * min(1.0, tt / 0.8))
            for dx in range(-7, 8):     # крышка шахты разъезжается
                if abs(dx) > gap:
                    c.plot(sx + dx, ground, "▄", "n")
            ts = 0.8 + k * 0.6
            if tt < ts:
                continue
            alt = (tt - ts) ** 2 * 3.2
            y = ground - 5 - int(alt)
            for yy in range(max(0, y + 5), ground):     # дымный столб от шахты до ракеты
                j = yy - (y + 5)
                spread = min(5, j // 2)
                for dx in range(-spread, spread + 1):
                    if rng.random() < 0.7:
                        c.plot(sx + dx, yy, "▒" if abs(dx) < 2 else "░", "n" if j > 2 else "b")
                if j < 2:
                    c.plot(sx, yy, "✱", "b")
            body = [" ▲ ", "▐█▌", "▐█▌", "▐█▌", "╱█╲"]
            for i, row in enumerate(body):
                c.text(sx - 1, y + i, row, "b")
            for dx in range(-12, 13):   # клубы у земли
                if rng.random() < 0.5:
                    c.plot(sx + dx, ground - 1 - rng.randint(0, 1), rng.choice("▒░"), "d")
        c.center(1, "■ " + cfg.get("caption", "") + " ■", "b")
        return c
    # сцена 3: траектории над картой, отсчёт подлётного времени
    tt = t - 8.2
    for x in range(0, w, 2):
        c.plot(x, ground, "·", "f")
    for k in range(5):
        x0, x1 = 4 + k * 3, w - 34 + k * 7
        c.plot(x1, ground, "✕", "b" if int(t * 4) % 2 else "n")
        ph = min(1.0, tt / 3.2 + k * 0.03)
        steps = int(70 * ph)
        for s in range(steps):
            q = s / 70
            x = x0 + (x1 - x0) * q
            y = ground - 1 - (ground - 4) * 4 * q * (1 - q)
            c.plot(x, y, "·" if s < steps - 1 else "◆", "n" if s < steps - 1 else "b")
    c.text(2, 1, "СЛЕЖЕНИЕ: ЦЕЛЕЙ 5", "n")
    c.text(w - 22, 1, "ПОДЛЁТНОЕ ВРЕМЯ", "d")
    left = max(0, 14 - int(tt * 3))
    big_text(c, ground - 6, f"{left:02d}:00", "n")
    return c


def strike(cfg, t, w, h):
    """Ядерный удар по городу: тревога, падающие боеголовки, вспышка, ударная волна, гриб, второй взрыв."""
    c = Canvas(w, h)
    rng = random.Random(int(t * 15))
    ground = h - 2
    cx = w // 2
    t0 = 3.0
    if t < t0:
        _skyline(c, 7, ground)
        if int(t * 3) % 2 == 0:
            big_text(c, 2, "УДАР", "b")
        for k in range(3):
            y = int((t / t0) * (ground - 2)) - k * 3
            x = cx + (k - 1) * 25 + int(t * (k - 1) * 2)
            for d in range(4):
                c.plot(x, y - d, "│" if d else "▼", "b" if d == 0 else "n")
        c.text(2, 1, "ВОЗДУШНАЯ ТРЕВОГА", "b" if int(t * 4) % 2 else "n")
        return c
    tt = t - t0
    if tt < 0.3:
        c.fill("█", "i")
        return c
    if tt < 0.55:
        c.fill("▓", "b")
        return c
    if tt < 0.8:
        c.fill("▒", "n")
        return c
    wave = (tt - 0.8) * 26
    c.ox = rng.randint(-2, 2) if tt < 2.5 else 0
    # здания вне волны целы, внутри — руины
    r = random.Random(7)
    x = 0
    while x < w:
        bw, bh = r.randint(3, 8), r.randint(2, max(3, h // 2 - 1))
        hit = abs(x + bw / 2 - cx) < wave
        if hit:
            bh = max(1, bh // 3)
        for xx in range(x, min(w, x + bw)):
            for yy in range(ground - bh, ground):
                c.plot(xx, yy, "▓" if hit else "█", "d")
            if hit and rng.random() < 0.3:
                c.plot(xx, ground - bh - 1, rng.choice("^*"), "b")
        x += bw + r.randint(0, 2)
    for x in range(w):
        c.plot(x, ground, "▀", "d")
    if wave < w:   # кольцо ударной волны
        for a in range(0, 181, 3):
            xx = cx + wave * math.cos(math.radians(a))
            yy = ground - 1 - wave * 0.35 * math.sin(math.radians(a))
            c.plot(xx, yy, rng.choice("░▒"), "b")
    _mushroom(c, cx, ground, tt - 0.8, 0.95, rng)
    if tt > 5.5:   # второй, дальний взрыв
        t2 = tt - 5.5
        if t2 < 0.2:
            c.fill("▒", "b")
        else:
            _mushroom(c, w // 6, ground, t2, 0.5, rng)
    if tt > 3.0:
        c.text(2, 1, "СВЯЗЬ С ОБЛАСТЯМИ ПОТЕРЯНА", "n" if int(t * 2) % 2 else "d")
    return c


def summit_death(cfg, t, w, h):
    """«Смерть на вершине»: секретный телетайп, траур над канцелярией, оцепление Берлина, три голоса в эфире и раскол."""
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    ground = h - 2
    if t < 3.2:   # сцена 1: телетайп в темноте
        lines = ["ВЕРХОВНОЕ КОМАНДОВАНИЕ // ЛИЧНО // СОВЕРШЕННО СЕКРЕТНО",
                 "БЕРЛИН 03:40 // ВРАЧИ НЕ ДОПУЩЕНЫ К ТЕЛУ",
                 "СЕРДЦЕ ОСТАНОВИЛОСЬ // ДОКУМЕНТ О ПРЕЕМНИКЕ НЕ НАЙДЕН",
                 "ВСЕМ ГАРНИЗОНАМ: НИКАКИХ ПРИКАЗОВ НЕ ИСПОЛНЯТЬ"]
        n = int(t * 44)
        y0 = max(1, h // 2 - 4)
        for i, line in enumerate(lines):
            shown = line[:max(0, n - i * 26)]
            c.text(6, y0 + i * 2, shown, "b" if i == len(lines) - 1 else "n")
            if 0 < len(shown) < len(line) and int(t * 6) % 2 == 0:
                c.plot(6 + len(shown), y0 + i * 2, "█", "b")
        c.text(2, 1, "▌ТЕЛЕТАЙП 7▐", "d")
        _grain(c, rng, 0.01)
        return c
    if t < 6.6:   # сцена 2: траур над канцелярией
        tt = t - 3.2
        cx, top = w // 2, max(9, ground - 9)
        for x in range(cx - 30, cx + 31):
            c.plot(x, top - 1, "▄", "n")
            c.plot(x, ground - 1, "▀", "d")
        for k in range(-6, 7):   # колонны
            for y in range(top, ground - 1):
                c.plot(cx + k * 5, y, "║", "d")
        lit = tt < 1.4 or (tt < 2.0 and rng.random() < 0.5)
        c.text(cx - 2, top + 2, "▐██▌" if lit else "▐  ▌", "b" if lit else "f")
        mast = min(1.0, tt / 2.4)
        for k, fx in enumerate((cx - 40, cx + 37)):   # флагштоки, полотнища ползут вниз
            for y in range(3, ground):
                c.plot(fx, y, "│", "n")
            fy = int(3 + mast * 5)
            for dy in range(3):
                c.text(fx + 1, fy + dy, "▓▓▓▓▓" if (dy + int(t * 3) + k) % 4 else "▓▓▓▓▒", "n")
        for x in range(w):
            c.plot(x, ground, "▀", "d")
        if tt > 1.0:
            big_text(c, 1, "ТРАУР", "n" if int(t * 2) % 2 else "b")
        c.center(7, cfg.get("caption", ""), "b")
        return c
    if t < 9.8:   # сцена 3: Берлин оцеплен
        tt = t - 6.6
        for x in range(w):
            c.plot(x, ground, "▀", "d")
        _skyline(c, 7, ground - 1)
        for k in range(4):   # прожекторы
            bx = 10 + k * (w // 4)
            ang = math.sin(t * 1.1 + k * 1.7) * 0.7
            for r in range(1, ground - 2):
                c.plot(bx + r * math.sin(ang) * 2, ground - 2 - r, "╱" if ang > 0 else "╲", "f")
        bar = w // 2 + 8
        c.text(bar - 6, ground - 2, "▓▒▓▒▓▒▓▒▓▒▓▒▓", "b")   # шлагбаум
        c.text(bar - 6, ground - 3, "  КОНТРОЛЬ", "n")
        car = ["  ▄▄▄██▄▄", "▐████████▌", " ◦◦  ◦◦  "]
        for k in range(4):
            x = int(min(bar - 18 - k * 14, -20 + tt * 26 - k * 14))
            for i, row in enumerate(car):
                c.text(x, ground - 3 + i - 1, row, "n")
        for k in range(7):   # патрули
            px = int((k * 23 + tt * 6) % w)
            c.plot(px, ground - 1, "♜", "d")
        c.center(1, "■ БЕРЛИН ОЦЕПЛЕН · СВЯЗЬ С ПРОВИНЦИЯМИ ПРЕРВАНА ■", "b" if int(t * 3) % 2 else "n")
        return c
    # сцена 4: три голоса в эфире, экран раскалывается
    tt = t - 9.8
    voices = [("РАДИО ПАРТИИ", "«Партийная канцелярия принимает власть...»"),
              ("РАДИО ГЕРИНГА", "«Рейхсмаршал призывает армию к порядку...»"),
              ("ВОЛНА СС", "«Орден не признаёт ни одного из них...»")]
    pw = w // 3
    for i, (head, line) in enumerate(voices):
        x0 = i * pw
        for y in range(h - 1):
            c.plot(x0, y, "║", "n")
        c.text(x0 + 2, 1, head, "b")
        shown = line[:max(0, int((tt - i * 0.4) * 30))]
        row, col = 3, 0
        for word in shown.split(" "):   # перенос по словам
            if col and col + len(word) > pw - 4:
                row, col = row + 1, 0
            c.text(x0 + 2 + col, row, word, "n")
            col += len(word) + 1
        for x in range(x0 + 2, x0 + pw - 2):   # осциллограмма
            v = math.sin(x * 0.4 + t * (5 + i * 2)) * math.sin(x * 0.11 + i) * 2.2
            c.plot(x, h - 4 + int(v), "∙", "d")
    if tt > 1.4:   # трещина через кадр
        crack = random.Random(9)
        x = w // 2
        reach = int(min(h, (tt - 1.4) * 40))
        for y in range(reach):
            x += crack.choice((-1, 0, 1))
            c.plot(x, y, "╳", "b")
            c.plot(x + 1, y, "▒", "n")
    if tt > 2.0:
        c.ox = rng.randint(-1, 1)
        for y in range(h // 2 - 3, h // 2 + 4):   # чёрная полоса под надписью
            for x in range(w):
                c.plot(x - c.ox, y, " ", "f")
        big_text(c, h // 2 - 2, "СМУТА", "b" if int(t * 4) % 2 else "n")
    return c


def kremlin(cfg, t, w, h):
    """«Знамя над Кремлём»: колонны Лиги входят в Москву, гарнизон Кремля сдаётся у Спасских ворот,
    звезду на Спасской башне сменяет чёрное знамя Лиги, осколки России сходятся в одно."""
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    floor = h - 2            # линия мостовой; под ней строка подписи
    road = floor - 1         # по ней идут люди
    base = floor - 2         # нижний ряд стены и башни
    cx = w // 2

    def snow(k=0.012):
        for i in range(int(w * h * k)):
            sx = (i * 37 + int(t * 6) * (i % 3 + 1)) % w
            sy = (i * 11 + int(t * 8)) % (h - 1)
            c.plot(sx, sy, "·" if i % 3 else "*", "d")

    def ground():
        for x in range(w):
            c.plot(x, floor, "▀", "d")

    def caption(s, st="b"):
        c.center(h - 1, s, st)

    def wall():
        """Кремлёвская стена с зубцами «ласточкин хвост»."""
        for x in range(w):
            for y in range(base - 3, base + 1):
                c.plot(x, y, "▓" if (x * 3 + y) % 11 else "▒", "d")
            if x % 3 < 2:
                c.plot(x, base - 4, "▙" if x % 3 == 0 else "▟", "n")

    def tower(star=True):
        """Спасская башня: ворота, часы, ярусы, шатёр. Возвращает строку острия."""
        for y in range(base - 3, base + 1):
            for x in range(cx - 6, cx + 7):
                c.plot(x, y, "█", "n")
        for y in (base, base - 1):                 # проезд Спасских ворот
            for x in range(cx - 1, cx + 2):
                c.plot(x, y, " ", "f")
        c.text(cx - 1, base - 2, "▛▀▜", "n")
        for x in range(cx - 6, cx + 7):            # зубцы над воротным ярусом
            c.plot(x, base - 4, "▙" if (x - cx) % 2 else "▟", "n")
        for y in (base - 6, base - 5):             # ярус с курантами
            for x in range(cx - 4, cx + 5):
                c.plot(x, y, "█", "n")
        c.text(cx - 1, base - 5, "(◷)", "b")
        for x in range(cx - 3, cx + 4):            # ярус со звонницей
            c.plot(x, base - 7, "▐" if (x - cx) % 2 else "█", "n")
        c.text(cx - 2, base - 8, "▟███▙", "n")     # шатёр
        c.text(cx - 1, base - 9, "▐█▌", "n")
        c.plot(cx, base - 10, "▲", "n")
        if star:
            c.plot(cx, base - 11, "★", "b")
        return base - 10

    def black_flag(x0, y0, width, height=4, emblem=True):
        """Чёрное полотнище: пустое (чёрное) поле в яркой кромке, по центру звезда Лиги."""
        for i in range(width):
            dy = 0
            for r in range(height):
                if r == 0:
                    ch = "▛" if i == 0 else ("▜" if i == width - 1 else "▀")
                elif r == height - 1:
                    ch = "▙" if i == 0 else ("▟" if i == width - 1 else "▄")
                else:
                    ch = "▌" if i == 0 else ("▐" if i == width - 1 else " ")
                c.plot(x0 + i, y0 + r + dy, ch, "b" if ch != " " else "f")
            if emblem and width >= 9 and i == width // 2:
                c.plot(x0 + i, y0 + height // 2 + dy, "★", "b")
                c.plot(x0 + i - 1, y0 + height // 2 + dy, " ", "f")
                c.plot(x0 + i + 1, y0 + height // 2 + dy, " ", "f")

    if t < 3.4:   # сцена 1: колонны Лиги с чёрными знамёнами входят в Москву сквозь метель
        sky = random.Random(7)
        for x in range(w):                          # низкий силуэт разрушенного города на горизонте
            for y in range(road - 4 - sky.choice((0, 0, 1, 1, 2, 3)), road - 3):
                c.plot(x, y, "▓", "f")
        snow()
        ground()
        for row, st in ((0, "b"), (2, "n")):
            y = road - row
            speed = 9 - row * 2
            for k in range(30):
                x = int((k * 6 + row * 3 + t * speed) % (w + 12)) - 6
                c.plot(x, y, "╿", st)
                if row == 0 and k % 6 == 3:          # знаменосец: маленькое чёрное знамя
                    for yy in range(y - 3, y):
                        c.plot(x, yy, "│", st)
                    c.text(x + 1, y - 3, "▛▀▀▜", st)
                    c.text(x + 1, y - 2, "▙▄▄▟", st)
        big_text(c, 1, "МОСКВА", "b" if int(t * 2) % 2 else "n")
        c.center(7, "  МЕТЕЛЬ. ЧЁРНАЯ ЛИГА ВХОДИТ В СТАРУЮ СТОЛИЦУ  ", "b")
        return c

    if t < 7.0:   # сцена 2: штурм у Спасских ворот, затем гарнизон выходит с поднятыми руками
        tt = t - 3.4
        fire = tt < 2.0
        c.ox = rng.randint(-1, 1) if fire and rng.random() < 0.5 else 0
        wall()
        tower(star=True)
        ground()
        if fire:
            for _ in range(5):
                _blast(c, rng.randrange(w), base - 5 - rng.randrange(4), 1 + rng.random() * 2, rng)
            for k in range(8):                      # трассеры летят от позиций Лиги к стене
                x = int((k * 17 + tt * 60) % (cx - 8))
                c.text(x, base - 6 - k % 3, "--", "b")
                c.text(w - 2 - x, base - 7 - k % 2, "--", "b")
            for k in range(w // 6):
                c.plot(k * 6 + 2, road, "╿", "n")
            caption("ПОСЛЕДНИЙ БОЙ У КРЕМЛЁВСКОЙ СТЕНЫ", "b" if int(t * 3) % 2 else "n")
        else:
            out = min(12, int((tt - 2.0) * 7) + 1)
            for k in range(out):                    # пленные расходятся от ворот, оружие остаётся в куче
                side = -1 if k % 2 else 1
                dist = 3 + int((tt - 2.0 - k / 7) * 9) + k
                x = cx + side * dist
                c.plot(x, road, "Ψ", "b")
                if k == 0:
                    c.plot(x, road - 1, "⚐", "b")
            for k in range(min(out, 6)):
                c.plot(cx - 2 + k, road, "/", "n")
            for k in range(6):                      # бойцы Лиги по краям
                c.plot(3 + k * 2, road, "╿", "n")
                c.plot(w - 4 - k * 2, road, "╿", "n")
            caption("ГАРНИЗОН КРЕМЛЯ СКЛАДЫВАЕТ ОРУЖИЕ", "b" if int(t * 3) % 2 else "n")
        snow(0.006)
        return c

    if t < 11.0:  # сцена 3: звезда падает, над Спасской башней разворачивается чёрное знамя, бьют колокола
        tt = t - 7.0
        wall()
        tip = tower(star=False)
        ground()
        for k in range(3):                          # волны колокольного звона от курантов
            rad = (tt * 9 + k * 6) % 20
            for a in range(0, 360, 12):
                px = cx + 2 * rad * math.cos(math.radians(a))
                py = base - 5 + rad * math.sin(math.radians(a)) * 0.6
                if abs(px - cx) > 7 or py < base - 11:     # не рисовать поверх башни
                    c.plot(px, py, "·", "d")
        if tt < 0.9:                                 # старая звезда сорвана и падает
            c.plot(cx + int(tt * 6), tip - 1 + int(tt * tt * 12), "★" if tt < 0.5 else "☆", "b" if tt < 0.5 else "d")
        top = max(0, tip - 6)
        grow = min(1.0, max(0.0, (tt - 0.7) / 0.6))
        for y in range(int(tip - 1 - (tip - 1 - top) * grow), tip):
            c.plot(cx, y, "│", "b")
        unfurl = min(1.0, max(0.0, (tt - 1.3) / 1.2))
        if unfurl > 0:
            black_flag(cx + 1, top, max(2, int(22 * unfurl)), emblem=unfurl >= 1.0)
        for k in range(w // 3):                      # толпа у стены поднимает винтовки
            c.plot(k * 3 + (int(t * 4) + k) % 2, road, "╿" if (k + int(t * 3)) % 4 else "ʌ", "n")
        if unfurl >= 1.0:
            caption(cfg.get("caption", ""), "b")
        return c

    # сцена 4: осколки России сходятся в одно — «единая, неделимая, непобедимая»
    tt = t - 11.0
    names = ["КОМИ", "ВЯТКА", "САМАРА", "ДОН", "СВЕРДЛОВСК", "ТЮМЕНЬ", "ГОРЬКИЙ", "КАЗАНЬ", "АРХАНГЕЛЬСК",
             "ПЕРМЬ", "УФА", "ТОМСК"]
    cy = h // 2
    merge = min(1.0, tt / 1.6)
    if merge < 1.0:
        for i, name in enumerate(names):
            a = i / len(names) * math.tau
            r0 = 1.0 - merge
            x = cx + math.cos(a) * (w * 0.42) * r0
            y = cy + math.sin(a) * (h * 0.42) * r0
            for k in range(1, 4):   # след — снаружи, за названием
                c.plot(x + math.cos(a) * (len(name) / 2 + k * 2), y + math.sin(a) * (k + 1), "·", "d")
            c.text(int(x - len(name) / 2), int(y), name, "b")
        c.plot(cx, cy, "★", "b")
        return c
    for y in range(h - 1):
        for x in range(w):
            if ((x - cx) / 2.2) ** 2 + (y - cy) ** 2 * 2.5 < (h * 0.9) ** 2 and (x + y) % 3 == 0:
                c.plot(x, y, "░", "f")
    big_text(c, 1, "ЕДИНАЯ", "b" if int(t * 3) % 2 else "n")
    words = ["НЕДЕЛИМАЯ", "НЕПОБЕДИМАЯ"]
    shown = [wd for k, wd in enumerate(words) if tt > 1.9 + k * 0.6]
    if shown:
        c.center(8, "  " + "   ★   ".join(shown) + "  ", "b")
    if tt > 3.0:
        c.center(h - 3, "  НАСТУПАЕТ ЭПОХА: «ЕДИНАЯ ЛИГА»  ", "b")
    return c


def purge2(cfg, t, w, h):
    """«Чистка в Политбюро»: заседание, ретушь групповой фотографии, «воронок» у подъезда, список и штамп."""
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    ground = h - 2
    members = 9

    def figure(x, y, st="n", gone=False):
        if gone:
            for dy in range(3):
                c.text(x - 1, y + dy, "░░░", "f")
            return
        c.text(x, y, "●", st)
        c.text(x - 1, y + 1, "▟█▙", st)
        c.text(x - 1, y + 2, "███", st)

    if t < 3.2:   # сцена 1: заседание под портретом
        for x in range(4, w - 4):
            c.plot(x, ground - 2, "▀", "n")
        for x in (6, w - 7):
            for y in range(ground - 1, ground + 1):
                c.plot(x, y, "║", "d")
        c.text(w // 2 - 3, 1, "┌────┐", "d")
        for y in (2, 3, 4):
            c.text(w // 2 - 3, y, "│▓▓▓▓│", "d")
        c.text(w // 2 - 3, 5, "└────┘", "d")
        gap = (w - 20) // members
        for i in range(members):
            figure(10 + i * gap + gap // 2, ground - 5, "n")
        speaker = 10 + (members // 2) * gap + gap // 2
        if int(t * 3) % 2:
            c.text(speaker + 3, ground - 7, "«…заговор…»", "b")
        c.text(2, 1, "ЗАСЕДАНИЕ ПОЛИТБЮРО // " + cfg.get("place", "ВОЛОГДА"), "b")
        return c
    if t < 6.6:   # сцена 2: групповой снимок, лица вымарываются
        tt = t - 3.2
        x0, x1, y0, y1 = 6, w - 7, 2, ground
        for x in range(x0, x1 + 1):
            c.plot(x, y0, "═", "n")
            c.plot(x, y1, "═", "n")
        for y in range(y0, y1 + 1):
            c.plot(x0, y, "║", "n")
            c.plot(x1, y, "║", "n")
        gap = (x1 - x0 - 6) // members
        order = [2, 6, 4, 8, 1]
        gone = order[:int(tt / 0.6)]
        for i in range(members):
            x = x0 + 4 + i * gap + gap // 2
            figure(x, y1 - 6, "n", gone=i in gone)
        if len(gone) < len(order):   # перо ретушёра над следующим лицом
            nx = x0 + 4 + order[len(gone)] * gap + gap // 2
            ph = (tt % 0.6) / 0.6
            c.text(nx - 2 + int(ph * 4), y1 - 7 - int(abs(math.sin(ph * 6)) * 2), "✎", "b")
        _grain(c, rng, 0.02)
        c.center(y0 + 1, "АРХИВ · ФОТОГРАФИЯ ИСПРАВЛЕНА", "b" if int(t * 3) % 2 else "n")
        return c
    if t < 9.8:   # сцена 3: «воронок» у подъезда, окна гаснут
        tt = t - 6.6
        for x in range(w):
            c.plot(x, ground, "▀", "d")
        bx0, bx1, btop = w // 2 - 30, w // 2 + 30, 3
        for y in range(btop, ground):
            for x in range(bx0, bx1):
                c.plot(x, y, "▓", "f")
        k = 0
        for y in range(btop + 1, ground - 3, 2):
            for x in range(bx0 + 3, bx1 - 3, 6):
                lit = k * 0.09 > tt
                c.text(x, y, "██" if lit else "  ", "b" if lit else "f")
                k += 1
        car = ["  ▄▄▄▄▄▄▄▄", "▐██████████▌", " ◦◦     ◦◦ "]
        cx = int(min(bx0 + 10, -14 + tt * 40))
        for i, row in enumerate(car):
            c.text(cx, ground - 3 + i, row, "n")
        for r in range(1, 14):   # фары
            c.plot(cx + 12 + r, ground - 2 + (r % 3 == 0), "─" if r % 2 else "-", "d" if r > 6 else "n")
        if tt > 1.6:
            c.center(1, "ЧЁРНЫЙ ВОРОНОК · " + time_str(tt), "b")
        return c
    # сцена 4: список с именами, штамп и «ЧИСТКА»
    tt = t - 9.8
    names = ["ЗАМ. ПРЕДСЕДАТЕЛЯ ……… АРЕСТОВАН", "НАРКОМ ПРОДОВОЛЬСТВИЯ … АРЕСТОВАН",
             "КОМАНДАРМ 2-Й АРМИИ …… АРЕСТОВАН", "СЕКРЕТАРЬ ВОЛОГОДСКИЙ … АРЕСТОВАН",
             "НАЧАЛЬНИК РАЗВЕДКИ ……… ИСЧЕЗ"]
    c.text(4, 1, "СПИСОК № 7 · СОВЕРШЕННО СЕКРЕТНО", "b")
    n = int(tt * 40)
    for i, line in enumerate(names):
        c.text(6, 3 + i, line[:max(0, n - i * 14)], "n")
    if tt > 1.6:
        c.ox = rng.randint(-1, 1) if tt < 1.9 else 0
        big_text(c, h - 7, "ЧИСТКА", "b" if int(t * 3) % 2 else "n")
    return c


def time_str(tt):
    return f"03:{int(10 + tt * 7):02d}"


def collapse(cfg, t, w, h):
    """«Ядерный коллапс»: три вспышки над картой огней, гаснущая энергосистема, ядерная зима, тишина в эфире."""
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    ground = h - 2
    cities = random.Random(5)
    lights = [(cities.randrange(2, w - 2), cities.randrange(3, h - 2)) for _ in range(140)]
    if t < 3.4:   # сцена 1: огни городов и три удара
        hits = [(w // 4, h // 2), (w // 2 + 10, h // 3), (3 * w // 4, h // 2 + 3)]
        n = min(3, int(t / 1.0))
        for x, y in lights:
            dead = any(((x - hx) / 2) ** 2 + (y - hy) ** 2 < (5 + 3 * k) ** 2 for k, (hx, hy) in enumerate(hits[:n]))
            if not dead:
                c.plot(x, y, "∙" if (x + y + int(t * 4)) % 5 else "•", "n")
        for k in range(n):
            hx, hy = hits[k]
            age = t - (k + 1) * 1.0
            if age < 0.25:
                c.fill("█", "i")
            r = 2 + min(age, 1.5) * 9
            for ring in (r, r * 0.6):   # ударная волна
                for ang in range(0, 360, 8):
                    c.plot(hx + 2 * ring * math.cos(math.radians(ang)), hy + ring * math.sin(math.radians(ang)) * 0.55,
                           rng.choice("░▒*"), "b" if ring == r else "n")
            for dy in range(-1, 2):   # огненный шар
                c.text(hx - 3, hy + dy, "▓███▓" if dy == 0 else " ▓▓▓ ", "b")
        c.text(2, 1, f"УДАР № {max(1, n)}", "b")
        c.text(w - 22, 1, "НЕОБРАТИМО" if n >= 3 else "ЭСКАЛАЦИЯ", "b" if int(t * 4) % 2 else "n")
        return c
    if t < 6.8:   # сцена 2: энергосистема и связь рушатся
        tt = t - 3.4
        alive = max(0.0, 1 - tt / 2.6)
        for i, (x, y) in enumerate(lights):
            if (i * 0.618) % 1 < alive:
                c.plot(x, y, "∙", "d")
        pct = int(alive * 100)
        rows = [f"ЭНЕРГОСИСТЕМА ...... {pct:3d}%", f"ЖЕЛЕЗНЫЕ ДОРОГИ .... {'ВСТАЛИ' if tt > 1.0 else 'СБОИ'}",
                f"СВЯЗЬ С ОБЛАСТЯМИ .. {'ПОТЕРЯНА' if tt > 1.6 else 'ПОМЕХИ'}",
                f"ПРАВИТЕЛЬСТВО ...... {'НЕТ ОТВЕТА' if tt > 2.2 else 'В БУНКЕРЕ'}"]
        bx = w // 2 - 20
        for x in range(bx - 2, bx + 42):
            c.plot(x, 3, "─", "n")
            c.plot(x, 9, "─", "n")
        for i, row in enumerate(rows):
            glitch = "".join(ch if rng.random() > 0.06 * tt else rng.choice("#%&?") for ch in row)
            c.text(bx, 4 + i + (i > 0), glitch[:40], "b" if i == 0 else "n")
        return c
    if t < 10.2:   # сцена 3: ядерная зима
        tt = t - 6.8
        _skyline(c, 11, ground, ruined=True)
        sun = max(0.0, 1 - tt / 2.5)
        for a in range(0, 360, 15):
            r = 3
            c.plot(w - 20 + 2 * r * math.cos(math.radians(a)), 5 + r * math.sin(math.radians(a)) * 0.6,
                   "○" if sun > 0.3 else "·", "n" if sun > 0.3 else "f")
        for i in range(int(w * h * 0.03 * (1 + tt))):
            x = (i * 53 + int(t * 7) * (i % 4 + 1)) % w
            y = (i * 17 + int(t * 9)) % (h - 1)
            c.plot(x, y, rng.choice("·,'░"), "d")
        c.center(1, "ПЕПЕЛ ЗАКРЫЛ СОЛНЦЕ · ТЕМПЕРАТУРА ПАДАЕТ", "b")
        return c
    # сцена 4: «КОЛЛАПС» и тишина в эфире
    tt = t - 10.2
    for y in range(h - 1):
        for x in range(w):
            if rng.random() < 0.18:
                c.plot(x, y, rng.choice(" .:░"), "f")
    big_text(c, h // 2 - 4, "КОЛЛАПС", "b" if int(t * 3) % 2 else "n")
    if tt > 1.2:
        c.center(h - 3, "…говорит… кто-нибудь слышит… приём…"[:int((tt - 1.2) * 18)], "d")
    return c


def static(cfg, t, w, h):
    c = Canvas(w, h)
    rng = random.Random(int(t * 12))
    fade = min(1.0, t / 4)
    for y in range(h - 1):
        for x in range(w):
            if rng.random() < 0.55 * (1 - fade * 0.7):
                c.plot(x, y, rng.choice(" .:░▒"), rng.choice("fd"))
    box = " " + cfg.get("caption", "") + " "
    c.center(h // 2 - 1, "╔" + "═" * len(box) + "╗", "n")
    c.center(h // 2, "║" + box + "║", "b")
    c.center(h // 2 + 1, "╚" + "═" * len(box) + "╝", "n")
    return c


STYLES = {"newsreel": newsreel, "war": war, "nuke": nuke, "launch": launch,
          "ash": ash, "flag": flag, "static": static, "purge": purge, "night_clash": night_clash,
          "war_start": war_start, "launch2": launch2, "strike": strike, "summit_death": summit_death, "kremlin": kremlin, "purge2": purge2, "collapse": collapse}


def frame(cfg, t, w, h):
    return STYLES.get(cfg.get("style"), static)(cfg, t, w, h)
