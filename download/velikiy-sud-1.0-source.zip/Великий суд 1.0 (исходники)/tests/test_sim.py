"""Безголовая проверка: валидность данных и прогон партий с автоигроком.

Запуск:  python -m tests.test_sim   (из корня проекта)
"""
import collections
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from game import registry  # noqa: E402
from game.core import Game, load_json  # noqa: E402
from game.events.engine import load_events  # noqa: E402


def _walk_refs(obj, out):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k == "fire":
                out.add(v)
            elif k == "schedule":
                out.add(v["event"])
            elif k == "call":
                assert v in registry.ACTIONS, f"нет действия {v}"
            elif k == "func" and isinstance(v, (str, list)):
                name = v if isinstance(v, str) else v[0]
                assert name in registry.PREDICATES or name in registry.CHANCES, f"нет функции {name}"
            _walk_refs(v, out)
    elif isinstance(obj, list):
        for x in obj:
            _walk_refs(x, out)


def test_data():
    Game("burgundy", seed=1)  # регистрирует механики
    events = load_events()
    refs = set()
    _walk_refs(list(events.values()), refs)
    for t in load_json("territories.json").values():
        for terr in t["territories"]:
            for k in ("on_action_event", "on_military_event", "final_event"):
                if k in terr:
                    refs.add(terr[k])
    code_refs = {"EVENT_W01", "EVENT_W03", "SUPEREVENT_WAR", "SUPEREVENT_F02", "SUPEREVENT_F_RET",
                 "SUPEREVENT_F03", "ENDING_VICTORY", "ENDING_DEFEAT", "ENDING_ULTIMATUM",
                 "ENDING_ARMISTICE", "EVENT_F01"}
    missing = (refs | code_refs) - set(events)
    assert not missing, f"ссылки на несуществующие ивенты: {missing}"
    media = load_json("media.json")
    for ev in events.values():
        if ev.get("superevent"):
            assert ev.get("media") in media, f"{ev['id']}: нет медиа {ev.get('media')}"
        for opt in ev.get("options", []):
            assert "text" in opt
    print(f"данные ок: {len(events)} ивентов")


def autoplay(side, seed, aggressive=0.5, max_days=1600, verbose=False):
    rnd = random.Random(seed * 7 + 1)
    g = Game(side, seed=seed)
    st = g.state
    seen = collections.Counter()
    while not st.ending and st.day < max_days:
        while g.engine.queue and not st.ending:
            inst = g.engine.current()
            seen[inst.id] += 1
            opts = [o for o in inst.options(st) if o[2]]
            assert opts, f"{inst.id}: нет доступных вариантов"
            g.engine.choose(rnd.choice(opts)[0])
        if st.ending:
            break
        # случайные действия игрока
        if rnd.random() < aggressive:
            tab = rnd.choice([t for t in g.tabs() if t not in ("map", "log")])
            view = g.view(tab)
            acts = [a for it in view.items for a in it.actions if a.enabled]
            if acts:
                rnd.choice(acts).fn()
        g.tick()
    return st, seen


def test_autoplay(n=12):
    endings = collections.Counter()
    all_seen = collections.Counter()
    for side in ("burgundy", "league"):
        for seed in range(n):
            st, seen = autoplay(side, seed, aggressive=0.3 + 0.05 * seed)
            endings[(side, st.ending)] += 1
            all_seen.update(seen)
            # сохранение/загрузка не ломается
            path = os.path.join("/tmp", f"velikiy_sud_test_{side}.json")
            st.save(path)
            Game.load(path)
    print("концовки:", dict(endings))
    print("ивенты:", ", ".join(f"{k}:{v}" for k, v in sorted(all_seen.items())))


PRIORITY = ("Подкуп", "Ввести войска СС", "Военная операция", "Переговоры", "Пропаганда", "Потребовать", "Вступить")


def _greedy_unification_day(side, seed, max_days=500):
    """Жадный бот: каждый день начинает лучшую доступную операцию. Возвращает день взятия столицы или None."""
    rnd = random.Random(seed)
    g = Game(side, seed=seed)
    st = g.state
    tab = "unification" if side == "league" else "absorption"
    while not st.ending and st.day < max_days:
        while g.engine.queue and not st.ending:
            g.engine.choose(rnd.choice([o for o in g.engine.current().options(st) if o[2]])[0])
        if tab in g.tabs():
            acts = [a for it in g.view(tab).items for a in it.actions
                    if a.enabled and a.label.startswith(PRIORITY)]
            if acts:
                acts.sort(key=lambda a: [a.label.startswith(p) for p in PRIORITY].index(True))
                acts[0].fn()
        if any(t.get("final") and t["status"] in ("annexed", "puppet") for t in st.territories.values()):
            return st.day
        g.tick()
    return None


def test_balance():
    """Числа баланса: объединение не берётся подкупом за год, казна без дел не пухнет."""
    for seed in range(3):
        day = _greedy_unification_day("league", seed)
        assert day is None, f"Лига объединила Россию за {day} дн. — подкуп/переговоры снова слишком сильны"
    for side in ("burgundy", "league"):
        g = Game(side, seed=1)
        st = g.state
        while st.day < 365 and not st.ending:
            while g.engine.queue:
                g.engine.choose([o for o in g.engine.current().options(st) if o[2]][-1][0])
            g.tick()
        assert st.get("treasury") < 1200, f"{side}: казна {st.get('treasury'):.0f} за год без действий"
    print("баланс ок")


if __name__ == "__main__":
    test_data()
    test_balance()
    test_autoplay()
    print("OK")
