"""Экраны: загрузка и выбор стороны, основная игра, эпилог."""
import datetime
import os

import pygame

from .. import config, epilogue, i18n, pixelmap, settings
from ..core import TAB_NAMES, Game, load_json
from ..mechanics import army, war
from ..media.player import SuperEventPlayer
from . import emblems, mapview
from .terminal import wrap
from ..i18n import tr

SAVE_PATH = os.path.join(config.SAVE_DIR, "quicksave.json")

BANNER_FONT = {
    "Н": ["█   █", "█   █", "█████", "█   █", "█   █"],
    "О": [" ███ ", "█   █", "█   █", "█   █", " ███ "],
    "В": ["████ ", "█   █", "████ ", "█   █", "████ "],
    "Ы": ["█    █", "█    █", "███  █", "█  █ █", "███  █"],
    "Й": [" ▀▀▀ ", "█  ██", "█ █ █", "██  █", "█   █"],
    "П": ["█████", "█   █", "█   █", "█   █", "█   █"],
    "Р": ["████ ", "█   █", "████ ", "█    ", "█    "],
    "Я": [" ████", "█   █", " ████", "  █ █", " █  █"],
    "Д": [" ███ ", " █ █ ", " █ █ ", "█████", "█   █"],
    "К": ["█   █", "█  █ ", "███  ", "█  █ ", "█   █"],
    "Е": ["█████", "█    ", "████ ", "█    ", "█████"],
    "Л": [" ████", " █  █", " █  █", " █  █", "█   █"],
    "И": ["█   █", "█  ██", "█ █ █", "██  █", "█   █"],
    "С": [" ████", "█    ", "█    ", "█    ", " ████"],
    "У": ["█   █", "█   █", " ████", "    █", " ███ "],
    " ": ["   ", "   ", "   ", "   ", "   "],
}

# латиница для английской версии: те же 5x5, «#» -> «█»
BANNER_FONT.update({k: [r.replace('#', '█').replace('.', ' ') for r in v] for k, v in {
    "A": ['.###.', '#...#', '#####', '#...#', '#...#'],
    "B": ['####.', '#...#', '####.', '#...#', '####.'],
    "C": ['.####', '#....', '#....', '#....', '.####'],
    "D": ['####.', '#...#', '#...#', '#...#', '####.'],
    "E": ['#####', '#....', '####.', '#....', '#####'],
    "F": ['#####', '#....', '####.', '#....', '#....'],
    "G": ['.####', '#....', '#..##', '#...#', '.###.'],
    "H": ['#...#', '#...#', '#####', '#...#', '#...#'],
    "I": ['.###.', '..#..', '..#..', '..#..', '.###.'],
    "J": ['..###', '...#.', '...#.', '#..#.', '.##..'],
    "K": ['#...#', '#..#.', '###..', '#..#.', '#...#'],
    "L": ['#....', '#....', '#....', '#....', '#####'],
    "M": ['#...#', '##.##', '#.#.#', '#...#', '#...#'],
    "N": ['#...#', '##..#', '#.#.#', '#..##', '#...#'],
    "O": ['.###.', '#...#', '#...#', '#...#', '.###.'],
    "P": ['####.', '#...#', '####.', '#....', '#....'],
    "Q": ['.###.', '#...#', '#.#.#', '#..#.', '.##.#'],
    "R": ['####.', '#...#', '####.', '#..#.', '#...#'],
    "S": ['.####', '#....', '.###.', '....#', '####.'],
    "T": ['#####', '..#..', '..#..', '..#..', '..#..'],
    "U": ['#...#', '#...#', '#...#', '#...#', '.###.'],
    "V": ['#...#', '#...#', '#...#', '.#.#.', '..#..'],
    "W": ['#...#', '#...#', '#.#.#', '##.##', '#...#'],
    "X": ['#...#', '.#.#.', '..#..', '.#.#.', '#...#'],
    "Y": ['#...#', '.#.#.', '..#..', '..#..', '..#..'],
    "Z": ['#####', '...#.', '..#..', '.#...', '#####'],
}.items()})


def banner(text):
    rows = [""] * 5
    for ch in text:
        g = BANNER_FONT.get(ch, BANNER_FONT[" "])
        for i in range(5):
            rows[i] += g[i] + " "
    return rows


class Screen:
    def __init__(self, app):
        self.app = app
        self.hits = []   # [(pygame.Rect, callback)] — зоны клика текущего кадра

    def hit(self, x, y, w, h, fn):
        self.hits.append((self.app.term.rect(x, y, w, h), fn))

    def click(self, pos):
        for rect, fn in reversed(self.hits):
            if rect.collidepoint(pos):
                fn()
                return True
        return False

    def handle(self, event):
        pass

    def update(self, dt):
        pass

    def draw(self, term):
        pass


# =====================================================================
class BootScreen(Screen):
    BOOT = [
        tr("ТЕРМИНАЛ «ВЕЛИКИЙ СУД»  мод. 1962"),
        tr("ПРОВЕРКА ПАМЯТИ ............ 640К  OK"),
        tr("ШИФРАТОР «ЭНИГМА-М» ........ ПОДКЛЮЧЁН"),
        tr("РАДИОКАНАЛ ................. ПОМЕХИ 34%"),
        tr("ЗАГРУЗКА СВОДОК РАЗВЕДКИ ... OK"),
        "",
        tr("МИР ПОСЛЕ ВОЙНЫ. ГЕРМАНИЯ ПОБЕДИЛА. ЕВРОПА РАСКОЛОТА."),
        tr("ВЫБЕРИТЕ ДЕРЖАВУ, КОТОРОЙ ВЫ БУДЕТЕ ПРАВИТЬ."),
    ]

    def __init__(self, app, skip_boot=False):
        super().__init__(app)
        self.t = 99.0 if skip_boot else 0.0
        self.scenario = load_json("scenario.json")
        self.sides = ["burgundy", "league"]
        self.sel = 0
        self.msg = ""

    @property
    def booting(self):
        return self.t < 3.2

    def handle(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.booting:
                self.t = 99
            else:
                self.click(event.pos)
            return
        if event.type != pygame.KEYDOWN:
            return
        if self.booting:
            self.t = 99
            return
        k = event.key
        if k in (pygame.K_UP, pygame.K_w, pygame.K_LEFT):
            self.sel = (self.sel - 1) % 2
            self.app.audio.play("ui_click")
        elif k in (pygame.K_DOWN, pygame.K_s, pygame.K_RIGHT, pygame.K_TAB):
            self.sel = (self.sel + 1) % 2
            self.app.audio.play("ui_click")
        elif k in (pygame.K_1, pygame.K_KP1):
            self.sel = 0
        elif k in (pygame.K_2, pygame.K_KP2):
            self.sel = 1
        elif k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.start()
        elif k == pygame.K_F9:
            self.load()
        elif k == pygame.K_c:
            settings.next_theme()
        elif k == pygame.K_l:
            if not i18n.switch_and_restart(self.app):
                self.msg = tr("Язык сменится после перезапуска игры.")
        elif k in (pygame.K_t, pygame.K_b):
            emblems.open_link(config.LINKS[0 if k == pygame.K_t else 1][3])
        elif k == pygame.K_ESCAPE:
            self.app.running = False

    def start(self):
        self.app.audio.play("ui_beep")
        self.app.set_screen(GameScreen(self.app, Game(self.sides[self.sel])))

    def load(self):
        if not os.path.exists(SAVE_PATH):
            self.msg = tr("Сохранение не найдено.")
            return
        try:
            self.app.set_screen(GameScreen(self.app, Game.load(SAVE_PATH)))
        except Exception as e:  # повреждённый файл
            self.msg = tr("Ошибка загрузки: {0}").format(e)

    def update(self, dt):
        self.t += dt

    def draw(self, term):
        self.hits = []
        term.clear()
        if self.booting:
            n = int(self.t / 0.35)
            for i, line in enumerate(self.BOOT[:n]):
                term.put(4, 3 + i, line, "n")
            if n < len(self.BOOT):
                part = self.BOOT[n][: int((self.t % 0.35) / 0.35 * len(self.BOOT[n]))]
                term.put(4, 3 + n, part + "█", "b")
            term.put(4, term.rows - 2, tr("[любая клавиша — пропустить]"), "d")
            return
        rows = banner(tr("ВЕЛИКИЙ СУД"))
        bx = (term.cols - len(rows[0])) // 2
        for i, r in enumerate(rows):
            term.put(bx, 1 + i, r, "b")
        sub = tr("ХРОНИКА ПОСЛЕДНИХ ДНЕЙ ЕВРОПЫ  //  1962  //  ВЕРСИЯ {0}").format(config.VERSION)
        term.put((term.cols - len(sub)) // 2, 7, sub, "n")

        half = (term.cols - 6) // 2
        top, h = 8, 31
        for i, key in enumerate(self.sides):
            side = self.scenario["sides"][key]
            sel = i == self.sel
            x = 2 + i * (half + 2)
            main = "n" if sel else "d"
            term.box(x, top, half, h, f"[{i + 1}] {side['name'].upper()}", "b" if sel else "d",
                     double=sel, title_style="b" if sel else "d")
            self.hit(x, top, half, h, lambda i=i: self._click_side(i))
            with term.clip(x + 1, top + 1, half - 2, h - 2):
                art = emblems.EMBLEMS[key]()
                img = emblems.image(key, 15 * term.ch - 10, config.BRIGHT if sel else config.DIM)
                if img is not None:
                    area = term.rect(x + 1, top + 1, half - 2, len(art))
                    term.surface.blit(img, img.get_rect(center=area.center))
                else:
                    ax = x + (half - len(art[0])) // 2
                    for r, line in enumerate(art):
                        term.put(ax, top + 1 + r, line, "b" if sel else "d")
                name = f"{'▶ ' if sel else ''}{side['name'].upper()}{' ◀' if sel else ''}"
                term.put(x + (half - len(name)) // 2, top + 1 + len(art), name, "i" if sel else "d")
                y = top + 3 + len(art)
                lines = []
                for para in side["lore"]:
                    if para:
                        lines += [(ln, "b" if para.startswith(tr("СТИЛЬ")) else main) for ln in wrap(para, half - 6)]
                lines.append((tr("Столица: {0}").format(side['capital']), "d"))
                for ln, stl in lines[: top + h - 1 - y]:
                    term.put(x + 3, y, ln, stl)
                    y += 1

        lw = emblems.links_width()
        emblems.draw_links(self, term, (term.cols - lw) // 2, top + h, "b")
        term.put(4, top + h + 1, tr("←→ выбор стороны   ENTER начать   F9 загрузить   C цвет   ESC выход")
                 + "   L " + i18n.LANGS[i18n.other_lang()].upper(), "d")
        if self.msg:
            term.put(4, top + h + 2, self.msg, "b")
        blink = int(self.t * 2) % 2 == 0
        term.put(term.cols - 30, top + h + 1, tr("> ГОТОВ К ПРИЁМУ КОМАНД") + ("█" if blink else ""), "b")

    def _click_side(self, i):
        if self.sel == i:
            self.start()
        self.sel = i


# =====================================================================
class GameScreen(Screen):
    TOP_H = 5
    SIDE_W = 26
    PANEL_COLLAPSED = 4
    PANEL_EXPANDED = 19

    def __init__(self, app, game):
        super().__init__(app)
        self.game = game
        self.paused = True
        self.speed = config.DEFAULT_SPEED
        self.digit_armed = False
        self.acc = 0.0
        self.tab = "map"
        self.cursor = {}       # вкладка -> выбранная строка
        self.map_zoom = 1.5    # карта Европы: масштаб, центр (долгота, широта), окно в пикселях
        self.map_center = [22.0, 50.0]
        self.map_rect = None
        self.map_drag = None
        self.action_sel = 0
        self.scroll = {}       # вкладка -> прокрутка
        self.opt_sel = 0
        self.digit_armed = False
        self.player = SuperEventPlayer(app.audio)
        self.playing_for = None   # EventInstance, для которого идёт видео
        self.played = set()       # id() инстансов, для которых видео уже показано
        self.menu_open = False
        self.flash = ""
        self.flash_t = 0.0
        self.last_event_seen = None
        self.endgame_delay = None
        self.clock = 0.0          # секунды на экране: по ним летят ракеты
        self.trail_start = {}     # номер следа -> время старта ракеты
        self.trails_seen = len(game.state.vars.get("nuke_trails", []))   # старые следы из сохранения — без полёта
        self._trail_cache = None

    # ---------- состояние ----------
    @property
    def state(self):
        return self.game.state

    def current_event(self):
        return self.game.engine.current()

    def blocking(self):
        return self.current_event() is not None or self.player.active and self.playing_for is not None

    def notify(self, text):
        self.flash = text
        self.flash_t = 3.0

    # ---------- ввод ----------
    def handle(self, event):
        if self._map_mouse(event):
            return
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if self.playing_for is not None and not self.player.finished:
                    if self.player.skippable:
                        self.player.skip()
                    return
                self.click(event.pos)
            elif event.button in (4, 5):
                self._move_cursor(-1 if event.button == 4 else 1)
            return
        if event.type != pygame.KEYDOWN:
            return
        k = event.key
        # Видео суперивента блокирует интерфейс
        if self.playing_for is not None and not self.player.finished:
            if k in (pygame.K_ESCAPE, pygame.K_SPACE, pygame.K_RETURN) and self.player.skippable:
                self.player.skip()
            return
        if self.menu_open:
            self._menu_key(k)
            return
        ev = self.current_event()
        if ev is not None:
            self._event_key(k, ev)
            return
        self._game_key(event)

    # ---------- масштаб и сдвиг карты Европы ----------
    MAP_SPAN = (73.0, 45.5)     # градусов по долготе и широте при масштабе 1

    def map_bounds(self):
        lon, lat = self.map_center
        sw, sh = self.MAP_SPAN[0] / self.map_zoom, self.MAP_SPAN[1] / self.map_zoom
        return (lon - sw / 2, lon + sw / 2, lat - sh / 2, lat + sh / 2)

    def _clamp_map(self):
        self.map_zoom = max(1.0, min(6.0, self.map_zoom))
        self.map_center[0] = max(-12.0, min(70.0, self.map_center[0]))
        self.map_center[1] = max(38.0, min(68.0, self.map_center[1]))

    def zoom_map(self, factor, pos=None):
        """Приблизить/отдалить; точка под курсором остаётся на месте."""
        if pos is not None and self.map_rect is not None and self.map_rect.collidepoint(pos):
            proj = pixelmap.Projection(self.map_bounds(), self.map_rect.size)
            px, py = pos[0] - self.map_rect.x, pos[1] - self.map_rect.y
            lon = proj.lon_c + (px - proj.w / 2) / proj.sx
            lat = proj.lat_c - (py - proj.h / 2) / proj.sy
            old = self.map_zoom
            self.map_zoom *= factor
            self._clamp_map()
            k = old / self.map_zoom
            self.map_center[0] = lon + (self.map_center[0] - lon) * k
            self.map_center[1] = lat + (self.map_center[1] - lat) * k
        else:
            self.map_zoom *= factor
        self._clamp_map()

    def pan_map(self, dx, dy):
        """Сдвиг в долях видимой области."""
        b = self.map_bounds()
        self.map_center[0] += dx * (b[1] - b[0])
        self.map_center[1] += dy * (b[3] - b[2])
        self._clamp_map()

    def _map_mouse(self, event):
        if self.tab != "map" or self.map_rect is None or self.blocking() or self.menu_open:
            self.map_drag = None
            return False
        if event.type == pygame.MOUSEBUTTONDOWN and self.map_rect.collidepoint(event.pos):
            if event.button in (4, 5):
                self.zoom_map(1.25 if event.button == 4 else 0.8, event.pos)
                return True
            if event.button == 1:
                self.map_drag = (event.pos, list(self.map_center))
                return True
        if event.type == pygame.MOUSEMOTION and self.map_drag:
            (x0, y0), (lon0, lat0) = self.map_drag
            proj = pixelmap.Projection(self.map_bounds(), self.map_rect.size)
            self.map_center[0] = lon0 - (event.pos[0] - x0) / proj.sx
            self.map_center[1] = lat0 + (event.pos[1] - y0) / proj.sy
            self._clamp_map()
            return True
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.map_drag:
            self.map_drag = None
            return True
        return False

    def _menu_key(self, k):
        if k in (pygame.K_ESCAPE, pygame.K_1):
            self.menu_open = False
        elif k == pygame.K_2:
            self.save()
            self.menu_open = False
        elif k == pygame.K_3:
            self.load()
            self.menu_open = False
        elif k == pygame.K_4:
            self.app.set_screen(BootScreen(self.app, skip_boot=True))
        elif k == pygame.K_5:
            settings.next_theme()
        elif k == pygame.K_6:
            self.app.running = False
        elif k in (pygame.K_7, pygame.K_8):
            emblems.open_link(config.LINKS[k - pygame.K_7][3])

    def _event_key(self, k, ev):
        opts = ev.options(self.state)
        digit = {pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2, pygame.K_4: 3,
                 pygame.K_KP1: 0, pygame.K_KP2: 1, pygame.K_KP3: 2, pygame.K_KP4: 3}.get(k)
        if digit is not None and digit < len(opts):
            # цифра только выделяет вариант (её легко нажать, меняя скорость); повтор той же цифры или ENTER — выбор
            if self.opt_sel == digit and self.digit_armed:
                self.choose_option(opts[digit])
            else:
                self.opt_sel = digit
                self.digit_armed = True
                self.app.audio.play("ui_click")
        elif k in (pygame.K_UP, pygame.K_w):
            self.digit_armed = False
            self.opt_sel = (self.opt_sel - 1) % len(opts)
            self.app.audio.play("ui_click")
        elif k in (pygame.K_DOWN, pygame.K_s):
            self.opt_sel = (self.opt_sel + 1) % len(opts)
            self.app.audio.play("ui_click")
        elif k in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.choose_option(opts[min(self.opt_sel, len(opts) - 1)])

    def _game_key(self, event):
        k = event.key
        tabs = self.game.tabs()
        if k == pygame.K_SPACE:
            self.paused = not self.paused
        elif k in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
            self.speed = min(5, self.speed + 1)
        elif k in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self.speed = max(1, self.speed - 1)
        elif pygame.K_1 <= k <= pygame.K_5:
            self.speed = k - pygame.K_1 + 1
            self.paused = False
        elif pygame.K_F1 <= k <= pygame.K_F8:
            i = k - pygame.K_F1
            if i < len(tabs):
                self.set_tab(tabs[i])
        elif k == pygame.K_TAB:
            i = tabs.index(self.tab) if self.tab in tabs else 0
            step = -1 if event.mod & pygame.KMOD_SHIFT else 1
            self.set_tab(tabs[(i + step) % len(tabs)])
        elif self.tab == "map" and k in (pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT,
                                         pygame.K_PAGEUP, pygame.K_PAGEDOWN, pygame.K_HOME):
            if k == pygame.K_PAGEUP:
                self.zoom_map(1.25)
            elif k == pygame.K_PAGEDOWN:
                self.zoom_map(0.8)
            elif k == pygame.K_HOME:
                self.map_zoom, self.map_center = 1.5, [22.0, 50.0]
            else:
                dx = {pygame.K_LEFT: -0.15, pygame.K_RIGHT: 0.15}.get(k, 0)
                dy = {pygame.K_UP: 0.15, pygame.K_DOWN: -0.15}.get(k, 0)
                self.pan_map(dx, dy)
        elif k in (pygame.K_UP, pygame.K_w):
            self._move_cursor(-1)
        elif k in (pygame.K_DOWN, pygame.K_s):
            self._move_cursor(1)
        elif k == pygame.K_PAGEUP:
            self._move_cursor(-10)
        elif k == pygame.K_PAGEDOWN:
            self._move_cursor(10)
        elif k in (pygame.K_LEFT, pygame.K_a):
            self.action_sel = max(0, self.action_sel - 1)
        elif k in (pygame.K_RIGHT, pygame.K_d):
            self.action_sel += 1
        elif k in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.run_selected_action()
        elif k == pygame.K_F5:
            self.save()
        elif k == pygame.K_F9:
            self.load()
        elif k == pygame.K_c:
            settings.next_theme()
            self.notify(tr("Цвет экрана: {0}.").format(settings.theme_name()))
        elif k == pygame.K_m:
            self.app.audio.muted = not self.app.audio.muted
            self.notify(tr("Звук выключен") if self.app.audio.muted else tr("Звук включён"))
        elif k == pygame.K_ESCAPE:
            self.menu_open = True
            self.paused = True

    def set_tab(self, tab):
        if tab != self.tab:
            self.tab = tab
            self.action_sel = 0
            self.app.audio.play("ui_click")

    def _move_cursor(self, d):
        if self.tab == "log":
            self.scroll["log"] = max(0, self.scroll.get("log", 0) + d)
            return
        if self.tab == "map":
            return
        n = len(self.game.view(self.tab).items)
        if n:
            self.cursor[self.tab] = max(0, min(n - 1, self.cursor.get(self.tab, 0) + d))
            self.action_sel = 0
            self.app.audio.play("ui_click")

    def run_selected_action(self, idx=None):
        if self.tab in ("map", "log"):
            return
        view = self.game.view(self.tab)
        if not view.items:
            return
        item = view.items[min(self.cursor.get(self.tab, 0), len(view.items) - 1)]
        if not item.actions:
            return
        a = item.actions[min(idx if idx is not None else self.action_sel, len(item.actions) - 1)]
        if a.enabled:
            a.fn()
            self.app.audio.play("ui_beep")
        else:
            self.notify(tr("Недоступно: {0}").format(a.reason))

    def choose_option(self, opt):
        idx, text, ok, hint = opt
        if not ok:
            self.notify(tr("Этот вариант сейчас недоступен."))
            return
        inst = self.game.engine.choose(idx)
        self.app.audio.play("ui_beep")
        self.opt_sel = 0
        self.digit_armed = False
        if inst.superevent:
            self.player.stop()
            self.playing_for = None
        if self.state.ending:
            self.endgame_delay = 0.4

    # ---------- сохранение ----------
    def save(self):
        try:
            self.state.save(SAVE_PATH)
            self.notify(tr("Партия сохранена (F9 — загрузить)."))
        except Exception as e:
            self.notify(tr("Ошибка сохранения: {0}").format(e))

    def load(self):
        if not os.path.exists(SAVE_PATH):
            self.notify(tr("Сохранение не найдено."))
            return
        try:
            self.app.set_screen(GameScreen(self.app, Game.load(SAVE_PATH)))
        except Exception as e:
            self.notify(tr("Ошибка загрузки: {0}").format(e))

    # ---------- время ----------
    def update(self, dt):
        self.clock += dt
        if self.flash_t > 0:
            self.flash_t -= dt
        self._launch_trails()
        if self.endgame_delay is not None:
            self.endgame_delay -= dt
            if self.endgame_delay <= 0:
                self.app.set_screen(EndScreen(self.app, self.game))
            return
        ev = self.current_event()
        if ev is not None:
            if ev is not self.last_event_seen:
                self.last_event_seen = ev
                self.opt_sel = 0
                self.digit_armed = False
                if not ev.superevent:
                    self.app.audio.play("ui_beep")
            if ev.superevent and id(ev) not in self.played:
                self.played.add(id(ev))
                self.playing_for = ev
                self.player.start(ev.media)
        if self.player.active:
            self.player.update(dt)
        if self.blocking() or self.paused or self.menu_open:
            return
        self.acc += dt
        step = config.SPEEDS[self.speed]
        while self.acc >= step and not self.blocking():
            self.acc -= step
            self.game.tick()
        if self.blocking():
            self.acc = 0.0

    # ---------- отрисовка ----------
    def draw(self, term):
        self.hits = []
        term.clear()
        video = self.playing_for is not None and self.player.active
        panel_h = self.PANEL_EXPANDED if video else self.PANEL_COLLAPSED
        main_bottom = term.rows - self.PANEL_COLLAPSED
        self.draw_top(term)
        self.draw_sidebar(term, main_bottom)
        self.draw_center(term, main_bottom)
        self.draw_panel(term, term.rows - panel_h, panel_h, video)
        ev = self.current_event()
        if ev is not None and not (video and not self.player.finished):
            self.draw_event(term, ev, video)
        if self.menu_open:
            self.draw_menu(term)
        if self.flash_t > 0:
            msg = f" {self.flash} "
            term.put((term.cols - len(msg)) // 2, self.TOP_H, msg, "i")

    def draw_top(self, term):
        st = self.state
        side = self.game.side_cfg
        term.box(0, 0, term.cols, self.TOP_H, None, "n", double=True)
        with term.clip(1, 1, term.cols - 2, self.TOP_H - 2):
            self._draw_top_body(term, st, side)

    def _draw_top_body(self, term, st, side):
        if self.paused or self.blocking():
            spd = tr("‖ ПАУЗА") if self.paused else tr("‖ РЕШЕНИЕ")
        else:
            spd = "▶" * self.speed + "▷" * (5 - self.speed)
        term.put(2, 1, f" {side['name'].upper()} ", "i")
        term.put(4 + len(side["name"]), 1, tr("  ДАТА: {0}  (день {1})").format(st.date_str(), st.day), "b")
        term.put(term.cols - 30, 1, tr("ВРЕМЯ: {0}  x{1}").format(spd, self.speed), "b" if not self.paused else "n")
        if st.has_flag("nuke_tested"):
            nuke = tr("ЕСТЬ ({0:.0f} б/г)").format(st.get('warheads'))
        elif st.has_flag("nuke_program"):
            nuke = f"{st.get('nuke_research'):.0f}%"
        else:
            nuke = tr("НЕТ")
        line2 = (tr("СТАБ {0:.0f}%  КАЗНА {1:.0f} ({2:+.1f}/д)  ПРЕСТИЖ {3:.0f}  РАЗВЕДКА {4:.0f}  АРМИЯ {5:.1f}  ☢ {6}  НАПРЯЖ. {7:.0f}  РИСК ЯД.ВОЙНЫ {8:.0f}%").format(st.get('stability'), st.get('treasury'), self.income(), st.get('prestige'), st.get('intel'), army.strength(st), nuke, st.get('tension'), war.nuclear_war_risk(st)))
        badge = self.nuke_badge()
        if badge:
            bx = 6 + len(side["name"]) + len(tr("  ДАТА: {0}  (день {1})").format(st.date_str(), st.day))
            term.put(bx, 1, f" {badge} ", "i" if int(self.clock * 2) % 2 == 0 else "b")
        if len(line2) > term.cols - 4:   # длинные числа в конце игры: ужимаем подписи
            line2 = (line2.replace("  ", " ").replace(tr("РАЗВЕДКА"), tr("РАЗВ."))
                     .replace(tr("ПРЕСТИЖ"), tr("ПРЕСТ.")).replace(tr("РИСК ЯД.ВОЙНЫ"), tr("РИСК")))
        term.put(2, 2, line2, "n", term.cols - 4)
        facs = "   ".join(f"{f['short']} {st.relations[k]:3.0f}" for k, f in side["factions"].items())
        extra = tr("   ДИПЛ.ОЧКИ {0:3.0f}").format(st.get('dip_points'))
        if st.war["active"]:
            extra += tr("   ФРОНТ {0:+.0f}").format(st.war['front'])
        term.put(2, 3, tr("ФРАКЦИИ: ") + facs + extra, "d", term.cols - 4)

    def income(self):
        """Изменение казны за последний день без покупок игрока (для верхней строки)."""
        return self.state.vars.get("treasury_delta", 0.0)

    def nuke_badge(self):
        """Яркая мигающая плашка, когда ядерка требует внимания игрока."""
        st = self.state
        if st.war["active"] and st.get("warheads") > 0 and st.get("bombers") + st.get("missiles") > 0:
            return tr("☢ УДАР ГОТОВ: {0:.0f} Б/Г").format(st.get('warheads'))
        if st.has_flag("enemy_nuke_tested") and not st.has_flag("nuke_tested"):
            return tr("☢ У ВРАГА БОМБА")
        return ""

    def draw_sidebar(self, term, bottom):
        x, y, w, h = 0, self.TOP_H, self.SIDE_W, bottom - self.TOP_H
        term.box(x, y, w, h, tr("РАЗДЕЛЫ"), "n")
        with term.clip(x + 1, y + 1, w - 2, h - 2):
            self._draw_sidebar_body(term, x, y, w, h, bottom)

    def _draw_sidebar_body(self, term, x, y, w, h, bottom):
        tabs = self.game.tabs()
        for i, t in enumerate(tabs):
            label = f"F{i + 1} {TAB_NAMES[t]}"
            style = "i" if t == self.tab else "n"
            if t == "nuclear" and t != self.tab and self.nuke_badge() and int(self.clock * 2) % 2 == 0:
                style = "b"
                label = label.ljust(w - 6) + " !"
            term.put(x + 2, y + 1 + i, label.ljust(w - 4), style, w - 4)
            self.hit(x + 1, y + 1 + i, w - 2, 1, lambda t=t: self.set_tab(t))
        yy = y + 2 + len(tabs)
        term.hline(x + 1, yy, w - 2)
        help_lines = [tr("ПРОБЕЛ  пауза"), tr("1-5 +/- скорость"), tr("↑↓  выбор строки"), tr("←→  выбор действия"),
                      tr("ENTER выполнить"), tr("TAB  след. вкладка"), tr("F5/F9 сохр./загр."), tr("M звук  C цвет"), tr("ESC меню")]
        for i, line in enumerate(help_lines):
            term.put(x + 2, yy + 1 + i, line, "d")
        yy += len(help_lines) + 2
        term.hline(x + 1, yy, w - 2)
        term.put(x + 2, yy, tr(" ПОСЛЕДНЕЕ "), "n")
        lines = []
        for day, text in reversed(self.state.log[-6:]):
            for ln in wrap(text, w - 4):
                lines.append(ln)
            lines.append("")
        for i, ln in enumerate(lines[: bottom - yy - 2]):
            term.put(x + 2, yy + 1 + i, ln, "d")

    # ---------- центральная область ----------
    def draw_center(self, term, bottom):
        x, y = self.SIDE_W, self.TOP_H
        w, h = term.cols - self.SIDE_W, bottom - self.TOP_H
        if self.tab == "map":
            term.box(x, y, w, h, tr("КАРТА ЕВРОПЫ — 1962"), "n")
            with term.clip(x + 1, y + 1, w - 2, h - 2):
                self.draw_europe(term, x + 1, y + 1, w - 2, h - 2)
        elif self.tab == "log":
            term.box(x, y, w, h, tr("ЖУРНАЛ СОБЫТИЙ"), "n")
            with term.clip(x + 1, y + 1, w - 2, h - 2):
                self.draw_log(term, x + 2, y + 1, w - 4, h - 2)
        else:
            view = self.game.view(self.tab)
            term.box(x, y, w, h, view.title, "n")
            with term.clip(x + 1, y + 1, w - 2, h - 2):
                self.draw_view(term, view, x + 2, y + 1, w - 4, h - 2)

    def draw_europe(self, term, x, y, w, h):
        st = self.state
        mh = h - 4
        self.map_rect = term.rect(x, y, w, mh)
        last = getattr(self, "_map_last", None)
        if self.map_drag and last and last[3] == self.map_zoom and last[4] == self.map_rect.size:
            # пока карту тащат мышью — сдвигаем готовую картинку, перерисуем после отпускания
            surf, markers, (lon0, lat0) = last[0], last[1], last[2]
            proj = pixelmap.Projection(self.map_bounds(), self.map_rect.size)
            off = (int((lon0 - self.map_center[0]) * proj.sx), int((self.map_center[1] - lat0) * proj.sy))
            term.surface.fill(pixelmap.SEA, self.map_rect)
            term.surface.set_clip(self.map_rect)
            term.surface.blit(surf, self.map_rect.move(off))
            term.surface.set_clip(None)
        else:
            surf, markers = mapview.build_pixel(self.game, self.map_bounds(), self.map_rect.size, term.font)
            term.surface.blit(surf, self.map_rect)
            self._map_last = (surf, markers, tuple(self.map_center), self.map_zoom, self.map_rect.size)
        self.draw_trails(term)

        ly = y + mh
        term.hline(x, ly, w)
        hint = tr(" ×{0:.1f}  колесо/PgUp/PgDn — масштаб, мышь/стрелки — сдвиг, Home — сброс ").format(self.map_zoom)
        term.put(x + w - len(hint) - 1, ly, hint, "d")
        sides = st.scenario["sides"]
        legend = (tr("█ {0} (вы) — яркая заливка   ╱ {1} — штриховка   ∙ союзники — точки").format(sides[st.side]['short'], sides[st.enemy_side]['short']))
        term.put(x + 1, ly + 1, legend, "n", w - 2)
        if markers:
            leg = "  ".join(f"{m}-{t['name'].split(' (')[0]}" for m, t, _ in markers)
            for i, ln in enumerate(wrap(tr("Цели: ") + leg + tr("   (■ — ваше, × — уничтожено)"), w - 2)[:2]):
                term.put(x + 1, ly + 2 + i, ln, "d")

    # ---------- следы ракет ядерной войны ----------
    TRAIL_FLIGHT = 2.4     # секунд полёта одной ракеты
    TRAIL_STAGGER = 0.05   # ракеты залпа стартуют одна за другой

    def _launch_trails(self):
        """Новые удары: показать карту целиком и запустить полёт. Пока открыто окно события — ждём."""
        trails = self.state.vars.get("nuke_trails", [])
        if len(trails) < self.trails_seen:
            self.trails_seen = len(trails)
        if len(trails) == self.trails_seen or self.blocking():
            return
        new = range(self.trails_seen, len(trails))
        for k, i in enumerate(new):
            self.trail_start[i] = self.clock + 0.3 + k * self.TRAIL_STAGGER
        self.trails_seen = len(trails)
        self.tab = "map"
        self.map_zoom, self.map_center = 1.0, [30.0, 54.0]
        self._clamp_map()

    @staticmethod
    def _arc(p0, p1, bend, steps=32):
        """Баллистическая дуга: квадратичная кривая, выгнутая вверх (к северу на карте)."""
        (x0, y0), (x1, y1) = p0, p1
        d = ((x1 - x0) ** 2 + (y1 - y0) ** 2) ** 0.5
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2 - d * bend
        pts = []
        for i in range(steps + 1):
            t = i / steps
            a, b, c = (1 - t) ** 2, 2 * t * (1 - t), t * t
            pts.append((a * x0 + b * cx + c * x1, a * y0 + b * cy + c * y1))
        return pts

    def draw_trails(self, term):
        trails = self.state.vars.get("nuke_trails")
        if not trails or self.map_rect is None:
            return
        rect = self.map_rect
        proj = pixelmap.Projection(self.map_bounds(), rect.size)
        flying, landed = [], []
        for i, trl in enumerate(trails):
            age = self.clock - self.trail_start.get(i, -99.0)
            (flying if age < self.TRAIL_FLIGHT + 0.9 else landed).append((i, trl, age))
        arcs = {}

        def arc(i, trl):
            if i not in arcs:
                bend = 0.32 + 0.22 * ((i * 37) % 10) / 10
                arcs[i] = self._arc(proj(trl[0], trl[1]), proj(trl[2], trl[3]), bend)
            return arcs[i]

        # осевшие следы — полупрозрачный слой, перерисовывается только при сдвиге карты или новых следах
        key = (self.map_bounds(), rect.size, len(landed), settings.theme())
        if self._trail_cache is None or self._trail_cache[0] != key:
            layer = pygame.Surface(rect.size, pygame.SRCALPHA)
            for i, trl, _ in landed:
                col = (120, 255, 150, 85) if trl[4] == "me" else (255, 170, 70, 95)
                pts = arc(i, trl)
                pygame.draw.aalines(layer, col, False, pts)
                x, y = pts[-1]
                pygame.draw.circle(layer, (230, 255, 230, 150), (int(x), int(y)), 2)
            self._trail_cache = (key, layer)
        surf = term.surface
        old_clip = surf.get_clip()
        surf.set_clip(rect.clip(old_clip) if old_clip else rect)
        surf.blit(self._trail_cache[1], rect)
        # летящие ракеты: хвост растёт к цели, яркая головка, вспышка при попадании
        for i, trl, age in flying:
            if age < 0:
                continue
            pts = [(x + rect.x, y + rect.y) for x, y in arc(i, trl)]
            k = min(1.0, age / self.TRAIL_FLIGHT)
            n = max(2, int(k * (len(pts) - 1)) + 1)
            col = config.BRIGHT if trl[4] == "me" else (255, 185, 90)   # ракеты противника — янтарные
            pygame.draw.aalines(surf, col, False, pts[:n])
            hx, hy = pts[n - 1]
            if k < 1.0:
                pygame.draw.circle(surf, (255, 255, 255), (int(hx), int(hy)), 2)
            else:
                boom = (age - self.TRAIL_FLIGHT) / 0.9
                pygame.draw.circle(surf, (255, 255, 255), (int(hx), int(hy)), max(1, int(3 + 14 * boom)),
                                   max(1, int(3 * (1 - boom))))
        surf.set_clip(old_clip)

    def draw_log(self, term, x, y, w, h):
        lines = []
        for day, text in reversed(self.state.log):
            date = (datetime.date(config.START_YEAR, config.START_MONTH, config.START_DAY)
                    + datetime.timedelta(days=day - 1)).strftime("%d.%m.%Y")
            wl = wrap(text, w - 13)
            for i, ln in enumerate(wl):
                lines.append(((date if i == 0 else "").ljust(12) + ln, "n" if i == 0 else "d"))
        sc = min(self.scroll.get("log", 0), max(0, len(lines) - h))
        self.scroll["log"] = sc
        for i, (ln, stl) in enumerate(lines[sc: sc + h]):
            term.put(x, y + i, ln, stl)
        if not lines:
            term.put(x, y, tr("Журнал пуст."), "d")

    def draw_view(self, term, view, x, y, w, h):
        for i, (text, style) in enumerate(view.header):
            term.put(x, y + i, text, style, w)
        top = y + len(view.header)
        detail_h = 7
        list_h = h - len(view.header) - detail_h
        has_map = getattr(view, "map", None) is not None
        list_w = 49 if has_map else w
        items = view.items
        cur = min(self.cursor.get(self.tab, 0), max(0, len(items) - 1))
        self.cursor[self.tab] = cur
        sc = self.scroll.get(self.tab, 0)
        if cur < sc:
            sc = cur
        if cur >= sc + list_h:
            sc = cur - list_h + 1
        self.scroll[self.tab] = sc
        for i, item in enumerate(items[sc: sc + list_h]):
            idx = sc + i
            sel = idx == cur
            style = "i" if sel else item.style
            prefix = "▶ " if sel else "  "
            term.put(x, top + i, (prefix + item.text).ljust(list_w - 2), style, list_w - 2)
            self.hit(x, top + i, list_w - 2, 1, lambda idx=idx: self._click_item(idx))
        if has_map:
            self.draw_theater(term, view.map["bounds"], x + list_w, top, w - list_w, list_h, view.map.get("group"))
        # детали и действия
        dy = y + h - detail_h
        term.hline(x - 1, dy, w + 2)
        if not items:
            return
        item = items[cur]
        for i, ln in enumerate([l for d in item.details for l in wrap(d, w)][:3]):
            term.put(x, dy + 1 + i, ln, "n")
        ax = x
        ay = dy + 5
        if self.action_sel >= len(item.actions):
            self.action_sel = max(0, len(item.actions) - 1)
        if not item.actions:
            term.put(x, ay, tr("(нет доступных действий)"), "d")
        for j, a in enumerate(item.actions):
            cost = f" ({a.cost_text()})" if a.cost else ""
            label = f"[{a.label}{cost}]"
            sel = j == self.action_sel
            style = ("i" if a.enabled else "I") if sel else ("b" if a.enabled else "d")
            if ax + len(label) > x + w:
                break
            term.put(ax, ay, label, style)
            self.hit(ax, ay, len(label), 1, lambda j=j: self._click_action(j))
            ax += len(label) + 2
        sel_a = item.actions[self.action_sel] if item.actions else None
        if sel_a and not sel_a.enabled:
            term.put(x, ay + 1, tr("Недоступно: {0}").format(sel_a.reason), "d")
        elif sel_a:
            term.put(x, ay + 1, tr("ENTER — выполнить") + (tr("   ←→ — другое действие") if len(item.actions) > 1 else ""), "d")

    def _click_item(self, idx):
        if self.cursor.get(self.tab) == idx:
            return
        self.cursor[self.tab] = idx
        self.action_sel = 0
        self.app.audio.play("ui_click")

    def _click_action(self, j):
        self.action_sel = j
        self.run_selected_action(j)

    def draw_theater(self, term, bounds, x, y, w, h, group=None):
        rect = term.rect(x, y, w, h)
        surf, _ = mapview.build_pixel(self.game, bounds, rect.size, term.font, labels=False,
                                      cursor=self.cursor.get(self.tab, 0),
                                      home=self.game.expansion_cfg.get("home"), group=group or "main")
        term.surface.blit(surf, rect)

    # ---------- нижняя панель ----------
    def draw_panel(self, term, y, h, video):
        w = term.cols
        if not video:
            term.box(0, y, w, h, tr("КАНАЛ СУПЕРИВЕНТОВ"), "d")
            with term.clip(1, y + 1, w - 2, h - 2):
                blink = int(pygame.time.get_ticks() / 600) % 2 == 0
                term.put(2, y + 1, (tr("▒ НЕТ СИГНАЛА ▒") if blink else tr("  НЕТ СИГНАЛА  ")), "d")
                q = len(self.game.engine.queue)
                if q > 1:
                    term.put(2, y + 2, tr("Ожидают решения: {0} ивента(ов)").format(q), "b")
                if self.state.log:
                    for i, ln in enumerate(wrap(tr("Последняя сводка: ") + self.state.log[-1][1], w - 23)[:h - 2]):
                        term.put(20, y + 1 + i, ln, "n")
            return
        ev = self.playing_for
        title = tr("СУПЕРИВЕНТ ◆ {0}").format(ev.title().upper())
        term.box(0, y, w, h, title, "b", double=True)
        if not self.player.finished:
            hint = tr(" [ESC/ПРОБЕЛ — пропустить] ") if self.player.skippable else tr(" ● ЗАПИСЬ ")
            term.put(w - len(hint) - 2, y, hint, "n")
            pos = int(self.player.t / max(0.1, self.player.duration) * 30)
            term.put(2, y + h - 1, " " + "▮" * pos + "▯" * (30 - pos) + " ", "n")
        img = self.player.frame_image()
        if img is not None:
            rect = term.rect(1, y + 1, w - 2, h - 2)
            frame = pygame.transform.smoothscale(img, rect.size)
            frame.fill((60, 255, 110), special_flags=pygame.BLEND_MULT)
            term.surface.blit(frame, rect)
        else:
            canvas = self.player.frame_canvas(w - 2, h - 2)
            term.put_grid(1, y + 1, canvas.chars, canvas.styles)

    # ---------- окно ивента ----------
    def draw_event(self, term, ev, video):
        st = self.state
        w = 90 if video else 84
        x = (term.cols - w) // 2 + (0 if video else self.SIDE_W // 2)
        text_lines = wrap(ev.text(), w - 6)
        opts = ev.options(st)
        opt_lines = []
        for n, (idx, text, ok, hint) in enumerate(opts):
            hints = wrap("→ " + hint, w - 12)[:2] if hint else []
            label = f"[{n + 1}] {text}" + ("" if ok else tr("  (недоступно)"))
            opt_lines.append((n, wrap(label, w - 12), ok, hints))
        opts_h = sum(len(o[1]) + len(o[3]) for o in opt_lines)
        h = 4 + len(text_lines) + 1 + opts_h + 1
        area_top = 1 if video else self.TOP_H + 1
        area_bottom = (term.rows - self.PANEL_EXPANDED) if video else (term.rows - self.PANEL_COLLAPSED)
        if h > area_bottom - area_top:
            keep = max(3, len(text_lines) - (h - (area_bottom - area_top)))
            text_lines = text_lines[:keep]
            h = 4 + len(text_lines) + 1 + opts_h + 1
        y = area_top + max(0, (area_bottom - area_top - h) // 2)
        kind = tr("СУПЕРИВЕНТ") if ev.superevent else tr("СОБЫТИЕ")
        term.box(x, y, w, h, f"{kind}: {ev.title()}", "b", double=True)
        term.put(x + w - 16, y, f" {st.date_str()} ", "n")
        with term.clip(x + 1, y + 1, w - 2, h - 2):
            self._draw_event_body(term, x, y, w, text_lines, opt_lines, opts)

    def _draw_event_body(self, term, x, y, w, text_lines, opt_lines, opts):
        for i, ln in enumerate(text_lines):
            term.put(x + 3, y + 2 + i, ln, "n")
        oy = y + 3 + len(text_lines)
        for k, (n, labels, ok, hints) in enumerate(opt_lines):
            sel = n == self.opt_sel
            style = ("i" if ok else "I") if sel else ("b" if ok else "d")
            for j, ln in enumerate(labels):
                line = ("▶ " if sel and j == 0 else "  ") + ("" if j == 0 else "    ") + ln
                term.put(x + 3, oy + j, line.ljust(w - 6) if sel else line, style)
            for j, hl in enumerate(hints):
                term.put(x + 7, oy + len(labels) + j, hl, "d")
            n_rows = len(labels) + len(hints)
            self.hit(x + 3, oy, w - 6, n_rows, lambda o=opts[k], n=n: self._click_option(n, o))
            oy += n_rows

    def _click_option(self, n, opt):
        if self.opt_sel == n:
            self.choose_option(opt)
        else:
            self.opt_sel = n

    def draw_menu(self, term):
        w, h = 56, 15
        x, y = (term.cols - w) // 2, (term.rows - h) // 2
        term.box(x, y, w, h, tr("МЕНЮ"), "b", double=True)
        with term.clip(x + 1, y + 1, w - 2, h - 2):
            self._draw_menu_body(term, x, y, w, h)

    def _draw_menu_body(self, term, x, y, w, h):
        items = [tr("Продолжить"), tr("Сохранить (F5)"), tr("Загрузить (F9)"), tr("В главное меню"),
                 tr("Цвет экрана: {0} (C)").format(settings.theme_name()), tr("Выйти из игры")]
        keys = [pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6]
        for i, it in enumerate(items):
            term.put(x + 4, y + 2 + i * 1, f"[{i + 1}] {it}", "n")
            self.hit(x + 4, y + 2 + i, w - 8, 1, lambda k=keys[i]: self._menu_key(k))
        term.hline(x + 1, y + 9, w - 2)
        for i, (key, label, short, url) in enumerate(config.LINKS):
            yy = y + 10 + i
            img = emblems.icon(key, term.ch - 2, config.BRIGHT)
            if img is not None:
                term.surface.blit(img, img.get_rect(center=term.rect(x + 4, yy, 2, 1).center))
            text = {"telegram": tr("ТГ игры"), "boosty": tr("Поддержать разработчика")}.get(key, label)
            term.put(x + 7, yy, f"[{i + 7}] {text}", "b")
            term.put(x + w - 3 - len(short), yy, short, "d")
            self.hit(x + 4, yy, w - 8, 1, lambda url=url: emblems.open_link(url))
        term.put(x + 4, y + h - 2, tr("ESC — вернуться"), "d")


# =====================================================================
class EndScreen(Screen):
    def __init__(self, app, game):
        super().__init__(app)
        self.game = game
        endings = load_json("endings.json")
        self.paras = epilogue.build(game, endings)
        self.scroll = 0
        self.t = 0.0

    def handle(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.app.set_screen(BootScreen(self.app, skip_boot=True))
            elif event.key == pygame.K_ESCAPE:
                self.app.running = False
            elif event.key in (pygame.K_UP, pygame.K_w):
                self.scroll = max(0, self.scroll - 1)
            elif event.key in (pygame.K_DOWN, pygame.K_s):
                self.scroll += 1
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button in (4, 5):
            self.scroll = max(0, self.scroll + (-1 if event.button == 4 else 1))
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.click(event.pos)

    def update(self, dt):
        self.t += dt

    def draw(self, term):
        self.hits = []
        term.clear()
        term.box(2, 1, term.cols - 4, term.rows - 2, tr("ЭПИЛОГ"), "b", double=True)
        with term.clip(3, 2, term.cols - 6, term.rows - 4):
            self._draw_body(term)

    def _draw_body(self, term):
        lines = []
        for style, text in self.paras:
            for ln in wrap(text, term.cols - 12) or [""]:
                lines.append((ln, style))
        reveal = int(self.t * 60)
        shown = 0
        h = term.rows - 7
        self.scroll = min(self.scroll, max(0, len(lines) - h))
        for i, (ln, style) in enumerate(lines[self.scroll: self.scroll + h]):
            if shown >= reveal:
                break
            part = ln[: max(0, reveal - shown)]
            shown += len(ln) + 1
            term.put(6, 3 + i, part, style)
        term.put(6, term.rows - 3, tr("ENTER — новая партия    ↑↓ — прокрутка    ESC — выход"), "d")
        lw = emblems.links_width(keys=False)
        emblems.draw_links(self, term, term.cols - 6 - lw, term.rows - 4, "b", keys=False)
