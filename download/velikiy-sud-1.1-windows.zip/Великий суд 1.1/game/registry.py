"""Реестр функций, которые можно вызывать из JSON-описаний ивентов.

  predicate("name")  — условие:  {"func": "name"} или {"func": ["name", арг1, ...]}
  action("name")     — эффект:   {"call": "name", "args": [...]}
  chance("name")     — шанс:     "chance": {"func": "name"}

Функции получают (state, ctx, *args). ctx — контекст ивента ({"target": ...}).
"""

PREDICATES = {}
ACTIONS = {}
CHANCES = {}


def predicate(name):
    def deco(fn):
        PREDICATES[name] = fn
        return fn
    return deco


def action(name):
    def deco(fn):
        ACTIONS[name] = fn
        return fn
    return deco


def chance(name):
    def deco(fn):
        CHANCES[name] = fn
        return fn
    return deco
