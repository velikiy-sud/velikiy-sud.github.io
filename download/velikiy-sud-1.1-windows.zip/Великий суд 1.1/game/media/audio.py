"""Синтезатор звуков суперивентов и интерфейса (без внешних файлов и numpy).

Каждый «cue» — функция, возвращающая список сэмплов float в диапазоне [-1, 1].
Звуки генерируются в фоновом потоке при запуске, чтобы не тормозить показ.
Если в assets/media лежит <media_id>.wav/.ogg — плеер использует его вместо синтеза.
"""
import array
import math
import random
import threading

try:
    import pygame
except ImportError:  # для безголовых тестов
    pygame = None

RATE = 22050


def _env(i, n, attack=0.01, release=0.2):
    t = i / RATE
    total = n / RATE
    a = min(1.0, t / attack) if attack > 0 else 1.0
    r = min(1.0, (total - t) / release) if release > 0 else 1.0
    return max(0.0, min(a, r))


def _sine(f, t):
    return math.sin(2 * math.pi * f * t)


def _square(f, t):
    return 1.0 if math.sin(2 * math.pi * f * t) >= 0 else -1.0


def tone(freq, dur, wave="square", vol=0.3, attack=0.005, release=0.05):
    n = int(dur * RATE)
    fn = _square if wave == "square" else _sine
    return [fn(freq, i / RATE) * vol * _env(i, n, attack, release) for i in range(n)]


def silence(dur):
    return [0.0] * int(dur * RATE)


def mix(base, other, offset=0.0):
    start = int(offset * RATE)
    need = start + len(other)
    if need > len(base):
        base.extend([0.0] * (need - len(base)))
    for i, v in enumerate(other):
        base[start + i] += v
    return base


def noise_lp(dur, cutoff=0.05, vol=0.5, rng=None):
    rng = rng or random.Random(1)
    n = int(dur * RATE)
    y = 0.0
    out = []
    for _ in range(n):
        y += cutoff * (rng.uniform(-1, 1) - y)
        out.append(y)
    peak = max(1e-6, max(abs(v) for v in out))
    return [v / peak * vol for v in out]


def _decay(samples, tau):
    return [v * math.exp(-i / RATE / tau) for i, v in enumerate(samples)]


# ---------------- звуки ----------------
def news_jingle():
    out = []
    for f, d in ((784, 0.18), (988, 0.18), (1175, 0.18), (784, 0.5)):
        out += tone(f, d, "square", 0.22, release=0.04) + silence(0.04)
    return mix(out, tone(196, 1.0, "sine", 0.25, release=0.5), 0.6)


def teletype():
    rng = random.Random(7)
    out = silence(5.0)
    t = 0.0
    while t < 4.8:
        click = [rng.uniform(-1, 1) * 0.35 * math.exp(-i / 60) for i in range(200)]
        mix(out, click, t)
        t += rng.choice((0.05, 0.07, 0.09, 0.12, 0.3))
    return out


def dread():
    dur = 7.0
    n = int(dur * RATE)
    out = []
    for i in range(n):
        t = i / RATE
        trem = 0.75 + 0.25 * math.sin(2 * math.pi * 0.4 * t)
        v = (_sine(55, t) * 0.5 + _sine(110, t) * 0.3 + _sine(130.8, t) * 0.25 + _sine(164.8, t) * 0.2
             + _sine(155.6, t) * 0.08 * math.sin(t))
        out.append(v * 0.35 * trem * _env(i, n, 1.5, 2.0))
    return out


def siren(dur=5.0, dying=False):
    n = int(dur * RATE)
    out = []
    phase = 0.0
    for i in range(n):
        t = i / RATE
        k = 1.0 - (t / dur) * 0.6 if dying else 1.0
        f = (450 + 400 * (0.5 - 0.5 * math.cos(2 * math.pi * t / 2.6))) * k
        phase += 2 * math.pi * f / RATE
        v = math.sin(phase) * 0.7 + math.sin(2 * phase) * 0.2
        vol = (1 - t / dur) if dying else 1.0
        out.append(v * 0.3 * vol * _env(i, n, 0.3, 0.6))
    return out


def march():
    rng = random.Random(3)
    out = silence(5.5)
    beat = 0.5
    t = 0.0
    k = 0
    while t < 5.2:
        kick = [_sine(60 - i / RATE * 40, i / RATE) * 0.6 * math.exp(-i / RATE / 0.12) for i in range(int(0.3 * RATE))]
        mix(out, kick, t)
        if k % 2 == 1:
            snare = [rng.uniform(-1, 1) * 0.3 * math.exp(-i / RATE / 0.07) for i in range(int(0.2 * RATE))]
            mix(out, snare, t)
            mix(out, snare, t + beat * 0.5)
        t += beat
        k += 1
    return out


def boom(dur=6.0, vol=0.9, seed=11):
    rng = random.Random(seed)
    crack = _decay(noise_lp(0.4, 0.6, 0.8, rng), 0.08)
    rumble = _decay(noise_lp(dur, 0.012, vol, rng), dur / 3)
    sub = [_sine(38, i / RATE) * 0.5 * math.exp(-i / RATE / 1.5) for i in range(int(dur * RATE))]
    out = mix(rumble, sub)
    return mix(out, crack)


def artillery():
    rng = random.Random(5)
    out = silence(6.0)
    for k in range(7):
        b = boom(1.4, 0.4 + rng.random() * 0.3, seed=20 + k)
        mix(out, b, rng.uniform(0, 4.5))
    return out


def door_slam():
    """Три тяжёлых хлопка дверей в пустом коридоре, с эхом."""
    rng = random.Random(9)
    out = silence(7.0)
    for k, at in enumerate((0.6, 2.9, 5.2)):
        hit = _decay(noise_lp(0.9, 0.08, 0.8, rng), 0.12)
        thud = [_sine(55, i / RATE) * 0.6 * math.exp(-i / RATE / 0.15) for i in range(int(0.9 * RATE))]
        h = mix(hit, thud)
        mix(out, h, at)
        mix(out, [s * 0.25 for s in h], at + 0.18)   # эхо
    return out


def gunfire():
    """Ночная перестрелка: очереди и одиночные выстрелы."""
    rng = random.Random(13)
    out = silence(8.0)
    t = 0.3
    while t < 7.5:
        burst = rng.randint(1, 6)
        for k in range(burst):
            shot = _decay(noise_lp(0.12, 0.5, 0.35 + rng.random() * 0.3, rng), 0.025)
            mix(out, shot, t + k * 0.09)
        t += burst * 0.09 + rng.uniform(0.2, 1.1)
    return out


def incoming():
    """Свист падающей боеголовки: тон уходит вниз."""
    dur = 2.6
    n = int(dur * RATE)
    out, ph = [], 0.0
    for i in range(n):
        f = 1800 - 1400 * (i / n)
        ph += 2 * math.pi * f / RATE
        out.append(math.sin(ph) * 0.18 * _env(i, n, 0.3, 0.05))
    return out


def planes():
    """Гул моторов эскадрильи: биения нескольких низких тонов."""
    dur = 5.0
    n = int(dur * RATE)
    return [(_sine(82, i / RATE) + _sine(86.5, i / RATE) + 0.6 * _sine(123, i / RATE)) * 0.12 * _env(i, n, 1.2, 1.5)
            for i in range(n)]


def key_turn():
    """Два щелчка ключей и зуммер разрешения пуска."""
    out = silence(2.2)
    for at in (0.6, 1.1):
        mix(out, [(1 if j % 3 else -1) * 0.6 * math.exp(-j / 60) for j in range(600)], at)
    mix(out, tone(880, 0.6, "square", 0.15), 1.4)
    return out


def big_boom():
    out = boom(8.0, 1.0, seed=31)
    return mix(out, boom(5.0, 0.5, seed=32), 0.25)


def countdown():
    out = silence(2.4)
    for k in range(4):
        mix(out, tone(1000 if k < 3 else 1500, 0.12, "sine", 0.3), k * 0.6)
    return out


def wind():
    rng = random.Random(9)
    base = noise_lp(6.0, 0.02, 0.4, rng)
    n = len(base)
    return [v * (0.6 + 0.4 * math.sin(2 * math.pi * 0.3 * i / RATE)) * _env(i, n, 1.0, 2.0)
            for i, v in enumerate(base)]


def klaxon():
    out = []
    for k in range(4):
        out += tone(220 if k % 2 == 0 else 277, 0.4, "square", 0.22) + silence(0.15)
    return out


def rocket():
    rng = random.Random(13)
    dur = 6.5
    n = int(dur * RATE)
    out = []
    y = 0.0
    for i in range(n):
        t = i / RATE
        cutoff = 0.02 + 0.15 * min(1.0, t / 3)
        y += cutoff * (rng.uniform(-1, 1) - y)
        out.append(y * 2.2 * _env(i, n, 1.5, 2.5))
    return out


def geiger():
    rng = random.Random(17)
    out = silence(6.0)
    t = 0.0
    while t < 5.9:
        click = [(1 if j % 2 else -1) * 0.4 * math.exp(-j / 25) for j in range(120)]
        mix(out, click, t)
        rate = 3 + 25 * (t / 6)
        t += rng.expovariate(rate)
    return out


def fanfare():
    notes = [(392, 0.35), (523, 0.35), (659, 0.35), (784, 0.9), (659, 0.3), (784, 1.4)]
    out = []
    for f, d in notes:
        n = int(d * RATE)
        seg = []
        for i in range(n):
            t = i / RATE
            v = (_square(f, t) * 0.5 + _sine(f * 1.5, t) * 0.25 + _sine(f / 2, t) * 0.25)
            seg.append(v * 0.25 * _env(i, n, 0.02, 0.1))
        out += seg
    return mix(out, tone(98, len(out) / RATE, "sine", 0.25, 0.3, 0.8))


def bells():
    out = silence(5.0)
    for k, f in enumerate((392, 330, 262)):
        n = int(3.0 * RATE)
        bell = [(_sine(f, i / RATE) * 0.5 + _sine(f * 2.76, i / RATE) * 0.25 + _sine(f * 5.4, i / RATE) * 0.12)
                * 0.35 * math.exp(-i / RATE / 0.9) for i in range(n)]
        mix(out, bell, k * 1.1)
    return out


def static():
    rng = random.Random(23)
    base = noise_lp(5.0, 0.5, 0.18, rng)
    n = len(base)
    return [v * (1.0 if rng.random() > 0.002 else 3.0) * _env(i, n, 0.2, 1.0) for i, v in enumerate(base)]


def beeps():
    out = silence(6.0)
    for k in range(6):
        mix(out, tone(1000, 0.1 if k < 5 else 0.5, "sine", 0.3), k * 0.9)
    return out


def ui_click():
    return [random.uniform(-1, 1) * 0.15 * math.exp(-i / 40) for i in range(300)]


def ui_beep():
    return tone(880, 0.06, "square", 0.08, release=0.02) + tone(1320, 0.06, "square", 0.06, release=0.02)


CUES = {
    "news_jingle": news_jingle, "teletype": teletype, "dread": dread,
    "siren": siren, "siren_dying": lambda: siren(6.0, True), "march": march,
    "boom": boom, "artillery": artillery, "countdown": countdown, "wind": wind,
    "klaxon": klaxon, "rocket": rocket, "geiger": geiger, "fanfare": fanfare,
    "bells": bells, "static": static, "beeps": beeps, "door_slam": door_slam, "gunfire": gunfire,
    "incoming": incoming, "planes": planes, "key_turn": key_turn, "big_boom": big_boom,
    "ui_click": ui_click, "ui_beep": ui_beep,
}


class Audio:
    """Обёртка над pygame.mixer. Если звук недоступен — тихо ничего не делает."""

    def __init__(self, enabled=True):
        global RATE
        self.ok = False
        self.raw = {}
        self.sounds = {}
        self.files = {}
        self.channels = 1
        self.size = -16
        self.muted = False
        if not enabled or pygame is None:
            return
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(RATE, -16, 1, 512)
            freq, size, ch = pygame.mixer.get_init()
            RATE = freq
            self.channels = ch
            self.size = size
            pygame.mixer.set_num_channels(16)
            self.ok = True
        except Exception:
            self.ok = False
            return
        threading.Thread(target=self._pregen, daemon=True).start()

    def _pregen(self):
        for name, fn in CUES.items():
            if name not in self.raw:
                self.raw[name] = self._encode(fn())

    def _encode(self, samples):
        if abs(self.size) == 32:      # некоторые системы открывают микшер во float32
            data = array.array("f")
            for v in samples:
                s = max(-1.0, min(1.0, v)) * 0.92
                for _ in range(self.channels):
                    data.append(s)
            return data.tobytes()
        data = array.array("h")
        for v in samples:
            s = int(max(-1.0, min(1.0, v)) * 30000)
            for _ in range(self.channels):
                data.append(s)
        return data.tobytes()

    def _sound(self, name):
        if name in self.sounds:
            return self.sounds[name]
        raw = self.raw.get(name)
        if raw is None:
            raw = self._encode(CUES[name]())
            self.raw[name] = raw
        snd = pygame.mixer.Sound(buffer=raw)
        self.sounds[name] = snd
        return snd

    def play(self, name):
        if not self.ok or self.muted or name not in CUES:
            return
        try:
            self._sound(name).play()
        except Exception:
            pass

    def play_file(self, path):
        if not self.ok or self.muted:
            return
        try:
            if path not in self.files:
                self.files[path] = pygame.mixer.Sound(path)
            self.files[path].play()
        except Exception:
            pass

    def stop_all(self):
        if self.ok:
            pygame.mixer.stop()
