"""Глобальные настройки: пути, размеры терминальной сетки, палитра, скорости."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT, "data")
EVENTS_DIR = os.path.join(DATA_DIR, "events")
ASSETS_DIR = os.path.join(ROOT, "assets")
FONTS_DIR = os.path.join(ASSETS_DIR, "fonts")
MEDIA_DIR = os.path.join(ASSETS_DIR, "media")
SAVE_DIR = os.path.join(ROOT, "saves")

TITLE = "ВЕЛИКИЙ СУД"
VERSION = "1.1"

# Ссылки игры: (иконка из assets/icons, подпись, адрес для показа, адрес)
LINKS = [
    ("telegram", "ТГ ИГРЫ", "t.me/tnolarp", "https://t.me/tnolarp"),
    ("boosty", "ПОДДЕРЖАТЬ РАЗРАБОТЧИКА", "boosty.to/tnov", "https://boosty.to/tnov"),
]

# Терминальная сетка (символы). Окно подстраивается под размер ячейки шрифта.
COLS, ROWS = 120, 42
FONT_FILE = "DejaVuSansMono.ttf"
FONT_SIZE = 16

# Монохромная зелёная палитра
BG = (0, 6, 2)
BRIGHT = (110, 255, 140)
NORMAL = (40, 215, 90)
DIM = (20, 130, 55)
FAINT = (8, 65, 28)
INVERSE_BG = (40, 215, 90)

# Цвет люминофора: игра рисуется зелёным, а при другой теме весь кадр перекрашивается
# (game/ui/terminal.py, CRT.process). Тема переключается клавишей C и в меню, хранится в saves/settings.json.
THEMES = {
    "green": ("Зелёный", None),
    "purple": ("Фиолетовый", (205, 135, 255)),
    "red": ("Красный", (255, 100, 85)),
    "blue": ("Голубой", (150, 240, 255), (95, 175, 205)),   # третье поле — подсветка: ярче остальных
}

# CRT-эффекты
CRT_SCANLINES = True
CRT_GLOW = True
CRT_FLICKER = True
CRT_FRAME = True      # корпус кинескопа со скруглёнными углами вокруг экрана

# Скорости симуляции: секунд реального времени на один игровой день
SPEEDS = {1: 1.0, 2: 0.5, 3: 0.25, 4: 0.1, 5: 0.04}
DEFAULT_SPEED = 2

START_YEAR, START_MONTH, START_DAY = 1962, 1, 1

AUDIO_RATE = 22050
