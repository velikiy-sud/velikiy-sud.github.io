"""Подробная карта: области и страны из data/map_provinces.json, нарисованные пикселями.

Тёмно-зелёная заливка суши, тонкие линии областей, яркие границы владельцев и побережья,
чёрные моря. Владельцы считаются так же, как на старой символьной карте (game/ui/mapview.py):
область относится к стране мира 1962 года, а осколки Рейха и России делятся по ближайшей
«столице» территории.
"""
import json
import math
import os

import pygame

from . import config, worldmap

SEA = (0, 5, 2)
PROVINCE_LINE = (26, 100, 50)
BORDER = (110, 255, 140)
TEXT = (150, 255, 170)
TEXT_DIM = (60, 190, 95)
SHADOW = (0, 0, 0)

_DATA = None
_BASE_CACHE = {}


def _data():
    global _DATA
    if _DATA is None:
        with open(os.path.join(config.DATA_DIR, "map_provinces.json"), encoding="utf-8") as f:
            raw = json.load(f)
        k = raw["scale"]
        for p in raw["provinces"]:
            p["rings"] = [[(r[i] / k, r[i + 1] / k) for i in range(0, len(r), 2)] for r in p.pop("r")]
        _DATA = raw["provinces"]
    return _DATA


class Projection:
    """Равнопромежуточная проекция с поправкой на широту: страны не растянуты вширь.

    Весь запрошенный прямоугольник bounds = (lon0, lon1, lat0, lat1) попадает на карту,
    по свободной стороне карта расширяется."""

    def __init__(self, bounds, size):
        lon0, lon1, lat0, lat1 = bounds
        w, h = size
        k = math.cos(math.radians((lat0 + lat1) / 2))
        s = min(h / (lat1 - lat0), w / ((lon1 - lon0) * k))   # пикселей на градус широты
        self.sx, self.sy = s * k, s
        self.lon_c, self.lat_c = (lon0 + lon1) / 2, (lat0 + lat1) / 2
        self.w, self.h = w, h

    def __call__(self, lon, lat):
        return (self.w / 2 + (lon - self.lon_c) * self.sx, self.h / 2 - (lat - self.lat_c) * self.sy)


def regions(seeds):
    """Код области для каждой провинции (как worldmap.rasterize, но по центрам провинций)."""
    out = []
    for p in _data():
        code = p.get("t") or p["c"]
        if seeds and code in seeds:
            group = seeds[code]
            k = math.cos(math.radians(p["y"]))
            best, bd = None, 1e9
            for rid, slon, slat in group:
                d = ((p["x"] - slon) * k) ** 2 + (p["y"] - slat) ** 2
                if d < bd:
                    best, bd = rid, d
            code = best if (len(group) == 1 or bd <= worldmap.MAX_REGION_DIST ** 2) else code + ":wild"
        out.append(code)
    return out


def _run(m, x, y, w):
    """Ширина участка маски в строке y вокруг x (шаг 2 пикселя)."""
    if not (0 <= y < m.get_size()[1]) or not m.get_at((x, y)):
        return 0
    lo = hi = x
    while lo - 2 >= 0 and m.get_at((lo - 2, y)):
        lo -= 2
    while hi + 2 < w and m.get_at((hi + 2, y)):
        hi += 2
    return hi - lo


def _label_spot(m):
    """Место для подписи: центр самого большого куска земель и ширина суши вокруг него."""
    comp = m.connected_component()
    if comp.count() < 30:
        return None
    w, h = m.get_size()
    cx, cy = comp.centroid()
    if not comp.get_at((cx, cy)):
        # центр вне фигуры (вогнутая страна): ближайшая точка фигуры по строке
        xs = [x for x in range(0, w, 2) if comp.get_at((x, cy))]
        if not xs:
            return None
        cx = min(xs, key=lambda x: abs(x - cx))
    room = min(_run(comp, cx, cy + dy, w) for dy in (-6, 0, 6))
    return cx, cy, room


def _pattern(size, kind, color):
    """Узор поверх заливки: штриховка для противника, точки для марионеток."""
    surf = pygame.Surface(size, pygame.SRCALPHA)
    surf.fill((0, 0, 0, 0))
    w, h = size
    if kind == "stripes":
        for x in range(-h, w, 7):
            pygame.draw.line(surf, color, (x, h), (x + h, 0), 1)
    elif kind == "dots":
        for y in range(2, h, 5):
            for x in range(2 + (y // 5 % 2) * 2, w, 5):
                surf.set_at((x, y), color)
    return surf


def base(bounds, size, region_codes, owner_of, fill_of):
    """Заливка и границы без подписей. Кэшируется, пока не изменятся владельцы."""
    owners = [owner_of(c) for c in region_codes]
    key = (tuple(bounds), tuple(size), tuple(owners))
    if key in _BASE_CACHE:
        return _BASE_CACHE[key]
    if len(_BASE_CACHE) > 12:
        _BASE_CACHE.clear()
    proj = Projection(bounds, size)
    surf = pygame.Surface(size)
    surf.fill(SEA)
    ids = pygame.Surface(size)
    ids.fill((0, 0, 0))
    index = {}
    shapes = []
    for p, owner in zip(_data(), owners):
        n = index.setdefault(owner, len(index) + 1)
        id_color = (n & 255, (n >> 8) & 255, 255)
        fill, _ = fill_of(owner)
        for ring in p["rings"]:
            pts = [proj(x, y) for x, y in ring]
            xs = [q[0] for q in pts]
            ys = [q[1] for q in pts]
            if max(xs) < 0 or min(xs) > size[0] or max(ys) < 0 or min(ys) > size[1]:
                continue
            pygame.draw.polygon(surf, fill, pts)
            pygame.draw.polygon(ids, id_color, pts)
            shapes.append(pts)
    # узоры по владельцам
    full = pygame.Rect((0, 0), size)
    for owner, n in index.items():
        _, pattern = fill_of(owner)
        if not pattern:
            continue
        kind, color = pattern
        m = pygame.mask.from_threshold(ids, (n & 255, (n >> 8) & 255, 255), (1, 1, 1, 255))
        layer = m.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))
        layer.blit(_pattern(size, kind, color), (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        surf.blit(layer, full)
    # тонкие линии областей
    for pts in shapes:
        pygame.draw.aalines(surf, PROVINCE_LINE, True, pts)
    # яркие границы владельцев и побережья: край маски каждого владельца
    edges = pygame.mask.Mask(size)
    centers = {}
    for owner, n in index.items():
        m = pygame.mask.from_threshold(ids, (n & 255, (n >> 8) & 255, 255), (1, 1, 1, 255))
        centers[owner] = _label_spot(m)
        inner = m.overlap_mask(m, (1, 0)).overlap_mask(m, (-1, 0)).overlap_mask(m, (0, 1)).overlap_mask(m, (0, -1))
        m.erase(inner, (0, 0))
        edges.draw(m, (0, 0))
    w, h = size
    for x in range(w):           # край карты — не граница
        edges.set_at((x, 0), 0)
        edges.set_at((x, h - 1), 0)
    for y in range(h):
        edges.set_at((0, y), 0)
        edges.set_at((w - 1, y), 0)
    surf.blit(edges.to_surface(setcolor=BORDER, unsetcolor=None), full)
    centers = {o: c for o, c in centers.items() if c}
    _BASE_CACHE[key] = (surf, proj, centers)
    return surf, proj, centers


def _text(surf, font, text, pos, color, center=True):
    img = font.render(text, True, color)
    sh = font.render(text, True, SHADOW)
    x, y = pos
    if center:
        x -= img.get_width() / 2
        y -= img.get_height() / 2
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (1, 1)):
        surf.blit(sh, (x + dx, y + dy))
    surf.blit(img, (x, y))
    return pygame.Rect(int(x), int(y), img.get_width(), img.get_height())


def draw_labels(surf, proj, font, labels, taken=None, clamp=False):
    """labels: [(текст, lon, lat, яркий?)]. Подписи, которые наползают друг на друга, пропускаются;
    clamp=True — подпись у края карты сдвигается внутрь, а не пропускается."""
    taken = taken if taken is not None else []
    full = surf.get_rect()
    for text, lon, lat, bright in labels:
        x, y = proj(lon, lat)
        w, h = font.size(text)
        r = pygame.Rect(int(x - w / 2), int(y - h / 2), w, h)
        if clamp:
            r.clamp_ip(full)
            x, y = r.center
        if not full.contains(r) or any(r.colliderect(t) for t in taken):
            continue
        _text(surf, font, text, (x, y), TEXT if bright else TEXT_DIM)
        taken.append(r)
    return taken


_FONTS = {}


def font(size):
    if size not in _FONTS:
        path = os.path.join(config.FONTS_DIR, config.FONT_FILE)
        try:
            _FONTS[size] = pygame.font.Font(path, size)
        except Exception:
            _FONTS[size] = pygame.font.SysFont("dejavusansmono,consolas,monospace", size)
    return _FONTS[size]


def _spaced(text, f, spacing, color):
    """Надпись с разрядкой, как подписи государств на карте TNO."""
    glyphs = [f.render(ch, True, color) for ch in text]
    w = sum(g.get_width() for g in glyphs) + spacing * (len(glyphs) - 1)
    out = pygame.Surface((max(1, w), f.get_linesize()), pygame.SRCALPHA)
    x = 0
    for g in glyphs:
        out.blit(g, (x, 0))
        x += g.get_width() + spacing
    return out


def _lines(text, f, color):
    """Надпись в одну строку и, для длинных названий, в две (по пробелу ближе к середине)."""
    out = [[f.render(text, True, color)]]
    words = text.split(" ")
    if len(words) > 1:
        cut = min(range(1, len(words)), key=lambda k: abs(len(" ".join(words[:k])) - len(text) / 2))
        out.append([f.render(" ".join(words[:cut]), True, color), f.render(" ".join(words[cut:]), True, color)])
    return out


def _stack(rows):
    w = max(r.get_width() for r in rows)
    h = sum(r.get_height() - 3 for r in rows) + 3
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    y = 0
    for r in rows:
        surf.blit(r, ((w - r.get_width()) // 2, y))
        y += r.get_height() - 3
    return surf


def _fit(text, room, color):
    """Полное название покрупнее, чтобы влезло в ширину страны (room); иначе — самое мелкое в две строки."""
    for size in (16, 14, 12, 11, 10):
        for rows in _lines(text, font(size), color):
            if max(r.get_width() for r in rows) <= room:
                return size, len(rows)
    return 10, min(2, len(text.split(" ")))


def draw_country_labels(surf, proj, centers, labels, taken):
    """labels: {владелец: ([текст], яркий?)}. Подпись — полное название в центре земель владельца:
    крупно, если страна большая, мелко и в две строки — если маленькая. Подписываются все страны."""
    full = surf.get_rect()
    # сначала стороны конфликта, потом страны покрупнее
    order = sorted(labels.items(), key=lambda kv: (not kv[1][1], -(centers[kv[0]][2] if kv[0] in centers else 0)))
    for owner, (texts, bright) in order:
        if owner not in centers:
            continue
        text = texts[0]
        x, y, room = centers[owner]
        size, nrows = _fit(text, max(room * 0.95, 40), TEXT)
        color = TEXT if bright else TEXT_DIM
        img = _stack(_lines(text, font(size), color)[nrows - 1])
        sh = _stack(_lines(text, font(size), SHADOW)[nrows - 1])
        spots = [(0, 0), (0, -12), (0, 12), (-20, 0), (20, 0), (0, -24), (0, 24), (-30, -12), (30, 12)]
        best = None
        for dx, dy in spots:
            r = img.get_rect(center=(int(x) + dx, int(y) + dy))
            r.clamp_ip(full)
            hits = sum(r.colliderect(t) for t in taken)
            if best is None or hits < best[0]:
                best = (hits, r)
            if hits == 0:
                break
        r = best[1]
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (1, 1), (2, 2)):
            surf.blit(sh, (r.x + dx, r.y + dy))
        surf.blit(img, r)
        taken.append(r.inflate(4, 0))
    return taken


def draw_marker(surf, font, pos, mark, selected=False, active=False):
    """Метка цели: цифра в светлом квадрате; выбранная — в рамке."""
    x, y = pos
    w, h = font.size(mark)
    r = pygame.Rect(0, 0, w + 6, h)
    r.center = (int(x), int(y))
    r.clamp_ip(surf.get_rect())
    if selected:
        pygame.draw.rect(surf, BORDER, r.inflate(6, 6), 2)
    pygame.draw.rect(surf, BORDER if not active else TEXT_DIM, r)
    surf.blit(font.render(mark, True, config.BG), (r.x + 3, r.y))
    return r
