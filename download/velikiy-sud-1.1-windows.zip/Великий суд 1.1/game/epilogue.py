"""Текстовый эпилог: итог партии по выборам игрока, доктринам и показателям."""
from .mechanics import expansion
from .mechanics.army import DOCTRINES
from .mechanics.nuclear import DOCTRINE_NAMES

ENDING_CHAIN_IDS = ("EVENT_002", "EVENT_B01", "EVENT_B03", "EVENT_L01", "EVENT_L02", "EVENT_L03",
                    "EVENT_W01", "EVENT_W04", "EVENT_F01", "SUPEREVENT_F02", "EVENT_BE1", "EVENT_LE1")


def build(game, endings):
    st = game.state
    e = endings.get(st.ending, {"title": st.ending.upper(), "text": ""})
    years = st.day / 365
    paras = [
        ("bright", f"{st.side_name().upper()} — {e['title']}"),
        ("normal", f"Партия длилась {st.day} дней (~{years:.1f} г.), до {st.date_str()}."),
        ("normal", ""),
        ("normal", e["text"]),
        ("normal", ""),
        ("bright", "ПУТЬ ДЕРЖАВЫ:"),
    ]
    # Ключевые решения
    picked = [h for h in st.history if h["id"] in ENDING_CHAIN_IDS or h["id"].startswith("SUPEREVENT")]
    for h in picked[:14]:
        paras.append(("normal", f"  {h['date']}  {h['title']}: «{h['option']}»"))

    # Экспансия
    ctrl = expansion.controlled(st)
    if st.territories:
        title = game.expansion_cfg["title"].capitalize()
        names = ", ".join(t["name"] for t in ctrl) or "ничего"
        paras += [("normal", ""), ("bright", f"{title.upper()}: {len(ctrl)}/{len(st.territories)}"),
                  ("normal", f"  Под контролем: {names}.")]
        if st.has_flag("new_burgundian_empire"):
            paras.append(("normal", "  Германия как единое государство прекратила существование."))
        if st.has_flag("united_league"):
            paras.append(("normal", "  Россия объединена под чёрным знаменем Лиги."))

    # Армия и ядерка
    d = DOCTRINES.get(st.vars.get("army_doctrine"), {}).get("name", "не утверждена")
    nd = DOCTRINE_NAMES.get(st.vars.get("nuke_doctrine"), "не принята")
    paras += [("normal", ""), ("bright", "ВОЕННАЯ МАШИНА:"),
              ("normal", f"  Армейская доктрина: {d}. Ядерная доктрина: {nd}."),
              ("normal", f"  Ядерное испытание: {'проведено' if st.has_flag('nuke_tested') else 'не проведено'}"
                         f"{', программа форсировалась' if st.has_flag('nuke_forced') else ''}."
                         f"{' Аварии скрывались от мира.' if st.vars.get('coverups') else ''}"),
              ("normal", f"  Ядерных ударов нанесено: {st.war['strikes']}, получено: {st.war['enemy_strikes']}."),
              ("normal", f"  Опустошение: наше {st.get('own_losses'):.0f}%, противника {st.get('enemy_losses'):.0f}%."),
              ("normal", f"  Итог: стабильность {st.get('stability'):.0f}, престиж {st.get('prestige'):.0f}, "
                         f"мировое осуждение {st.get('world_reaction'):.0f}.")]
    return paras
