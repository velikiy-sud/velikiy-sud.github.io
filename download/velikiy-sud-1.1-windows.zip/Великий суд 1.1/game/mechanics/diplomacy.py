"""Дипломатия: фракции, внутренняя пропаганда, разведка, канал связи с противником."""
from .common import Item, TabView, bar, costly


def view(game):
    st = game.state
    side_cfg = game.side_cfg
    header = [
        (f"Дипломатические очки: {st.get('dip_points'):.0f}   Престиж: {st.get('prestige'):.0f}   "
         f"Разведданные: {st.get('intel'):.0f}   Мировое осуждение: {st.get('world_reaction'):.0f}", "bright"),
        (f"Идеологическая чистота: {bar(st.get('ideology'), 20)} {st.get('ideology'):.0f}", "normal"),
    ]
    if "leader_power" in st.stats:
        header.append((f"Власть лидера:          {bar(st.get('leader_power'), 20)} {st.get('leader_power'):.0f}   "
                       f"Компетентность аппарата: {st.get('apparatus'):.0f}", "normal"))
    header += [("", "normal"), ("ФРАКЦИИ И ОТНОШЕНИЯ:", "bright")]
    items = []
    for key, f in side_cfg["factions"].items():
        rel = st.relations[key]

        def court(key=key, f=f):
            st.add_relation(key, 8)
            st.log_msg(f"Отношения с фракцией «{f['name']}» улучшены.")
        items.append(Item(f"{f['name']:<32} {bar(rel, 16)} {rel:3.0f}",
                          [costly(st, "Укрепить связи", {"dip_points": 10}, court)],
                          [f.get("desc", ""), "+8 к отношениям за 10 дипломатических очков."]))

    def home_prop():
        st.add("stability", 4)
        st.add("ideology", 1)
        st.log_msg("Радио и газеты славят режим. Улицы спокойны.")
    items.append(Item("Внутренняя пропаганда", [costly(st, "Запустить кампанию", {"treasury": 20}, home_prop)],
                      ["+4 стабильности, +1 идеологической чистоты."]))

    def ideology():
        st.add("ideology", 5)
        st.add("stability", -1)
        st.log_msg("Чистка рядов: сомневающихся отстранили от должностей.")
    items.append(Item("Идеологическая чистка", [costly(st, "Провести чистку", {"dip_points": 8}, ideology)],
                      ["+5 идеологической чистоты, -1 стабильности.",
                       "Чистота ускоряет пропаганду, но мешает компромиссам."]))

    def spy():
        st.add("intel", 6)
        st.log_msg("Новые агенты внедрены в штабы противника.")
    items.append(Item("Агентурная сеть у противника", [costly(st, "Внедрить агентов", {"treasury": 25}, spy)],
                      ["+6 разведданных. Чем больше данных, тем точнее оценки армии и арсенала врага."]))

    def channel():
        st.add("tension", -8)
        st.add("prestige", -1)
        st.log_msg("Тайный канал связи с противником снизил напряжённость.")
    items.append(Item("Тайный канал с противником",
                      [costly(st, "Провести переговоры", {"dip_points": 15}, channel,
                              not st.war["active"], "идёт война")],
                      ["-8 напряжённости, -1 престижа."]))

    def provoke():
        st.add("tension", 6)
        st.add("prestige", 3)
        st.log_msg("Пограничная провокация: обе стороны обменялись нотами протеста.")
    items.append(Item("Провокация на границе",
                      [costly(st, "Устроить провокацию", {"treasury": 10}, provoke, not st.war["active"], "идёт война")],
                      ["+6 напряжённости, +3 престижа. Приближает войну."]))
    return TabView("ДИПЛОМАТИЯ", header, items)
