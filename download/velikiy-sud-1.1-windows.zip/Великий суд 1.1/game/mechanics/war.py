"""Война: обычная (линия фронта) и ядерная (удары, ответные удары, полный обмен)."""
import random

from .. import registry
from . import army, expansion, nuclear
from .common import Action, Item, TabView, bar

STANCES = {"offensive": "Наступление", "balanced": "Сбалансированно", "defensive": "Оборона"}


def enemy_power(state):
    eco = 0.5 + 0.5 * state.get("enemy_economy", 100) / 100
    # 0.95 — выучка и снабжение противника тоже не идеальны (у игрока их считает army.strength)
    return state.get("enemy_army") * (1 - state.get("enemy_losses") / 200) * eco * 0.95


# ---------- следы ракет на карте (рисует game/ui/screens.py) ----------
# откуда летят ракеты и бомбардировщики стороны и по каким городам бьют по ней (долгота, широта)
LAUNCH_SITES = {
    "burgundy": [(4.35, 50.85), (4.4, 51.2), (3.06, 50.63), (5.57, 50.63), (5.0, 47.3), (6.13, 49.6),
                 (4.9, 52.37), (3.7, 51.05)],
    "league": [(39.9, 59.2), (40.5, 64.5), (49.7, 58.6), (46.6, 61.25), (56.3, 58.0), (39.9, 57.6),
               (44.0, 60.8), (52.0, 62.0)],
}
TARGET_CITIES = {
    "burgundy": [(4.35, 50.85), (4.4, 51.2), (3.06, 50.63), (5.57, 50.63), (4.9, 52.37), (4.5, 51.9),
                 (6.13, 49.6), (4.03, 49.25), (6.18, 48.7), (5.0, 47.3), (3.7, 51.05), (2.35, 48.85)],
    "league": [(39.9, 59.2), (37.6, 55.75), (39.9, 57.6), (40.5, 64.5), (44.0, 56.3), (49.1, 55.8),
               (49.7, 58.6), (56.3, 58.0), (37.9, 59.1), (40.9, 57.8), (56.0, 54.7), (50.1, 53.2)],
}
TRAILS_PER_WARHEAD = 6    # залп: на каждую боеголовку — несколько ракет и ложных целей
MAX_TRAILS = 400


def add_trails(state, attacker, warheads):
    """Запомнить траектории удара: [долгота0, широта0, долгота1, широта1, "me"/"enemy", день]."""
    if warheads <= 0:
        return
    side = state.side if attacker == "me" else state.enemy_side
    target = state.enemy_side if attacker == "me" else state.side
    trails = state.vars.setdefault("nuke_trails", [])
    rnd = random.Random(state.day * 7919 + len(trails))   # свой генератор: не сбивает ход партии
    for _ in range(min(60, warheads * TRAILS_PER_WARHEAD)):
        lon0, lat0 = rnd.choice(LAUNCH_SITES[side])
        lon1, lat1 = rnd.choice(TARGET_CITIES[target])
        trails.append([round(lon0 + rnd.uniform(-0.8, 0.8), 2), round(lat0 + rnd.uniform(-0.5, 0.5), 2),
                       round(lon1 + rnd.uniform(-0.6, 0.6), 2), round(lat1 + rnd.uniform(-0.4, 0.4), 2),
                       attacker, state.day])
    del trails[:-MAX_TRAILS]


def nuclear_war_risk(state):
    """Оценка вероятности ядерной войны (0..100) — для интерфейса и эпилога."""
    if state.get("warheads") <= 0 and state.get("enemy_nukes") <= 0:
        return 0.0
    r = state.get("tension") * 0.35 + state.get("escalation") * 0.5
    r *= {"retaliation": 0.7, "preventive": 1.15, "unlimited": 1.4}.get(state.vars.get("nuke_doctrine"), 1.0)
    if state.war["active"]:
        r += 15
    return max(0.0, min(99.0, r))


# ---------- захваты по линии фронта ----------
STEP = 8   # на сколько пунктов должен сдвинуться фронт, чтобы одна земля перешла к наступающему


def merge_german_bloc(state):
    """Лига против Бургундии: рейхскомиссариаты и Германия Геринга воюют вместе с Орденом как одно государство."""
    game = state.game
    if state.side != "league":
        return []
    got = []
    for tid, t in expansion.all_defs(game).items():
        h = expansion.holder(state, tid)
        if h in ("me", "enemy"):
            continue
        if t.get("rk") or tid == "goering" or h == "goering":
            expansion._set_holder(state, tid, "enemy")
            got.append(t["name"])
    state.vars.get("ai_ops", {}).pop("goering", None)
    if got:
        state.set_flag("german_bloc")
        state.log_msg("Рейхскомиссариаты и войска Геринга встали под знамя Ордена: теперь это один фронт — "
                      + ", ".join(got) + ".")
    return got


def _defender(attacker):
    return "enemy" if attacker == "me" else "me"


def next_target(game, attacker):
    """Земля, за которую сейчас идёт бой: чужая, граничит с землями наступающего, самая слабая."""
    st = game.state
    defs = expansion.all_defs(game)
    pool = [tid for tid in defs if expansion.holder(st, tid) == _defender(attacker)
            and expansion.borders(game, attacker, tid)]
    if not pool:
        return None
    return min(pool, key=lambda tid: (defs[tid]["resistance"], tid))


def _take(game, attacker, tid):
    st = game.state
    t = expansion.all_defs(game)[tid]
    if attacker == "me":
        if tid in st.territories:
            expansion.set_status(st, {}, tid, "annexed")
        else:
            st.ai_territories[tid] = "player"
            expansion._captured(st, tid, "me")
        st.add("treasury", 10)   # трофеи
        st.log_msg(f"ФРОНТ: наши войска заняли «{t['name']}».")
    else:
        expansion._set_holder(st, tid, "enemy")
        expansion._captured(st, tid, "enemy")
        st.add("stability", -2)
        st.log_msg(f"ФРОНТ: противник прорвался и занял «{t['name']}».")


def _push(game, attacker):
    """Фронт сдвинулся на шаг: сначала отбиваем своё, потом берём чужое (только соседние земли)."""
    w = game.state.war
    back = w.setdefault("lost" if attacker == "me" else "won", [])
    while back:
        tid = back.pop()
        if expansion.holder(game.state, tid) == _defender(attacker) and expansion.borders(game, attacker, tid):
            _take(game, attacker, tid)
            return
    tid = next_target(game, attacker)
    if tid:
        _take(game, attacker, tid)
        w.setdefault("won" if attacker == "me" else "lost", []).append(tid)


def _front_captures(game):
    w = game.state.war
    lvl = w.setdefault("level", 0)
    # с запасом в целый шаг: фронт, дрожащий у отметки, не перекидывает землю туда-сюда каждый день
    while w["front"] >= (w["level"] + 1) * STEP:
        w["level"] += 1
        _push(game, "me")
    while w["front"] <= (w["level"] - 1) * STEP:
        w["level"] -= 1
        _push(game, "enemy")
    if w["level"] != lvl or "next_me" not in w or w.get("days", 0) % 5 == 0:
        w["next_me"] = (w.get("lost") or [None])[-1] or next_target(game, "me")
        w["next_enemy"] = (w.get("won") or [None])[-1] or next_target(game, "enemy")


def battles(state):
    """Для карты: [(кто наступает, id земли, доля занятого 0..1)] — бой за одну соседнюю землю."""
    w = state.war
    if not w["active"]:
        return []
    off = w["front"] - w.get("level", 0) * STEP
    if off > 0 and w.get("next_me"):
        return [("me", w["next_me"], min(1.0, off / STEP))]
    if off < 0 and w.get("next_enemy"):
        return [("enemy", w["next_enemy"], min(1.0, -off / STEP))]
    return []


# ---------- действия для ивентов ----------
@registry.action("war.start")
def start(state, ctx, front=0):
    if state.war["active"]:
        return
    state.war.update({"active": True, "front": float(front), "days": 0, "level": 0, "won": [], "lost": []})
    state.set("tension", 100)
    state.set_flag("war_started")
    state.log_msg(f"ВОЙНА: {state.side_name()} ⇄ {state.side_name(state.enemy_side)}.")
    bloc = merge_german_bloc(state)
    event = "SUPEREVENT_WAR_" + state.side.upper()
    if event not in state.engine.events:
        event = "SUPEREVENT_WAR"
    state.engine.fire(event, {"first_strike": front < 0, "bloc": ", ".join(bloc) or "—"})


@registry.action("war.ultimatum")
def ultimatum(state, ctx):
    """Ни Лига, ни Бургундия ультиматумов не принимают: ответ — война. При перевесе удар первыми наносим мы."""
    ratio = army.strength(state) / max(1.0, enemy_power(state))
    state.add("prestige", 5)
    if ratio >= 1.3:
        state.log_msg("Ультиматум отвергнут. Наши войска перешли границу, не дожидаясь ответного залпа.")
        start(state, ctx, 10)
    else:
        state.log_msg("Ответом на ультиматум стал артиллерийский залп: противник ударил первым!")
        state.add("morale", -10)
        start(state, ctx, -15)


@registry.action("war.nuclear_strike")
def nuclear_strike(state, ctx, kind):
    n = int(min(state.get("warheads"), 3))
    if n <= 0:
        state.log_msg("Удар сорван: в арсенале не осталось боеголовок.")
        return
    state.add("warheads", -n)
    plan = 1.25 if state.vars.get("nuke_target", "military") == kind else 1.0
    if state.get("missiles") <= 0:   # без ракет летят только бомбардировщики: часть сбивает ПВО
        lost = sum(1 for _ in range(n) if state.rng.random() < 0.35)
        if lost:
            state.log_msg(f"ПВО противника сбила {lost} из {n} бомбардировщиков с боеголовками.")
        n -= lost
        if n <= 0:
            state.add("escalation", 10)
            state.log_msg("Удар сорван: ни один бомбардировщик не прорвался к целям.")
            return
    if kind == "military":
        state.set("enemy_army", state.get("enemy_army") * (1 - min(0.6, 0.15 * n * plan)))
        state.add("enemy_losses", 8 * n * plan)
        state.war["front"] += 12 * n * plan
        state.add("world_reaction", 15)
        state.add("escalation", 25)
    else:
        state.add("enemy_economy", -15 * n * plan)
        state.add("enemy_losses", 12 * n * plan)
        state.add("world_reaction", 30)
        state.add("stability", -8)
        state.add("escalation", 35)
    state.war["strikes"] += 1
    state.set_flag("used_nukes")
    add_trails(state, "me", n)
    state.log_msg(f"Нанесён ядерный удар ({n} боеголовок) по {'военным объектам' if kind == 'military' else 'промышленным центрам'}.")
    _after_exchange(state)
    if state.get("enemy_nukes") > 0 and not state.has_flag("f03_pending"):
        p = 0.75 + state.get("escalation") / 200
        if state.vars.get("nuke_doctrine") == "preventive":
            p += 0.1
        if state.rng.random() < p:
            state.engine.schedule("SUPEREVENT_F_RET", state.day + state.rng.randint(1, 2))


@registry.action("war.enemy_strike")
def enemy_strike(state, ctx):
    n = int(min(state.get("enemy_nukes"), 3))
    if n <= 0:
        state.log_msg("Тревога оказалась ложной: у противника не осталось боеголовок.")
        return
    state.add("enemy_nukes", -n)
    state.add("own_losses", 10 * n)
    state.add("stability", -12)
    state.add("manpower", -8 * n)
    state.add("escalation", 20)
    state.war["enemy_strikes"] += 1
    state.war["front"] -= 10 * n
    add_trails(state, "enemy", n)
    state.log_msg(f"Противник нанёс ядерный удар. Потери: {state.get('own_losses'):.0f}%.")


@registry.action("war.full_exchange")
def full_exchange(state, ctx):
    mine = state.get("warheads")
    theirs = state.get("enemy_nukes")
    add_trails(state, "me", int(mine))
    add_trails(state, "enemy", int(theirs))
    state.add("enemy_losses", 9 * mine)
    state.add("own_losses", 11 * theirs + 5)
    state.set("warheads", 0)
    state.set("enemy_nukes", 0)
    state.set("escalation", 100)
    state.war["strikes"] += 1
    state.war["enemy_strikes"] += 1
    state.log_msg("Полномасштабный ядерный обмен.")


@registry.action("war.ceasefire")
def ceasefire(state, ctx):
    if state.get("escalation") < 50 and state.rng.random() < 0.4:
        state.engine.fire("ENDING_ARMISTICE")
    else:
        state.log_msg("Предложение перемирия осталось без ответа. Ракеты уже в воздухе.")
        full_exchange(state, ctx)
        _after_exchange(state)


@registry.predicate("war.pyrrhic")
def pyrrhic(state, ctx):
    return state.get("own_losses") + 10 <= state.get("enemy_losses") and state.get("own_losses") < 75


def _after_exchange(state):
    total = state.war["strikes"] + state.war["enemy_strikes"]
    if state.has_flag("f03_pending"):
        return
    if total >= 3:   # третий удар — ядерный коллапс
        state.set_flag("f03_pending")
        state.engine.schedule("SUPEREVENT_F_COLLAPSE", state.day + 1)
    elif total >= 2 and state.get("escalation") >= 90:
        state.set_flag("f03_pending")
        state.engine.schedule("SUPEREVENT_F03", state.day + 2)


registry.ACTIONS["war.check_exchange"] = lambda state, ctx: _after_exchange(state)


# ---------- ежедневный тик ----------
def daily(game):
    st = game.state
    w = st.war
    if not w["active"] or st.has_flag("f03_pending"):
        return
    w["days"] += 1
    own = army.strength(st)
    en = enemy_power(st)
    delta = max(-2.0, min(2.0, (own - en) / max(own, en, 1.0) * 2))   # фронт ползёт медленно
    stance = w.get("stance", "balanced")
    losses = army.doctrine(st).get("losses", 1.0)
    if stance == "offensive":
        delta += 0.7
        st.add("morale", -0.08)
        st.add("manpower", -0.45 * losses)
    elif stance == "defensive":
        delta = delta * 0.5 - 0.3
        st.add("manpower", -0.15 * losses)
    else:
        st.add("manpower", -0.25 * losses)
    delta += st.rng.gauss(0, 1.3)
    w["front"] = max(-100.0, min(100.0, w["front"] + delta))
    _front_captures(game)
    st.add("equipment", -0.15)
    st.add("treasury", -5)
    st.add("stability", -0.06)
    st.set("enemy_army", st.get("enemy_army") - 0.05 * own / max(en, 1.0))
    # мясорубка: потери копятся каждый день, а с ними — эскалация
    st.add("own_losses", 0.04 + (0.04 if stance == "offensive" else 0))
    st.add("enemy_losses", 0.05)
    st.add("escalation", 0.25 + abs(w["front"]) / 200)

    eng = game.engine
    if w["front"] >= 100:
        eng.fire("ENDING_VICTORY")
        w["active"] = False
        return
    if w["front"] <= -100:
        eng.fire("ENDING_DEFEAT")
        w["active"] = False
        return
    # Критическое положение — генералы предлагают ядерный удар
    age = st.flag_age("f02_offered")
    pause = 60 if st.has_flag("strike_cancelled") else 20   # после отмены генералы не давят сразу
    if w["front"] <= -40 and nuclear.can_strike(st, {}) and (age == -1 or age >= pause):
        st.set_flag("f02_offered")
        eng.fire("SUPEREVENT_F02", {"reason": "critical"})
        return
    # Противник может применить ядерное оружие первым
    if st.get("enemy_nukes") > 0 and (w["front"] >= 20 or st.get("escalation") >= 40):
        p = 0.016 * (1 + st.get("escalation") / 25)
        if st.vars.get("nuke_doctrine") == "preventive":
            p *= 1.5
        if st.rng.random() < p:
            eng.fire("SUPEREVENT_F_RET", {"enemy_first": True})


# ---------- вкладка ----------
def view(game):
    st = game.state
    w = st.war
    risk = nuclear_war_risk(st)
    header = [
        (f"{'ИДЁТ ВОЙНА' if w['active'] else 'МИР (вооружённый)'}: {st.side_name()} ⇄ {st.side_name(st.enemy_side)}", "bright"),
        ("", "normal"),
        (f"Напряжённость     {bar(st.get('tension'))} {st.get('tension'):5.1f}", "normal"),
        (f"Эскалация         {bar(st.get('escalation'))} {st.get('escalation'):5.1f}", "normal"),
        (f"Риск ядерной войны {risk:4.0f}%", "bright" if risk > 40 else "normal"),
        (f"Наша мощь: {army.strength(st):.1f}   Противник: {game.enemy_estimate()}   "
         f"Его арсенал: {game.enemy_nukes_estimate()}", "normal"),
    ]
    if w["active"]:
        pos = int((w["front"] + 100) / 200 * 40)
        line = "".join("█" if i < pos else "░" for i in range(40))
        header += [("", "normal"),
                   (f"ЛИНИЯ ФРОНТА  поражение [{line}] победа   {w['front']:+.0f}", "bright"),
                   (f"День войны: {w['days']}   Ядерных ударов: наших {w['strikes']}, противника {w['enemy_strikes']}", "normal"),
                   (f"Потери (опустошение): наши {st.get('own_losses'):.0f}%  противника {st.get('enemy_losses'):.0f}%", "normal")]
        defs = expansion.all_defs(game)
        fight = battles(st)
        if fight:
            who, tid, frac = fight[0]
            where = (f"наступаем на «{defs[tid]['name']}»" if who == "me"
                     else f"противник давит на «{defs[tid]['name']}»")
            header.append((f"Бой на линии фронта: {where} — {frac * 100:.0f}%", "bright"))
        header.append((f"Земли переходят по фронту: каждые {STEP} пунктов — одна соседняя область. "
                       f"Взято {len(w.get('won', []))}, потеряно {len(w.get('lost', []))}.", "dim"))
    header.append(("", "normal"))
    items = []
    eng = game.engine
    if not w["active"]:
        busy = any(q.id == "EVENT_F01" for q in eng.queue)

        def casus():
            eng.fire("EVENT_F01")
        ready = st.has_flag("war_gate") or st.day >= 365
        ok = st.get("tension") >= 70 and ready and not busy
        why = "напряжённость ниже 70" if st.get("tension") < 70 else "армия и общество ещё не готовы (после 1 года игры)"
        items.append(Item("Искать повод к войне (Casus belli)",
                          [Action("Созвать военный совет", casus, ok, why)],
                          ["Пограничный инцидент или ультиматум — повод найдётся.",
                           "Доступно при напряжённости 70+ и не раньше чем через год после начала."]))
    else:
        for key, name in STANCES.items():
            mark = "■" if w.get("stance") == key else "□"

            def set_stance(key=key):
                w["stance"] = key
            items.append(Item(f"{mark} Приказ армии: {name}", [Action("Отдать приказ", set_stance, w.get("stance") != key, "уже выполняется")],
                              {"offensive": ["Фронт двигается быстрее, но выше потери и падает боевой дух."],
                               "balanced": ["Обычный режим ведения войны."],
                               "defensive": ["Минимальные потери, но инициатива у противника."]}[key]))

        def strike():
            eng.fire("SUPEREVENT_F02", {"reason": "order"})
        items.insert(0 if nuclear.can_strike(st, {}) else len(items), Item("☢ ЯДЕРНЫЙ УДАР",
                          [Action("Отдать приказ", strike, nuclear.can_strike(st, {}),
                                  "нет боеголовок или носителей")],
                          ["Применение ядерного оружия. Пути назад не будет.",
                           f"Боеголовок: {st.get('warheads'):.0f}, носителей: {st.get('bombers') + st.get('missiles'):.0f}"]))
    return TabView("ВОЙНА", header, items)


@registry.action("war.push_front")
def push_front(state, ctx, amount):
    state.war["front"] = max(-100.0, min(100.0, state.war["front"] + amount))
