"""Отрисовка в стиле текстового терминала: символьная сетка, рамки, CRT-эффект."""
import math
import os
import random
from contextlib import contextmanager

import pygame

from .. import config, settings

STYLE_ALIASES = {"bright": "b", "normal": "n", "dim": "d", "faint": "f", "inverse": "i",
                 "inverse_dim": "I"}
COLORS = {
    "b": (config.BRIGHT, None),
    "n": (config.NORMAL, None),
    "d": (config.DIM, None),
    "f": (config.FAINT, None),
    "i": (config.BG, config.INVERSE_BG),
    "I": (config.BG, config.DIM),
}

SINGLE = "┌┐└┘─│"
DOUBLE = "╔╗╚╝═║"


def _st(style):
    return STYLE_ALIASES.get(style, style)


def wrap(text, width):
    """Перенос по словам с сохранением абзацев."""
    out = []
    for para in text.split("\n"):
        if not para.strip():
            out.append("")
            continue
        line = ""
        for word in para.split(" "):
            while len(word) > width:
                if line:
                    out.append(line)
                    line = ""
                out.append(word[:width])
                word = word[width:]
            if not line:
                line = word
            elif len(line) + 1 + len(word) <= width:
                line += " " + word
            else:
                out.append(line)
                line = word
        out.append(line)
    return out


class Terminal:
    def __init__(self, cols=config.COLS, rows=config.ROWS):
        path = os.path.join(config.FONTS_DIR, config.FONT_FILE)
        try:
            self.font = pygame.font.Font(path, config.FONT_SIZE)
        except Exception:
            self.font = pygame.font.SysFont("dejavusansmono,consolas,couriernew,monospace", config.FONT_SIZE)
        self.cw, _ = self.font.size("M")
        self.ch = self.font.get_linesize()
        self.cols, self.rows = cols, rows
        self.size = (cols * self.cw, rows * self.ch)
        self.surface = pygame.Surface(self.size)
        self.cache = {}
        self.clips = []          # стек прямоугольников (x, y, w, h): текст за их пределы не выходит
        self.overflow = None     # список для отладки: сюда пишутся обрезанные строки

    @contextmanager
    def clip(self, x, y, w, h):
        """Всё, что выводится внутри блока with, обрезается по прямоугольнику (внутренность окна)."""
        if self.clips:
            px, py, pw, ph = self.clips[-1]
            x2, y2 = min(x + w, px + pw), min(y + h, py + ph)
            x, y = max(x, px), max(y, py)
            w, h = max(0, x2 - x), max(0, y2 - y)
        self.clips.append((x, y, w, h))
        try:
            yield
        finally:
            self.clips.pop()

    # ---------- примитивы ----------
    def clear(self):
        self.surface.fill(config.BG)

    def _render(self, text, st):
        key = (text, st)
        surf = self.cache.get(key)
        if surf is None:
            fg, bg = COLORS[st]
            surf = self.font.render(text, True, fg, bg) if bg else self.font.render(text, True, fg)
            if len(self.cache) > 4000:
                self.cache.clear()
            self.cache[key] = surf
        return surf

    def put(self, x, y, text, style="n", width=None):
        if not text:
            return
        cx, cy, cw, ch = self.clips[-1] if self.clips else (0, 0, self.cols, self.rows)
        if y < cy or y >= cy + ch:
            return
        full = text
        if width is not None and len(text) > width:
            if self.overflow is not None and text[width:].strip():
                self.overflow.append((x, y, full))
            text = text[: max(0, width - 1)] + "…" if width > 1 else text[:width]
        if x < cx:
            text = text[cx - x:]
            x = cx
        limit = cx + cw - x
        if len(text) > limit:
            if self.overflow is not None and text[limit:].strip():
                self.overflow.append((x, y, full))
            text = text[: max(0, limit - 1)] + "…" if limit > 1 and text[limit:].strip() else text[:max(0, limit)]
        if not text:
            return
        # как в настоящем терминале: символ заменяет то, что было в ячейке (рамку, линию и т.п.)
        self.surface.fill(config.BG, self.rect(x, y, len(text), 1))
        self.surface.blit(self._render(text, _st(style)), (x * self.cw, y * self.ch))

    def fill(self, x, y, w, h, style=None):
        color = config.BG
        if style and COLORS[_st(style)][1]:
            color = COLORS[_st(style)][1]
        self.surface.fill(color, self.rect(x, y, w, h))

    def rect(self, x, y, w, h):
        return pygame.Rect(x * self.cw, y * self.ch, w * self.cw, h * self.ch)

    def box(self, x, y, w, h, title=None, style="n", double=False, clear=True, title_style="b"):
        tl, tr, bl, br, hz, vt = DOUBLE if double else SINGLE
        if clear:
            self.fill(x, y, w, h)
        self.put(x, y, tl + hz * (w - 2) + tr, style)
        for yy in range(y + 1, y + h - 1):
            self.put(x, yy, vt, style)
            self.put(x + w - 1, yy, vt, style)
        self.put(x, y + h - 1, bl + hz * (w - 2) + br, style)
        if title:
            t = f" {title} "
            if len(t) > w - 4:
                t = t[: w - 6] + "… "
            self.put(x + 2, y, t, title_style)

    def hline(self, x, y, w, style="d", ch="─"):
        self.put(x, y, ch * w, style)

    def put_grid(self, x, y, chars, styles):
        """Вывод сетки символов, группируя одинаковые стили в отрезки."""
        for r, (row_c, row_s) in enumerate(zip(chars, styles)):
            if y + r >= self.rows:
                break
            start = 0
            n = len(row_c)
            while start < n:
                st = row_s[start]
                end = start + 1
                while end < n and row_s[end] == st:
                    end += 1
                seg = "".join(row_c[start:end])
                if seg.strip() or st in ("i", "I"):
                    self.put(x + start, y + r, seg, st)
                start = end


def recolor(src, tint, lift_rgb=(70, 70, 70)):
    """Перекрасить зелёный кадр в другой цвет люминофора: яркость берётся из картинки, оттенок — из tint."""
    gray = pygame.transform.grayscale(src)
    lift = gray.copy()
    gray.fill(tint, special_flags=pygame.BLEND_MULT)
    lift.fill(lift_rgb, special_flags=pygame.BLEND_MULT)    # чуть ярче: серый тусклее зелёного
    gray.blit(lift, (0, 0), special_flags=pygame.BLEND_ADD)
    return gray


class CRT:
    """Пост-обработка: свечение, скан-линии, бегущая полоса развёртки, виньетка, мерцание
    и рамка кинескопа — тёмный корпус со скруглёнными углами вокруг экрана."""

    PAD = 40          # ширина корпуса вокруг экрана, пикселей
    RADIUS = 44       # скругление углов экрана

    def __init__(self, size):
        self.src_size = size
        w, h = size
        p = self.PAD if config.CRT_FRAME else 0
        self.pad = p
        self.size = (w + 2 * p, h + 2 * p)
        W, H = self.size
        screen = pygame.Rect(0, 0, W, H).inflate(-2 * (p - 12), -2 * (p - 12)) if p else pygame.Rect(0, 0, W, H)
        self.screen = screen
        # скан-линии: тёмная строка через одну
        self.scan = pygame.Surface(self.size, pygame.SRCALPHA)
        for yy in range(0, H, 2):
            pygame.draw.line(self.scan, (0, 0, 0, 82), (0, yy), (W, yy))
        # полоса развёртки, медленно ползущая сверху вниз
        self.band = pygame.Surface((W, 90))
        for yy in range(90):
            v = int(9 * math.sin(math.pi * yy / 90) ** 2)
            pygame.draw.line(self.band, (v // 2, v, v // 2), (0, yy), (W, yy))
        # виньетка: края экрана темнее, как у выпуклого кинескопа (плавный градиент без колец)
        sw, sh = 64, 36
        small = pygame.Surface((sw, sh), pygame.SRCALPHA)
        for yy in range(sh):
            for xx in range(sw):
                dx = abs((xx + 0.5) / sw * 2 - 1)
                dy = abs((yy + 0.5) / sh * 2 - 1)
                d = max(0.0, (dx ** 6 + dy ** 6) ** (1 / 6) - 0.55) / 0.45
                small.set_at((xx, yy), (0, 0, 0, int(170 * min(1.0, d) ** 2)))
        self.vignette = pygame.Surface(self.size, pygame.SRCALPHA)
        self.vignette.blit(pygame.transform.smoothscale(small, screen.size), screen)
        self.bezel = self._bezel() if p else None
        self.rng = random.Random()
        self.t = 0.0
        self.out = pygame.Surface(self.size)

    def _bezel(self):
        W, H = self.size
        s = self.screen
        bez = pygame.Surface(self.size, pygame.SRCALPHA)
        # корпус: тёмный пластик с лёгким градиентом сверху вниз
        for yy in range(H):
            k = yy / H
            c = int(26 - 14 * k)
            pygame.draw.line(bez, (c, c + 4, c + 1, 255), (0, yy), (W, yy))
        # кромка вокруг стекла
        pygame.draw.rect(bez, (52, 62, 56, 255), s.inflate(6, 6), 2, border_radius=self.RADIUS + 3)
        pygame.draw.rect(bez, (6, 8, 7, 255), s.inflate(2, 2), 2, border_radius=self.RADIUS + 1)
        # отверстие под экран
        pygame.draw.rect(bez, (0, 0, 0, 0), s, 0, border_radius=self.RADIUS)
        # тень корпуса на стекле
        for i in range(16):
            a = int(200 * (1 - i / 16) ** 2)
            pygame.draw.rect(bez, (0, 0, 0, a), s.inflate(-2 * i, -2 * i), 1, border_radius=max(4, self.RADIUS - i))
        return bez

    def to_screen(self, pos):
        """Точка на кадре -> точка на терминале (без рамки)."""
        return pos[0] - self.pad, pos[1] - self.pad

    def process(self, src, dt=1 / 30):
        self.t += dt
        theme = config.THEMES[settings.theme()]
        tint = theme[1]
        if tint:
            src = recolor(src, tint, *theme[2:])
        out = self.out
        out.fill((0, 0, 0))
        p = self.pad
        out.blit(src, (p, p))
        if config.CRT_GLOW:
            w, h = self.src_size
            small = pygame.transform.smoothscale(src, (w // 4, h // 4))
            glow = pygame.transform.smoothscale(small, (w, h))
            glow.fill((110, 110, 110), special_flags=pygame.BLEND_MULT)
            out.blit(glow, (p, p), special_flags=pygame.BLEND_ADD)
        if config.CRT_SCANLINES:
            out.blit(self.scan, (0, 0))
            y = int(self.t * 70) % (self.size[1] + 90) - 90
            out.blit(self.band, (0, y), special_flags=pygame.BLEND_ADD)
        out.blit(self.vignette, (0, 0))
        if config.CRT_FLICKER and self.rng.random() < 0.08:
            out.fill((6, 6, 6), special_flags=pygame.BLEND_SUB)
        if self.bezel is not None:
            out.blit(self.bezel, (0, 0))
        return out
