"""Карта с владельцами: страны, осколки Рейха и России, захваты игрока и противника."""
from .. import pixelmap, worldmap
from ..mechanics import expansion, war
from ..mechanics.expansion import CONTROLLED

SIDE_CODE = {"burgundy": "B", "league": "V"}


def _seeds(game):
    data = game.territory_data
    german = [(t["id"], t["lon"], t["lat"]) for t in data["burgundy"]["territories"] if t["id"] != "baltic"]
    baltic = [(t["id"], t["lon"], t["lat"]) for t in data["burgundy"]["territories"] if t["id"] == "baltic"]
    home = data["league"]["home"]
    russian = [(t["id"], t["lon"], t["lat"]) for t in data["league"]["territories"]]
    russian.append(("home:league", home["lon"], home["lat"]))
    return {"G": german, "O": baltic, "L": russian}


# под каким государством территория, пока её никто не взял (код страны на карте)
FREE_CODE = {"moscow": "M", "central": "M", "don": "M", "baltic": "O", "rk_ostland": "O", "rk_norway": "N",
             "netherlands": "NL", "bohemia": "BM", "gg": "GG", "rk_ukraine": "K", "rk_moskowien": "M",
             "rk_kaukasien": "KV", "fr_brittany": "BR", "fr_paris": "R", "fr_normandy": "R", "fr_loire": "R",
             "fr_aquitaine": "R", "fr_occitania": "R", "fr_lyon": "R", "fr_provence": "R"}
GERMAN = {"rhineland", "westphalia", "hesse", "hannover", "bavaria", "saxony", "silesia", "berlin", "goering",
          "austria"}
ANNEXED = {"netherlands", "bohemia"}    # включены в Рейх: до гражданской войны красятся как Германия


def build(game, bounds, w, h, labels=True):
    """Возвращает (символы, стили, маркеры) — маркеры: [(символ, территория, стиль)]."""
    owner_of, fill_of = _owners(game)
    return _build_ascii(game, bounds, w, h, labels, owner_of, fill_of)


def _owners(game):
    st = game.state
    own = SIDE_CODE[st.side]
    enemy = SIDE_CODE[st.enemy_side]
    defs = expansion.all_defs(game)
    civil_war = st.has_flag("german_civil_war")

    def owner_of(code):
        if code in defs:
            h = expansion.holder(st, code)
            if h == "me":
                t = st.territories.get(code)
                return "P:" + code if t and t["status"] in ("puppet", "allied") else own
            if h == "enemy":
                return enemy
            if (code in GERMAN or code in ANNEXED) and not civil_war:
                return "G"
            if h:
                return "r:" + h
            return FREE_CODE.get(code, "t:" + code)
        if code == "home:league":
            return "V"
        if code.endswith(":wild"):
            return "wild"
        return code

    def fill_of(o):
        if o == own:
            return "▒", "n"
        if o == enemy:
            return "▓", "d"
        if o.startswith(("P:", "r:")):
            return "░", "n"
        if o.startswith("t:"):
            return "·", "n"
        if o == "wild":
            return "·", "f"
        return "·", "d"

    return owner_of, fill_of


def _labels(game):
    st = game.state
    own = SIDE_CODE[st.side]
    enemy = SIDE_CODE[st.enemy_side]
    data = game.territory_data
    civil_war = st.has_flag("german_civil_war")
    names = []
    for code, (name, (lon, lat)) in worldmap.COUNTRIES.items():
        if code == "G" and civil_war:
            continue   # после распада Рейха Германия показана осколками с номерами
        style = "b" if code in (own, enemy) else "n"
        names.append((name, lon, lat, style))
    return names


def _markers(game, group=None):
    """Метки целей: номер в своей вкладке (для Франции — с буквой «Ф»). group=None — все вкладки."""
    st = game.state
    cfg = game.expansion_cfg
    groups = {"main": ("absorption" if st.side == "burgundy" else "unification", "")}
    for g, gc in cfg.get("groups", {}).items():
        if "tab" in gc:
            groups[g] = (gc["tab"], gc.get("prefix", ""))
    markers = []
    for g, (tab_key, prefix) in groups.items():
        if tab_key not in st.tabs or (group is not None and g != group):
            continue
        terrs = [t for t in st.territories.values() if expansion.group_of(t) == g]
        for i, t in enumerate(terrs, 1):
            if t["status"] == "destroyed":
                m = ("×", t, "b")
            elif t["status"] in CONTROLLED:
                m = ("■", t, "b")
            else:
                m = (prefix + str(i), t, "i" if t.get("op") else "b")
            markers.append(m)
    return markers


def _build_ascii(game, bounds, w, h, labels, owner_of, fill_of):
    regions = worldmap.rasterize(bounds, w, h, _seeds(game))
    chars, styles = worldmap.render(regions, owner_of, fill_of)
    if labels:
        worldmap.place_labels(chars, styles, bounds, w, h, _labels(game))
    markers = _markers(game)
    for m in markers:
        t = m[1]
        c, r = worldmap.project(bounds, w, h, t["lon"], t["lat"])
        c = min(w - 1, max(0, c))
        if 0 <= r < h:
            chars[r][c] = m[0] if len(m[0]) == 1 else "0"
            styles[r][c] = m[2]
    return chars, styles, markers


# ---------- подробная (пиксельная) карта ----------
FILLS = {
    "own": ((34, 112, 56), None),
    "enemy": ((18, 62, 32), ("stripes", (55, 175, 90))),
    "puppet": ((24, 86, 44), ("dots", (90, 230, 130))),
    "rival": ((20, 70, 36), None),
    "wild": ((8, 30, 16), None),
    "country": ((12, 45, 24), None),
}


def build_pixel(game, bounds, size, font, labels=True, cursor=None, home=None, group=None):
    """Подробная карта: (поверхность pygame, маркеры). home = {"name", "lon", "lat"} — звезда столицы."""
    st = game.state
    own = SIDE_CODE[st.side]
    enemy = SIDE_CODE[st.enemy_side]
    owner_of, _ = _owners(game)

    def fill_of(o):
        if o == own:
            return FILLS["own"]
        if o == enemy:
            return FILLS["enemy"]
        if o.startswith("P:"):
            return FILLS["puppet"]
        if o.startswith("r:"):
            return FILLS["rival"]
        if o == "wild" or o.endswith(":wild"):
            return FILLS["wild"]
        return FILLS["country"]

    codes = pixelmap.regions(None)
    owners = [owner_of(c) for c in codes]
    _advance(game, codes, owners)
    base, proj, centers = pixelmap.base(bounds, size, owners, lambda o: o, fill_of)
    surf = base.copy()
    taken = []
    markers = _markers(game, group)
    for i, (mark, t, style) in enumerate(markers):
        r = pixelmap.draw_marker(surf, font, proj(t["lon"], t["lat"]), mark,
                                 selected=(i == cursor), active=(style == "i"))
        taken.append(r.inflate(4, 2))
    if home:
        x, y = proj(home["lon"], home["lat"])
        star = pixelmap._text(surf, font, "★", (x, y), pixelmap.BORDER)
        pixelmap.draw_labels(surf, proj, font, [(home["name"], home["lon"], home["lat"] + 0.9 * 19 / proj.sy, True)],
                             taken, clamp=True)
        taken.append(star)
    if labels:
        names = {}
        civil_war = st.has_flag("german_civil_war")
        for code, (name, _) in worldmap.COUNTRIES.items():
            if code == "G" and civil_war:
                continue
            names[code] = ([name], code in (own, enemy))
        for side in ("burgundy", "league"):
            for t in game.territory_data[side]["territories"]:
                full = t["name"].split(" (")[0].upper()
                alt = [SHARD_NAME.get(t["id"], full)]
                names["t:" + t["id"]] = (alt, False)
                names["P:" + t["id"]] = (alt, False)
                if t.get("rival"):
                    names["r:" + t["id"]] = (alt, False)
        for rid, (_, rc) in expansion.rivals(game).items():
            if rc.get("no_core"):
                names["r:" + rid] = (["МАРИОНЕТКА ИТАЛИИ" if rc.get("puppet") else rc["name"].upper()], False)
        pixelmap.draw_country_labels(surf, proj, centers, names, taken)
    return surf, markers


def _advance(game, codes, owners):
    """Постепенный захват: области переходят к наступающему целиком, по одной, начиная с ближайших
    к его землям (операции игрока, противника и соперников, линия фронта войны). Меняет owners."""
    st = game.state
    own = SIDE_CODE[st.side]
    enemy = SIDE_CODE[st.enemy_side]
    provs = pixelmap._data()
    by_code = {}
    for i, c in enumerate(codes):
        by_code.setdefault(c, []).append(i)

    def take(ix, attacker, frac):
        ix = [i for i in ix if owners[i] != attacker]
        n = int(len(ix) * min(1.0, frac) + 0.5)
        if not ix or n <= 0:
            return
        mine = [i for i, o in enumerate(owners) if o == attacker]
        if not mine:
            return
        # откуда идёт наступление: соседние области захватчика, иначе все его земли
        near = [j for i in ix for j in provs[i].get("n", []) if owners[j] == attacker] or mine
        ox = sum(provs[i]["x"] for i in near) / len(near)
        oy = sum(provs[i]["y"] for i in near) / len(near)

        def dist(i):
            return (provs[i]["x"] - ox) ** 2 + (provs[i]["y"] - oy) ** 2
        # занимаем сплошным куском: каждый раз ближайшую область, граничащую с уже занятым
        left = set(ix)
        front = {i for i in ix if any(owners[j] == attacker for j in provs[i].get("n", []))}
        if not front:   # через море (Норвегия, Прибалтика): высадка в ближайшей точке
            front = {min(left, key=dist)}
        for _ in range(n):
            pool = front & left
            if not pool:   # дальше сплошного куска не прыгаем
                break
            i = min(pool, key=dist)
            owners[i] = attacker
            left.discard(i)
            front |= set(provs[i].get("n", [])) & left

    for t in st.territories.values():
        if t.get("op") and t["progress"] > 0:
            take(by_code.get(t["id"], []), own, t["progress"] / 100)
    for actor, op in st.vars.get("ai_ops", {}).items():
        take(by_code.get(op["t"], []), enemy if actor == "enemy" else "r:" + actor, op["p"] / 100)
    # война: бой идёт за одну землю на линии соприкосновения (war.battle), остальное — настоящие захваты
    for attacker, tid, frac in war.battles(st):
        take(by_code.get(tid, []), own if attacker == "me" else enemy, frac)


# подписи осколков на карте (как названия у TNO)
SHARD_NAME = {
    "volga": "САМАРА (КОНР)", "vyatka": "ВЯТСКАЯ МОНАРХИЯ", "arkhangelsk": "ЗАПАДНОРУССКИЙ ФРОНТ",
    "central": "КОМИТЕТ ЦЕНТРАЛЬНОЙ РОССИИ", "don": "ДОНСКОЕ ВОЙСКО", "urals": "УРАЛЬСКАЯ ВОЕННАЯ ЗОНА",
    "siberia": "ТЮМЕНСКИЙ СОВЕТ", "moscow": "МОСКВА", "komi": "РЕСПУБЛИКА КОМИ",
    "gayny": "АРИЙСКОЕ БРАТСТВО", "gorky": "ГОРЬКОВСКАЯ ДИРЕКТОРИЯ", "tatarstan": "ТАТАРСТАН",
    "bashkiria": "БАШКИРИЯ", "orenburg": "ОРЕНБУРГСКИЕ КОММУНЫ", "yugra": "ЮГРА", "sib_east": "ТОМСКАЯ РЕСПУБЛИКА",
    "rhineland": "РЕЙНЛАНД", "westphalia": "ВЕСТФАЛИЯ", "hesse": "ГЕССЕН", "hannover": "ГАННОВЕР",
    "austria": "ОСТМАРК", "bavaria": "БАВАРИЯ", "saxony": "САКСОНИЯ", "silesia": "СИЛЕЗИЯ", "baltic": "ПРИБАЛТИКА",
    "berlin": "БЕРЛИН", "goering": "ВОЙСКА ГЕРИНГА", "netherlands": "Р.К. НИДЕРЛАНДЫ",
    "bohemia": "БОГЕМИЯ И МОРАВИЯ", "gg": "ГЕНЕРАЛ-ГУБЕРНАТОРСТВО", "rk_norway": "Р.К. НОРВЕГИЯ",
    "rk_ostland": "Р.К. ОСТЛАНД", "rk_ukraine": "Р.К. УКРАИНА", "rk_moskowien": "Р.К. МОСКОВИЯ",
    "rk_kaukasien": "Р.К. КАВКАЗ", "fr_paris": "ПАРИЖ", "fr_normandy": "НОРМАНДИЯ", "fr_brittany": "БРЕТАНЬ",
    "fr_loire": "ДОЛИНА ЛУАРЫ", "fr_aquitaine": "АКВИТАНИЯ", "fr_occitania": "ОКСИТАНИЯ", "fr_lyon": "ЛИОН И ОВЕРНЬ",
    "fr_provence": "ПРОВАНС",
}
