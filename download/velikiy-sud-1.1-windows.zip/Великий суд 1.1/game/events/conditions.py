"""Язык условий для ивентов и вариантов выбора.

Условие — словарь; все ключи в словаре должны выполняться (логическое И).
Список условий — тоже И. Поддерживаемые ключи:

  day_gte / day_lte: N              — игровой день >= / <= N
  day_gte_var: "var" | ["var", off] — день >= значение переменной (+смещение)
  stat_gte / stat_lte: {"stat": N}  — показатели
  relation_gte / relation_lte: {"faction": N}
  flag / not_flag: "имя" | [...]    — флаги состояния
  flag_age_gte: ["флаг", N]         — флаг установлен не менее N дней назад
  var_eq: {"var": value}
  side: "burgundy" | "league"
  fired / not_fired: "EVENT_ID"     — ивент уже был / ещё не был
  chose: ["EVENT_ID", индекс]       — игрок выбирал вариант с индексом
  not_chose: ["EVENT_ID", индекс]
  war: true | false                 — идёт ли война
  tab_open: "absorption"
  func: "имя" | ["имя", арг...]     — функция механики из реестра
  all: [...], any: [...], not: {...}
"""
from .. import registry


def _as_list(v):
    return v if isinstance(v, list) else [v]


def check(cond, state, ctx=None):
    if cond is None:
        return True
    ctx = ctx or {}
    if isinstance(cond, list):
        return all(check(c, state, ctx) for c in cond)
    for key, val in cond.items():
        if not _check_one(key, val, state, ctx):
            return False
    return True


def _resolve(arg, ctx):
    if isinstance(arg, str) and arg.startswith("$"):
        return ctx.get(arg[1:])
    return arg


def _check_one(key, val, state, ctx):
    if key == "day_gte":
        return state.day >= val
    if key == "day_lte":
        return state.day <= val
    if key == "day_gte_var":
        name, off = (val, 0) if isinstance(val, str) else val
        return state.day >= state.vars.get(name, 10 ** 9) + off
    if key == "stat_gte":
        return all(state.get(k) >= v for k, v in val.items())
    if key == "stat_lte":
        return all(state.get(k) <= v for k, v in val.items())
    if key == "relation_gte":
        return all(state.relations.get(k, 0) >= v for k, v in val.items())
    if key == "relation_lte":
        return all(state.relations.get(k, 0) <= v for k, v in val.items())
    if key == "flag":
        return all(state.has_flag(f) for f in _as_list(val))
    if key == "not_flag":
        return not any(state.has_flag(f) for f in _as_list(val))
    if key == "flag_age_gte":
        return state.flag_age(val[0]) >= val[1]
    if key == "var_eq":
        return all(state.vars.get(k) == v for k, v in val.items())
    if key == "side":
        return state.side in _as_list(val)
    if key == "fired":
        return all(e in state.fired for e in _as_list(val))
    if key == "not_fired":
        return not any(e in state.fired for e in _as_list(val))
    if key == "chose":
        return val[1] in state.choices.get(val[0], [])
    if key == "not_chose":
        return val[1] not in state.choices.get(val[0], [])
    if key == "war":
        return bool(state.war["active"]) == bool(val)
    if key == "tab_open":
        return val in state.tabs
    if key == "func":
        name, *args = _as_list(val)
        fn = registry.PREDICATES[name]
        return bool(fn(state, ctx, *[_resolve(a, ctx) for a in args]))
    if key == "all":
        return all(check(c, state, ctx) for c in val)
    if key == "any":
        return any(check(c, state, ctx) for c in val)
    if key == "not":
        return not check(val, state, ctx)
    raise ValueError(f"Неизвестное условие: {key}")
