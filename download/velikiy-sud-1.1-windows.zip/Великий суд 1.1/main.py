"""ВЕЛИКИЙ СУД — точка входа.

    python main.py              — запуск в окне
    python main.py --fullscreen — во весь экран (F11 переключает)
    python main.py --no-sound   — без звука
"""
import os
import sys

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main():
    from game.ui.app import App
    App(fullscreen="--fullscreen" in sys.argv, sound="--no-sound" not in sys.argv).run()


if __name__ == "__main__":
    main()
