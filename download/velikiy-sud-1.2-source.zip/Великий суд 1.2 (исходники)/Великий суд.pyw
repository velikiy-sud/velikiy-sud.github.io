"""Запуск «Великого суда» двойным кликом: сразу окно игры, без командной строки (Windows, pythonw)."""
import os
import subprocess
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
sys.path.insert(0, HERE)


def ensure_pygame():
    try:
        import pygame  # noqa: F401
    except ImportError:
        exe = sys.executable
        if exe.lower().endswith("pythonw.exe"):
            exe = exe[:-len("pythonw.exe")] + "python.exe"
        flags = 0x08000000 if os.name == "nt" else 0       # CREATE_NO_WINDOW: pip без чёрного окна
        subprocess.run([exe, "-m", "pip", "install", "-r", "requirements.txt"], creationflags=flags)


try:
    ensure_pygame()
    import main
    main.main()
except Exception:
    with open(os.path.join(HERE, "crash.log"), "w", encoding="utf-8") as f:
        traceback.print_exc(file=f)
    if os.name == "nt":
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, "Игра упала. Подробности в файле crash.log рядом с игрой.\n"
                                         "The game crashed. See crash.log next to the game.",
                                         "Великий суд", 0x10)
