"""Снимки экранов в безголовом режиме: python -m tests.screenshots <папка>"""
import os
import sys

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame  # noqa: E402

from game.core import Game  # noqa: E402
from game.ui.app import App  # noqa: E402
from game.ui.screens import EndScreen, GameScreen  # noqa: E402

out = sys.argv[1] if len(sys.argv) > 1 else "shots"
os.makedirs(out, exist_ok=True)
app = App(sound=False)


def shot(name, dt=0.0):
    app.screen.update(dt)
    app.screen.draw(app.term)
    pygame.image.save(app.crt.process(app.term.surface), os.path.join(out, name + ".png"))


def key(k, mod=0):
    app.screen.handle(pygame.event.Event(pygame.KEYDOWN, key=k, mod=mod, unicode=""))


shot("02_select", 0.1)
key(pygame.K_DOWN)
shot("03_select_league", 0.1)

side = sys.argv[2] if len(sys.argv) > 2 else "burgundy"
g = Game(side, seed=3)
scr = GameScreen(app, g)
app.set_screen(scr)
shot("04_event001", 0.1)


def resolve_all(pick=0, play=True):
    while g.engine.queue:
        ev = g.engine.current()
        scr.update(0.05)
        if ev.superevent and play:
            scr.player.skip()
            scr.update(0.05)
        opts = [o for o in ev.options(g.state) if o[2]]
        scr.choose_option(opts[min(pick, len(opts) - 1)])


resolve_all()
shot("05_map", 0.1)
scr.zoom_map(2.0)
shot("05b_map_zoom", 0.05)
scr.zoom_map(0.5)
# дойти до суперивента гражданской войны
for _ in range(60):
    g.tick()
    ev = g.engine.current()
    if ev and ev.superevent:
        break
    if ev:
        resolve_all()
scr.update(0.05)
scr.player.t = 4.0
shot("06_superevent_video", 0.0)
scr.player.skip()
shot("07_superevent_choice", 0.05)
resolve_all()
for _ in range(10):
    g.tick()
    resolve_all()
tab = "absorption" if side == "burgundy" else "unification"
if tab in g.state.tabs:
    scr.set_tab(tab)
    shot("08_expansion", 0.05)
g.state.add("treasury", 500)
scr.set_tab("army")
shot("09_army", 0.05)
scr.set_tab("nuclear")
key(pygame.K_RETURN)
scr.update(0.05)
shot("10_w01_event", 0.05)
resolve_all()
g.state.set("nuke_research", 99.9)
g.state.add("nuke_materials", 10)
g.tick()
scr.update(0.05)
scr.player.t = 3.6
shot("11_nuke_test", 0.0)
scr.player.t = 7.0
shot("12_nuke_test_late", 0.0)
resolve_all()
for _ in range(15):
    g.tick()
    resolve_all()
scr.set_tab("nuclear")
shot("13_nuclear_tab", 0.05)
scr.set_tab("diplomacy")
shot("14_diplomacy", 0.05)
g.state.set("tension", 80)
scr.set_tab("war")
shot("15_war_tab", 0.05)
g.engine.fire("EVENT_F01")
scr.update(0.05)
shot("16_f01", 0.05)
scr.choose_option(g.engine.current().options(g.state)[0])
scr.update(0.05)
scr.player.t = 4.0
shot("17_war_video", 0.0)
resolve_all()
for _ in range(20):
    g.tick()
    resolve_all()
g.state.add("warheads", 3)
g.state.add("bombers", 2)
shot("18_war_front", 0.05)
g.engine.fire("SUPEREVENT_F02")
scr.update(0.05)
scr.player.t = 5.0
shot("19_launch", 0.0)
scr.player.skip()
scr.update(0.05)
shot("19b_launch_choice", 0.0)
resolve_all()
scr.set_tab("log")
shot("20_log", 0.05)
g.engine.fire("SUPEREVENT_F03")
scr.update(0.05)
scr.player.t = 5.0
shot("21_ash", 0.0)
resolve_all()
scr.update(1.0)
app.screen.update(30)
shot("22_epilogue", 0.0)
print("готово:", out)
