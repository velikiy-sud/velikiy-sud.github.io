"""Сборка data/map_provinces.json из открытых данных Natural Earth (общественное достояние).

Запуск (нужно один раз, игра читает готовый JSON):
    python tools/build_map.py ne_10m_admin_0_countries.geojson ne_10m_admin_1_states_provinces.geojson

Крупные страны берутся по областям (admin-1), остальные — целиком (admin-0). Каждой области
присваивается страна мира 1962 года по таблицам ниже (по картам TNO 1962), а осколкам Рейха и
России — территория из data/territories.json. Контуры упрощаются и обрезаются по рамке Европы.
"""
import json
import math
import os
import sys


BOUNDS = (-26.0, 76.0, 33.5, 74.0)          # lon0, lon1, lat0, lat1
TOLERANCE = 0.035                             # градусы, упрощение Дугласа — Пекера
MIN_AREA = 0.004                              # кв. градусы: мельче — выбрасываем островок
BY_PROVINCE = {"RUS", "UKR", "FRA", "DEU", "POL", "CZE", "AUT", "GBR", "GRC", "HRV", "ESP", "ITA", "TUR", "SWE",
               "NOR", "FIN", "ROU", "BLR", "KAZ", "LTU"}   # где есть линии областей и деление по областям
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "map_provinces.json")


def rings_of(geom):
    if geom["type"] == "Polygon":
        return [geom["coordinates"][0]]
    if geom["type"] == "MultiPolygon":
        return [p[0] for p in geom["coordinates"]]
    return []


def area(r):
    return abs(sum(r[i][0] * r[i - 1][1] - r[i - 1][0] * r[i][1] for i in range(len(r)))) / 2


def centroid(r):
    a = cx = cy = 0.0
    for i in range(len(r)):
        x0, y0 = r[i - 1]
        x1, y1 = r[i]
        f = x0 * y1 - x1 * y0
        a += f
        cx += (x0 + x1) * f
        cy += (y0 + y1) * f
    if abs(a) < 1e-12:
        return r[0]
    return cx / (3 * a), cy / (3 * a)


def simplify(pts, tol):
    if len(pts) < 4:
        return pts
    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        a, b = stack.pop()
        ax, ay = pts[a]
        bx, by = pts[b]
        dx, dy = bx - ax, by - ay
        L = math.hypot(dx, dy) or 1e-12
        best, bi = -1, -1
        for i in range(a + 1, b):
            px, py = pts[i]
            d = abs(dy * px - dx * py + bx * ay - by * ax) / L if (dx or dy) else math.hypot(px - ax, py - ay)
            if d > best:
                best, bi = d, i
        if best > tol:
            keep[bi] = True
            stack += [(a, bi), (bi, b)]
    return [p for p, k in zip(pts, keep) if k]


# Страны мира 1962 года (по картам TNO 1962) по современным странам (ISO A3) и областям.
# Код страны — ключ в game/worldmap.COUNTRIES. Territory — id территории из data/territories.json
# (осколки Рейха и России, которые можно захватить).
BY_COUNTRY = {
    "BEL": "B", "LUX": "B", "NLD": "NL", "DEU": "G", "AUT": "G", "CZE": "BM", "POL": "G", "SVN": "T",
    "DNK": "G", "NOR": "N", "SWE": "S", "FIN": "F", "ISL": "IS", "IRL": "I", "GBR": "EN",
    "EST": "O", "LVA": "O", "LTU": "O", "BLR": "O", "UKR": "K", "MDA": "A", "ROU": "A",
    "ITA": "T", "SMR": "T", "VAT": "T", "MLT": "T", "ALB": "T", "MNE": "T", "CYP": "Y",
    "HRV": "C", "BIH": "C", "SRB": "D", "KOS": "D", "MKD": "Z", "BGR": "Z", "HUN": "H", "SVK": "SK",
    "GRC": "T", "TUR": "Y", "ESP": "E", "PRT": "E", "CHE": "W", "LIE": "W", "KAZ": "KZ",
    "GEO": "KV", "ARM": "KV", "AZE": "KV", "RUS": "WS", "FRA": "R", "AND": "E", "MCO": "T",
    "ALD": "F", "FRO": "DK", "GGY": "EN", "JEY": "EN", "IMN": "EN", "BRT": "KZ", "KAB": "KZ",
    "CNM": "Y", "CYN": "Y", "ESB": "Y", "WSB": "Y", "PSX": "ISR",
}
BY_PROVINCE_NAME = {
    "FRA": {
        "B": ["Nord", "Pas-de-Calais", "Somme", "Aisne", "Ardennes", "Marne", "Aube", "Haute-Marne", "Meuse",
              "Meurthe-et-Moselle", "Haute-Saône", "Doubs", "Jura", "Côte-d'Or", "Yonne", "Saône-et-Loire", "Ain"],
        "BR": ["Finistère", "Côtes-d'Armor", "Morbihan", "Ille-et-Vilaine"],
        "T": ["Savoie", "Haute-Savoie", "Alpes-Maritimes", "Corse-du-Sud", "Haute-Corse"],
    },
    "POL": {
        "GG": ["Masovian", "Łódź", "Świętokrzyskie", "Lublin", "Lesser Poland", "Subcarpathian"],
    },
    "UKR": {
        "GG": ["L'viv", "Ivano-Frankivs'k", "Ternopil'"],
        "A": ["Odessa", "Chernivtsi", "Mykolayiv"],   # Транснистрия и Буковина — у Румынии
        "H": ["Transcarpathia"],
        "M": ["Sumy"],
    },
    "HRV": {
        "T": ["Istarska", "Primorsko-Goranska", "Zadarska", "Šibensko-Kninska", "Splitsko-Dalmatinska",
              "Dubrovacko-Neretvanska"],
    },
    "ROU": {   # Северная Трансильвания — у Венгрии
        "H": ["Satu Mare", "Maramures", "Salaj", "Bihor", "Cluj", "Bistrita-Nasaud", "Mures", "Harghita", "Covasna"],
        "Z": ["Constanta", "Tulcea"],   # Северная Добруджа — у Болгарии
    },
    "GRC": {
        # Греция поделена: большая часть — Италии (по умолчанию), Македония и Фракия — Болгарии
        "Z": ["Anatoliki Makedonia kai Thraki", "Kentriki Makedonia", "Agion Oros"],
    },
    "GBR": {
        "CW": ["Cornwall"],
    },
    "RUS": {
        "F": ["Karelia", "Murmansk", "Leningrad", "City of St. Petersburg"],
        "M": ["Novgorod", "Pskov", "Smolensk", "Bryansk", "Kursk",
              "Belgorod", "Orel", "Lipetsk", "Voronezh", "Tambov", "Penza", "Saratov", "Mordovia", "Tver'",
              "Yaroslavl'", "Ivanovo", "Vladimir", "Kostroma"],
        "KV": ["Adygey", "Krasnodar", "Stavropol'", "Karachay-Cherkess", "Kabardin-Balkar", "North Ossetia",
               "Ingush", "Chechnya", "Dagestan", "Kalmyk", "Astrakhan'"],
        "G": ["Crimea", "Sevastopol", "Kaliningrad"],
        "WK": ["Komi"],
        "WG": ["Nizhegorod", "Chuvash", "Mariy-El"],
        "WT": ["Tatarstan"],
        "WP": ["Perm'"],
        "WB": ["Bashkortostan"],
        "WO": ["Orenburg"],
        "WY": ["Khanty-Mansiy", "Yamal-Nenets"],
    },
}
# Шотландия, Уэльс, Северная Ирландия — по полю geonunit у областей Великобритании
GBR_UNITS = {"Scotland": "SC", "Wales": "WA", "Northern Ireland": "I"}
TERRITORY = {
    # осколки Рейха и войска Геринга (Бургундия)
    "rhineland": ["Rheinland-Pfalz", "Saarland", "Moselle"], "westphalia": ["Nordrhein-Westfalen"],
    "hesse": ["Hessen", "Baden-Württemberg", "Bas-Rhin", "Haute-Rhin", "Territoire de Belfort", "Vosges"],   # Эльзас — Рейху "hannover": ["Niedersachsen", "Bremen", "Hamburg", "Schleswig-Holstein"],
    "bavaria": ["Bayern"], "saxony": ["Sachsen", "Thüringen", "Sachsen-Anhalt"],
    "silesia": ["Lower Silesian", "Opole", "Silesian", "Greater Poland", "Lubusz"], "berlin": ["Berlin", "Brandenburg"],
    "goering": ["Mecklenburg-Vorpommern", "West Pomeranian", "Pomeranian", "Kuyavian-Pomeranian", "Warmian-Masurian",
                "Podlachian", "Kaliningrad", "Klaipedos", "Crimea", "Sevastopol"],   # Крым — Готенгау
    "austria": ["@AUT"], "baltic": ["@EST", "@LVA", "@LTU", "Pskov"],
    # рейхскомиссариаты и протектораты
    "rk_ostland": ["@BLR"], "rk_norway": ["@NOR"], "netherlands": ["@NLD"], "bohemia": ["@CZE"],
    "gg": ["Masovian", "Łódź", "Świętokrzyskie", "Lublin", "Lesser Poland", "Subcarpathian", "L'viv",
           "Ivano-Frankivs'k", "Ternopil'"],
    "rk_ukraine": ["@UKR"],
    "rk_moskowien": ["Novgorod", "Smolensk", "Bryansk", "Kursk",
                     "Belgorod", "Orel", "Lipetsk", "Voronezh", "Tambov", "Penza", "Saratov", "Mordovia", "Tver'",
                     "Yaroslavl'", "Ivanovo", "Vladimir", "Sumy", "Chernihiv"],
    "rk_kaukasien": ["Adygey", "Krasnodar", "Stavropol'", "Karachay-Cherkess", "Kabardin-Balkar", "North Ossetia",
                     "Ingush", "Chechnya", "Dagestan", "Astrakhan'", "@GEO", "@ARM", "@AZE"],
    # Французское государство (цели Бургундии)
    "fr_paris": ["Paris", "Hauts-de-Seine", "Seine-Saint-Denis", "Val-d'Oise", "Yvelines", "Essonne", "Seien-et-Marne",
                 "Val-de-Marne", "Oise"],
    "fr_normandy": ["Manche", "Calvados", "Eure", "Seine-Maritime", "Orne"],
    "fr_brittany": ["Morbihan", "Finistère", "Côtes-d'Armor", "Ille-et-Vilaine"],
    "fr_loire": ["Vendée", "Loire-Atlantique", "Mayenne", "Sarthe", "Maine-et-Loire", "Indre-et-Loire", "Indre",
                 "Loir-et-Cher", "Loiret", "Cher", "Eure-et-Loir", "Nièvre"],
    "fr_aquitaine": ["Pyrénées-Atlantiques", "Landes", "Gironde", "Charente-Maritime", "Haute-Vienne", "Corrèze",
                     "Creuse", "Dordogne", "Charente", "Lot-et-Garonne", "Deux-Sèvres", "Vienne"],
    "fr_occitania": ["Haute-Garonne", "Hautes-Pyrénées", "Ariège", "Pyrénées-Orientales", "Gard", "Hérault", "Aude",
                     "Gers", "Tarn-et-Garonne", "Tarn", "Aveyron", "Lot", "Lozère"],
    "fr_lyon": ["Isère", "Drôme", "Rhône", "Ardèche", "Loire", "Puy-de-Dôme", "Allier", "Haute-Loire", "Cantal"],
    "fr_provence": ["Alpes-de-Haute-Provence", "Hautes-Alpes", "Var", "Bouches-du-Rhône", "Vaucluse"],
    # осколки России (Чёрная Лига); Москва, Центр и Дон — под Рейхскомиссариатом Московия
    "moscow": ["Moskva", "Moskovskaya"], "central": ["Tula", "Ryazan'", "Kaluga"], "don": ["Rostov", "Volgograd", "Kalmyk"],
    "volga": ["Samara", "Ul'yanovsk"], "vyatka": ["Kirov", "Udmurt"], "arkhangelsk": ["Arkhangel'sk", "Nenets"],
    "urals": ["Sverdlovsk", "Chelyabinsk"], "siberia": ["Tyumen'", "Kurgan", "Omsk"], "komi": ["Komi"],
    "gayny": ["Perm'"], "gorky": ["Nizhegorod", "Chuvash", "Mariy-El"], "tatarstan": ["Tatarstan"],
    "bashkiria": ["Bashkortostan"], "orenburg": ["Orenburg"], "yugra": ["Khanty-Mansiy", "Yamal-Nenets", "RUS"],   # "RUS" — безымянный кусок Ямала
    "sib_east": ["Novosibirsk", "Tomsk"],
    "home:league": ["Vologda", "Kostroma"],
}
# Области, разрезанные по линиям Андрея (2026-10-30): кусок внутри многоугольника (долгота, широта)
# отходит другой стране/территории. Север Коми — Западнорусскому фронту, юго-запад Ленобласти — Прибалтике,
# Тихвин — Р.К. Московия, северо-восток Башкирии — Уралу, юг Словакии — Венгрии, север Словении — Рейху,
# Эгейские острова восточнее 25.9° (Лесбос, Хиос, Самос, Додеканес) — Турции.
SPLITS = [   # (ISO A3, область, код страны, территория, многоугольник)
    ("RUS", "Komi", "WS", 'arkhangelsk', [[46.98, 63.3], [49.16, 64.05], [50.68, 63.7], [52.78, 64.16], [53.92, 64.97], [55.44, 65.49], [57.91, 65.67], [60.0, 66.07], [61.72, 67.06], [64.95, 67.63], [66.47, 69.66], [45.55, 69.66], [45.55, 63.3]]),
    ("RUS", "Leningrad", "O", 'baltic', [[27.04, 59.36], [27.8, 59.36], [28.94, 59.44], [29.95, 59.36], [30.59, 59.09], [30.74, 58.63], [30.74, 57.4], [27.04, 57.4]]),
    ("RUS", "Leningrad", "M", 'rk_moskowien', [[33.22, 60.17], [35.66, 60.33], [35.66, 57.86], [34.01, 58.78], [33.25, 59.32]]),
    ("RUS", "Bashkortostan", "WS", 'urals', [[57.21, 57.01], [62.54, 57.01], [62.54, 55.24], [57.21, 55.24]]),
    ("SVK", "Slovakia", "H", None, [[16.33, 48.42], [16.94, 48.42], [18.16, 48.33], [19.07, 48.51], [20.44, 48.7], [22.42, 49.07], [23.33, 49.07], [23.33, 46.57], [16.33, 46.57]]),
    ("GRC", "Notio Aigaio", "Y", None, [[25.9, 34.0], [30.0, 34.0], [30.0, 41.0], [25.9, 41.0]]),
    ("GRC", "Voreio Aigaio", "Y", None, [[25.9, 34.0], [30.0, 34.0], [30.0, 41.0], [25.9, 41.0]]),
    ("SVN", "Slovenia", "G", 'austria', [[13.41, 46.52], [13.79, 46.06], [14.45, 45.94], [15.21, 46.12], [15.88, 46.41], [16.26, 46.64], [16.35, 46.87], [16.45, 47.97], [13.03, 47.97], [13.03, 46.52]]),
]
# код страны на карте, пока территория ничья
TERRITORY_CODE = {"moscow": "M", "central": "M", "don": "M", "home:league": "V", "baltic": "O", "rk_ostland": "O",
                  "rk_norway": "N", "netherlands": "NL", "bohemia": "BM", "gg": "GG", "rk_ukraine": "K",
                  "rk_moskowien": "M", "rk_kaukasien": "KV",
                  "fr_brittany": "BR", **{t: "R" for t in ("fr_paris", "fr_normandy", "fr_loire", "fr_aquitaine",
                                                             "fr_occitania", "fr_lyon", "fr_provence")}}
GERMAN = {"rhineland", "westphalia", "hesse", "hannover", "bavaria", "saxony", "silesia", "berlin", "goering", "austria"}
# что остаётся на карте: Европа, Турция, Кавказ и Казахстан (всё южнее — убрано)
KEEP = {"B", "G", "GG", "BM", "NL", "N", "S", "F", "EN", "SC", "WA", "CW", "I", "R", "BR", "E", "W", "T", "O", "K",
        "M", "KV", "H", "A", "Z", "C", "D", "Q", "Y", "DK", "IS", "SK", "KZ", "WS", "V"}
ADJ_SCALE = 24      # пикселей на градус при поиске соседних областей


def classify(a3, name, unit):
    """(код страны, id территории или None) для области."""
    # сначала области, названные по имени, потом целые страны ("@A3"): Сумы — Московии, Одесса — Румынии,
    # хотя Украина целиком у Р.К.
    for tid, names in TERRITORY.items():
        if name in names:
            return TERRITORY_CODE.get(tid, "G" if tid in GERMAN else "WS"), tid
    for code, names in BY_PROVINCE_NAME.get(a3, {}).items():
        if name in names:
            return code, None
    for tid, names in TERRITORY.items():
        if "@" + a3 in names:
            return TERRITORY_CODE.get(tid, "G" if tid in GERMAN else "WS"), tid
    if a3 == "GBR" and unit in GBR_UNITS:
        return GBR_UNITS[unit], None
    return BY_COUNTRY.get(a3, a3), None


def apply_splits(units):
    """Режет области из SPLITS (нужен shapely): кусок внутри многоугольника — отдельная область."""
    from shapely.geometry import Polygon
    from shapely.ops import unary_union
    out = []
    for a3, name, unit, rings in units:
        cuts = [s for s in SPLITS if s[0] == a3 and s[1] == name]
        if not cuts:
            out.append((a3, name, unit, rings, None))
            continue
        rest = unary_union([Polygon(r).buffer(0) for r in rings if len(r) >= 4])
        for _, _, code, terr, clip in cuts:
            cp = Polygon(clip)
            out.append((a3, name, unit, _rings(rest.intersection(cp)), (code, terr)))
            rest = rest.difference(cp)
        out.append((a3, name, unit, _rings(rest), None))
    return out


def _rings(g):
    parts = [g] if g.geom_type == "Polygon" else [p for p in getattr(g, "geoms", []) if p.geom_type == "Polygon"]
    return [list(p.exterior.coords) for p in parts if not p.is_empty]


def in_bounds(r):
    lon0, lon1, lat0, lat1 = BOUNDS
    xs = [p[0] for p in r]
    ys = [p[1] for p in r]
    return max(xs) > lon0 and min(xs) < lon1 and max(ys) > lat0 and min(ys) < lat1


def neighbours(provinces):
    """Соседние области (общая граница): рисуем все области в растр и смотрим соседние пиксели."""
    from PIL import Image, ImageDraw
    lon0, lon1, lat0, lat1 = BOUNDS
    w, h = int((lon1 - lon0) * ADJ_SCALE), int((lat1 - lat0) * ADJ_SCALE)
    img = Image.new("I", (w, h), 0)
    d = ImageDraw.Draw(img)
    for i, p in enumerate(provinces, 1):
        for r in p["r"]:
            pts = [((r[k] / 100 - lon0) * ADJ_SCALE, (lat1 - r[k + 1] / 100) * ADJ_SCALE) for k in range(0, len(r), 2)]
            d.polygon(pts, fill=i, outline=i)
    px = img.load()
    pairs = set()
    for y in range(h - 1):
        for x in range(w - 1):
            a = px[x, y]
            if not a:
                continue
            for b in (px[x + 1, y], px[x, y + 1], px[x + 1, y + 1]):
                if b and b != a:
                    pairs.add((min(a, b), max(a, b)))
    for p in provinces:
        p["n"] = []
    for a, b in pairs:
        provinces[a - 1]["n"].append(b - 1)
        provinces[b - 1]["n"].append(a - 1)
    print(f"соседних пар: {len(pairs)}")


def main(admin0, admin1):
    units = []
    for f in json.load(open(admin0, encoding="utf-8"))["features"]:
        a3 = f["properties"]["ADM0_A3"]
        if a3 not in BY_PROVINCE:
            units.append((a3, f["properties"].get("NAME", a3), None, rings_of(f["geometry"])))
    for f in json.load(open(admin1, encoding="utf-8"))["features"]:
        a3 = f["properties"]["adm0_a3"]
        if a3 in BY_PROVINCE:
            pr = f["properties"]
            units.append((a3, pr.get("name") or a3, pr.get("geonunit"), rings_of(f["geometry"])))
    out = []
    pts = 0
    for a3, name, unit, rings, forced in apply_splits(units):
        rings = [r for r in rings if in_bounds(r) and area(r) >= MIN_AREA]
        if not rings:
            continue
        big = max(rings, key=area)
        cx, cy = centroid(big)
        code, terr = forced or classify(a3, name, unit)
        if code not in KEEP:
            continue
        simp = []
        for r in rings:
            s = simplify([(round(x, 3), round(y, 3)) for x, y in r], TOLERANCE)
            if len(s) >= 4:
                simp.append([v for x, y in s for v in (round(x * 100), round(y * 100))])
                pts += len(s)
        if simp:
            rec = {"c": code, "a3": a3, "x": round(cx, 2), "y": round(cy, 2), "r": simp}
            if terr:
                rec["t"] = terr
            out.append(rec)
    neighbours(out)
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"bounds": BOUNDS, "scale": 100, "provinces": out}, fh, ensure_ascii=False,
                  separators=(",", ":"))
    print(f"{len(out)} областей, {pts} точек -> {OUT} ({os.path.getsize(OUT) // 1024} КБ)")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
