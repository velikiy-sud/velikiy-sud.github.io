#!/usr/bin/env sh
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt >/dev/null
python3 main.py "$@"
