"""Текстовый эпилог: итог партии по выборам игрока, доктринам и показателям."""
from .mechanics import expansion
from .mechanics.army import DOCTRINES
from .mechanics.nuclear import DOCTRINE_NAMES
from .i18n import tr

ENDING_CHAIN_IDS = ("EVENT_002", "EVENT_B01", "EVENT_B03", "EVENT_L01", "EVENT_L02", "EVENT_L03",
                    "EVENT_W01", "EVENT_W04", "EVENT_F01", "SUPEREVENT_F02", "EVENT_BE1", "EVENT_LE1")


def build(game, endings):
    st = game.state
    e = endings.get(st.ending, {"title": st.ending.upper(), "text": ""})
    years = st.day / 365
    paras = [
        ("bright", f"{st.side_name().upper()} — {e['title']}"),
        ("normal", tr("Партия длилась {0} дней (~{1:.1f} г.), до {2}.").format(st.day, years, st.date_str())),
        ("normal", ""),
        ("normal", e["text"]),
        ("normal", ""),
        ("bright", tr("ПУТЬ ДЕРЖАВЫ:")),
    ]
    # Ключевые решения
    picked = [h for h in st.history if h["id"] in ENDING_CHAIN_IDS or h["id"].startswith("SUPEREVENT")]
    for h in picked[:14]:
        paras.append(("normal", f"  {h['date']}  {h['title']}: «{h['option']}»"))

    # Экспансия
    ctrl = expansion.controlled(st)
    if st.territories:
        title = game.expansion_cfg["title"].capitalize()
        names = ", ".join(t["name"] for t in ctrl) or tr("ничего")
        paras += [("normal", ""), ("bright", f"{title.upper()}: {len(ctrl)}/{len(st.territories)}"),
                  ("normal", tr("  Под контролем: {0}.").format(names))]
        if st.has_flag("new_burgundian_empire"):
            paras.append(("normal", tr("  Германия как единое государство прекратила существование.")))
        if st.has_flag("united_league"):
            paras.append(("normal", tr("  Россия объединена под чёрным знаменем Лиги.")))

    # Армия и ядерка
    d = DOCTRINES.get(st.vars.get("army_doctrine"), {}).get("name", tr("не утверждена"))
    nd = DOCTRINE_NAMES.get(st.vars.get("nuke_doctrine"), tr("не принята"))
    paras += [("normal", ""), ("bright", tr("ВОЕННАЯ МАШИНА:")),
              ("normal", tr("  Армейская доктрина: {0}. Ядерная доктрина: {1}.").format(d, nd)),
              ("normal", tr("  Ядерное испытание: {0}{1}.{2}").format(tr("проведено") if st.has_flag('nuke_tested') else tr("не проведено"), tr(", программа форсировалась") if st.has_flag('nuke_forced') else '', tr(" Аварии скрывались от мира.") if st.vars.get('coverups') else '')),
              ("normal", tr("  Ядерных ударов нанесено: {0}, получено: {1}.").format(st.war['strikes'], st.war['enemy_strikes'])),
              ("normal", tr("  Опустошение: наше {0:.0f}%, противника {1:.0f}%.").format(st.get('own_losses'), st.get('enemy_losses'))),
              ("normal", tr("  Итог: стабильность {0:.0f}, престиж {1:.0f}, мировое осуждение {2:.0f}.").format(st.get('stability'), st.get('prestige'), st.get('world_reaction')))]
    return paras
