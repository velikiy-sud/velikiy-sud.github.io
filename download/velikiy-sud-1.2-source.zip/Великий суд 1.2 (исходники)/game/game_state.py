"""Состояние партии: дата, показатели, флаги, история выборов, территории.

Всё состояние — чистые данные (dict/list/числа), поэтому легко сохраняется в JSON.
"""
import datetime
import json
import os
import random

from . import config
from .i18n import tr

# Границы показателей (min, max). Неизвестные показатели не ограничиваются.
STAT_LIMITS = {
    "stability": (0, 100), "prestige": (0, 100), "intel": (0, 100),
    "ideology": (0, 100), "training": (0, 100), "supply": (0, 100),
    "equipment": (0, 100), "morale": (0, 100), "nuke_research": (0, 100),
    "nuke_safety": (0, 100), "tension": (0, 100), "escalation": (0, 100),
    "germany_stability": (0, 100), "loyalty": (0, 100),
    "world_reaction": (0, 100), "own_losses": (0, 100), "enemy_losses": (0, 100),
    "enemy_nuke_research": (0, 100), "enemy_economy": (0, 100),
    "manpower": (0, 9999), "nuke_materials": (0, 999), "nuke_facilities": (0, 10),
    "warheads": (0, 999), "bombers": (0, 99), "missiles": (0, 99),
    "enemy_army": (0, 999), "enemy_nukes": (0, 99), "dip_points": (0, 999),
    "treasury": (-500, 99999), "leader_power": (0, 100), "apparatus": (0, 100),
}

# Человекочитаемые названия показателей (для подсказок и эпилога)
STAT_NAMES = {
    "stability": tr("Стабильность"), "treasury": tr("Казна"), "prestige": tr("Престиж"),
    "intel": tr("Разведданные"), "ideology": tr("Идеологическая чистота"),
    "manpower": tr("Живая сила"), "training": tr("Выучка"), "supply": tr("Снабжение"),
    "equipment": tr("Вооружение"), "morale": tr("Боевой дух"),
    "nuke_research": tr("Ядерные исследования"), "nuke_materials": tr("Расщепляемые материалы"),
    "nuke_facilities": tr("Ядерные объекты"), "warheads": tr("Боеголовки"),
    "bombers": tr("Бомбардировщики"), "missiles": tr("Ракеты"), "nuke_safety": tr("Безопасность программы"),
    "tension": tr("Напряжённость"), "escalation": tr("Эскалация"),
    "germany_stability": tr("Стабильность Германии"), "enemy_army": tr("Армия противника"),
    "enemy_nukes": tr("Ядерный арсенал противника"), "dip_points": tr("Дипл. очки"),
    "loyalty": tr("Лояльность новых земель"), "world_reaction": tr("Мировое осуждение"),
    "own_losses": tr("Собственные потери"), "enemy_losses": tr("Потери противника"),
    "enemy_economy": tr("Экономика противника"),
    "leader_power": tr("Власть лидера"), "apparatus": tr("Компетентность аппарата"),
}


class GameState:
    def __init__(self, side, scenario, seed=None):
        self.side = side
        self.scenario = scenario
        side_cfg = scenario["sides"][side]
        self.enemy_side = side_cfg["enemy"]
        self.day = 1
        self.seed = seed if seed is not None else random.randrange(1 << 30)
        self.rng = random.Random(self.seed)

        self.stats = dict(scenario["common_stats"])
        self.stats.update(side_cfg.get("stats", {}))
        self.relations = {k: v["start"] for k, v in side_cfg["factions"].items()}
        self.flags = {}          # имя флага -> день установки
        self.vars = {}           # произвольные переменные (числа/строки)
        for name, (lo, hi) in scenario.get("random_vars", {}).items():
            self.vars[name] = self.rng.randint(lo, hi)
        self.fired = {}          # id ивента -> день последнего срабатывания
        self.fire_count = {}     # id ивента -> сколько раз сработал
        self.choices = {}        # id ивента -> список индексов выбранных вариантов
        self.history = []        # [{day, date, id, title, option}]
        self.log = []            # [(день, текст)]
        self.scheduled = []      # [{day, event, context}]
        self.tabs = list(side_cfg["tabs_open"])
        self.programs = {}       # включённые постоянные программы (учения, добыча...)
        self.modifiers = {}      # множители механик (скорость исследований и т.п.)
        self.territories = {}    # id -> dict
        self.ai_territories = {} # территории ветки противника: id -> "independent" | "taken"
        self.operations = []     # активные операции поглощения/объединения
        self.war = {"active": False, "front": 0.0, "days": 0, "stance": "balanced",
                    "strikes": 0, "enemy_strikes": 0}
        self.ending = None

    # ---------- даты ----------
    @property
    def date(self):
        start = datetime.date(config.START_YEAR, config.START_MONTH, config.START_DAY)
        return start + datetime.timedelta(days=self.day - 1)

    def date_str(self):
        return self.date.strftime("%d.%m.%Y")

    # ---------- показатели ----------
    def get(self, name, default=0):
        return self.stats.get(name, default)

    def add(self, name, delta):
        self.set(name, self.stats.get(name, 0) + delta)

    def set(self, name, value):
        lo, hi = STAT_LIMITS.get(name, (None, None))
        if lo is not None:
            value = max(lo, min(hi, value))
        self.stats[name] = value

    def add_relation(self, faction, delta):
        if faction in self.relations:
            self.relations[faction] = max(0, min(100, self.relations[faction] + delta))

    def mod(self, name, default=1.0):
        return self.modifiers.get(name, default)

    def mul_mod(self, name, factor):
        self.modifiers[name] = self.modifiers.get(name, 1.0) * factor

    # ---------- флаги ----------
    def set_flag(self, name):
        self.flags[name] = self.day

    def has_flag(self, name):
        return name in self.flags

    def clear_flag(self, name):
        self.flags.pop(name, None)

    def flag_age(self, name):
        if name not in self.flags:
            return -1
        return self.day - self.flags[name]

    # ---------- журнал ----------
    def log_msg(self, text):
        self.log.append((self.day, text))
        if len(self.log) > 500:
            self.log = self.log[-500:]

    def side_name(self, side=None):
        return self.scenario["sides"][side or self.side]["name"]

    def faction_name(self, key):
        return self.scenario["sides"][self.side]["factions"][key]["name"]

    # ---------- сохранение ----------
    _SAVED = ["side", "day", "seed", "stats", "relations", "flags", "vars", "fired",
              "fire_count", "choices", "history", "log", "scheduled", "tabs", "programs",
              "modifiers", "territories", "ai_territories", "operations", "war", "ending"]

    def to_dict(self):
        return {k: getattr(self, k) for k in self._SAVED}

    @classmethod
    def from_dict(cls, data, scenario):
        st = cls(data["side"], scenario, seed=data["seed"])
        for k in cls._SAVED:
            if k in data:
                setattr(st, k, data[k])
        st.log = [tuple(x) for x in st.log]
        for k, f in scenario["sides"][st.side]["factions"].items():   # фракции, добавленные позже
            st.relations.setdefault(k, f["start"])
        st.rng = random.Random(st.seed + st.day)
        return st

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=1)

    @classmethod
    def load(cls, path, scenario):
        with open(path, encoding="utf-8") as f:
            return cls.from_dict(json.load(f), scenario)
