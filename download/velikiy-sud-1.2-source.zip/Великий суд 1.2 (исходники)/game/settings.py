"""Настройки игрока, которые переживают перезапуск: цвет экрана. Хранятся в saves/settings.json."""
import json
import os

from . import config

PATH = os.path.join(config.SAVE_DIR, "settings.json")
_data = None


def _load():
    global _data
    if _data is None:
        try:
            with open(PATH, encoding="utf-8") as f:
                _data = json.load(f)
        except Exception:
            _data = {}
    return _data


def get(key, default=None):
    return _load().get(key, default)


def set(key, value):
    _load()[key] = value
    try:
        os.makedirs(config.SAVE_DIR, exist_ok=True)
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(_data, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def theme():
    key = get("theme", "green")
    return key if key in config.THEMES else "green"


def next_theme():
    keys = list(config.THEMES)
    key = keys[(keys.index(theme()) + 1) % len(keys)]
    set("theme", key)
    return key


def theme_name():
    from .i18n import tr
    return tr(config.THEMES[theme()][0])
