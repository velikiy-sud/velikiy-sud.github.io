"""Плеер суперивентов: процедурная ASCII-анимация + синтезированный звук.

Подмена настоящими медиа (необязательно):
  assets/media/<media_id>/*.png   — кадры (по алфавиту), проигрываются с fps из media.json
  assets/media/<media_id>.wav|.ogg — звук вместо синтеза
"""
import glob
import json
import os

from .. import config, i18n
from . import animations

try:
    import pygame
except ImportError:
    pygame = None


def load_media():
    with open(os.path.join(config.DATA_DIR, "media.json"), encoding="utf-8") as f:
        data = i18n.tr_data(json.load(f))
    data.pop("_comment", None)
    return data


class SuperEventPlayer:
    MIN_SHOW = 1.5   # секунд до возможности пропустить

    def __init__(self, audio):
        self.audio = audio
        self.media = load_media()
        self.cfg = None
        self.t = 0.0
        self.active = False
        self.frames = []
        self._cues = []

    def start(self, media_id):
        self.cfg = dict(self.media.get(media_id, {"style": "static", "duration": 5, "caption": media_id}))
        self.media_id = media_id
        self.t = 0.0
        self.active = True
        self.frames = []
        folder = os.path.join(config.MEDIA_DIR, media_id)
        if pygame and os.path.isdir(folder):
            for p in sorted(glob.glob(os.path.join(folder, "*.png"))):
                try:
                    self.frames.append(pygame.image.load(p).convert())
                except Exception:
                    pass
        sound_file = None
        for ext in (".wav", ".ogg", ".mp3"):
            p = os.path.join(config.MEDIA_DIR, media_id + ext)
            if os.path.exists(p):
                sound_file = p
                break
        if sound_file:
            self.audio.play_file(sound_file)
            self._cues = []
        else:
            self._cues = sorted((c["at"], c["cue"]) for c in self.cfg.get("sounds", []))

    @property
    def duration(self):
        return self.cfg.get("duration", 6.0) if self.cfg else 0

    def update(self, dt):
        if not self.active:
            return
        self.t += dt
        while self._cues and self._cues[0][0] <= self.t:
            self.audio.play(self._cues.pop(0)[1])

    @property
    def finished(self):
        return self.active and self.t >= self.duration

    @property
    def skippable(self):
        return self.t >= self.MIN_SHOW

    def skip(self):
        self.t = max(self.t, self.duration)
        self._cues = []

    def stop(self):
        self.active = False
        self.cfg = None
        self.audio.stop_all()

    def frame_canvas(self, w, h):
        return animations.frame(self.cfg, self.t, w, h)

    def frame_image(self):
        if not self.frames:
            return None
        idx = int(self.t * self.cfg.get("fps", 12)) % len(self.frames)
        return self.frames[idx]
