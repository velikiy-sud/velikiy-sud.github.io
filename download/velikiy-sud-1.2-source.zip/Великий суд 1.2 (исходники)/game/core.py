"""Партия целиком: состояние + движок ивентов + механики. Не зависит от pygame."""
import json
import os

from . import config, i18n
from .events.engine import EventEngine
from .game_state import GameState
from .mechanics import army, diplomacy, expansion, nuclear, war, world
from .i18n import tr


def load_json(name):
    with open(os.path.join(config.DATA_DIR, name), encoding="utf-8") as f:
        return i18n.tr_data(json.load(f))


# Вкладки боковой панели: ключ -> (название, функция представления или None для спец-вкладок)
TAB_ORDER = ["map", "log", "diplomacy", "army", "nuclear", "absorption", "france", "unification", "war"]
TAB_NAMES = {"map": tr("Карта Европы"), "log": tr("Журнал событий"), "diplomacy": tr("Дипломатия"),
             "army": tr("Армия"), "nuclear": tr("☢ Ядерный проект"),
             "absorption": tr("Поглощение Германии"), "france": tr("Захват Франции"), "unification": tr("Объединение России"),
             "war": tr("Война")}


class Game:
    def __init__(self, side=None, seed=None, state=None):
        self.scenario = load_json("scenario.json")
        self.territory_data = load_json("territories.json")
        new = state is None
        self.state = state or GameState(side, self.scenario, seed)
        side = self.state.side
        self.side_cfg = self.scenario["sides"][side]
        self.expansion_cfg = self.territory_data[side]
        if not new:   # тексты земель в сохранении — на языке той партии: берём из текущих данных
            defs = {t["id"]: t for t in self.expansion_cfg.get("territories", [])}
            for tid, t in self.state.territories.items():
                for k in ("name", "desc", "on_action_label", "no_talks"):
                    if k in defs.get(tid, {}):
                        t[k] = defs[tid][k]
        if not self.state.ai_territories:   # старые сохранения
            expansion.init_ai(self.state, self.territory_data)
        self.engine = EventEngine(self.state)
        self.state.engine = self.engine
        self.state.game = self
        if new:
            expansion.init_territories(self.state, self.territory_data)
            self.engine.daily()   # ивенты первого дня

    @classmethod
    def load(cls, path):
        scenario = load_json("scenario.json")
        return cls(state=GameState.load(path, scenario))

    # ---------- симуляция ----------
    def tick(self):
        """Один игровой день."""
        st = self.state
        if st.ending:
            return
        st.day += 1
        before = st.get("treasury")
        world.daily(self)
        army.daily(self)
        nuclear.daily(self)
        expansion.daily(self)
        expansion.ai_daily(self)
        war.daily(self)
        st.vars["treasury_delta"] = round(st.get("treasury") - before, 2)   # доход за день (без покупок игрока)
        self.engine.daily()

    # ---------- вкладки ----------
    def tabs(self):
        return [t for t in TAB_ORDER if t in self.state.tabs]

    def view(self, tab):
        return {"diplomacy": diplomacy.view, "army": army.view, "nuclear": nuclear.view,
                "absorption": expansion.view, "unification": expansion.view,
                "france": lambda g: expansion.view(g, "france"),
                "war": war.view}[tab](self)

    # ---------- оценки разведки ----------
    def _fuzz(self, value, salt):
        err = (100 - self.state.get("intel")) / 100 * 0.45
        if err < 0.05:
            return f"{value:.0f}"
        lo = value * (1 - err)
        hi = value * (1 + err)
        return f"{lo:.0f}–{hi:.0f}"

    def enemy_estimate(self):
        return self._fuzz(war.enemy_power(self.state), 1)

    def enemy_nukes_estimate(self):
        st = self.state
        if not st.has_flag("enemy_nuke_tested"):
            return tr("нет данных") if st.get("intel") < 40 else tr("нет (проект {0:.0f}%)").format(st.get('enemy_nuke_research'))
        if st.get("intel") >= 50:
            return tr("{0:.0f} боеголовок").format(st.get('enemy_nukes'))
        return tr("есть, число неизвестно")
