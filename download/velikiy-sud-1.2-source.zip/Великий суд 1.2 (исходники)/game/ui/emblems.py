"""Гербы сторон для экрана выбора: картинки assets/emblems/*.png (белый силуэт, тонируется в зелёный).

Символьные варианты BURGUNDY / LEAGUE остались на случай, если картинки не загрузятся."""
import os

import pygame

from .. import config
from ..i18n import tr

_CACHE = {}


def icon(key, height, color):
    """Иконка ссылки (assets/icons/<key>.png) в цвете color."""
    return image(key, height, color, "icons")


def open_link(url):
    import webbrowser
    try:
        webbrowser.open(url)
    except Exception:
        pass


def draw_links(screen, term, x, y, style="n", gap=4, keys=True):
    """Ряд ссылок с иконками: [иконка] ПОДПИСЬ  адрес. Клик открывает браузер. Возвращает ширину ряда."""
    cx = x
    for i, (key, label, short, url) in enumerate(config.LINKS):
        hotkey = f" [{'TB'[i]}]" if keys else ""
        text = f"{tr(label)}  {short}{hotkey}"
        img = icon(key, term.ch - 2, config.BRIGHT if style == "b" else config.NORMAL)
        if img is not None:
            r = term.rect(cx, y, 2, 1)
            term.surface.blit(img, img.get_rect(center=r.center))
        term.put(cx + 3, y, text, style)
        screen.hit(cx, y, len(text) + 3, 1, lambda url=url: open_link(url))
        cx += len(text) + 3 + gap
    return cx - x - gap


def links_width(gap=4, keys=True):
    return sum(len(f"{tr(label)}  {short}") + (4 if keys else 0) + 3 for _, label, short, _ in config.LINKS) + gap * (len(config.LINKS) - 1)


def image(key, height, color, folder="emblems"):
    """Герб высотой height пикселей в цвете color (или None, если картинки нет)."""
    k = (key, height, color, folder)
    if k not in _CACHE:
        try:
            src = pygame.image.load(os.path.join(config.ASSETS_DIR, folder, key + ".png"))
            w = round(src.get_width() * height / src.get_height())
            img = pygame.transform.smoothscale(src.convert_alpha() if pygame.display.get_surface() else src, (w, height))
            img.fill(color + (255,), special_flags=pygame.BLEND_RGBA_MULT)
            _CACHE[k] = img
        except Exception:
            _CACHE[k] = None
    return _CACHE[k]

BURGUNDY = [  # бургундский крест — сучковатые ветви крест-накрест — в круге
    "           ▗▄▄▄▄▄▄▄▄▖         ",
    "        ▄▟█▀▀▀    ▀▀▀█▙▄      ",
    "      ▟█▀           ▗▄ ▀█▙    ",
    "    ▗█▀▜█▙▖         ▐███▛▀█▖  ",
    "   ▗█▘  ███▙▖       ▟██▘  ▝█▖ ",
    "   █▌   █▀▀██▄▟█▛ ▄██▀     ▐█ ",
    "  ▐█        ▀██▙▄████▄      █▌",
    "  ▐█       ▐▙▖████          █▌",
    "  ▐█       ▝███▀▀██▄        █▌",
    "   █▌     ▗▟█▛   ████▄   ▗ ▐█ ",
    "   ▝█▖  ▗▟██▘   ▐▀▘ ▜███▛▘▗█▘ ",
    "    ▝█▄▟█▛▀▜▙▖       ▝▜█▙▄█▘  ",
    "      ▜█▄              ▄█▛    ",
    "        ▀▜█▄▄▄    ▄▄▄█▛▀      ",
    "           ▝▀▀▀▀▀▀▀▀▘         ",
]

LEAGUE = [  # пятиугольник Чёрной Лиги со звездой и двуглавым орлом
    "              ▗▄▄▖              ",
    "            ▄▟████▙▄            ",
    "           ▐███▛▜███▌           ",
    "          ▗▟██▄  ▄██▙▖          ",
    "    ▄▄▄ ▄█████▙▟▙▟█████▄ ▄▄▄    ",
    " ▄▟█████▛▜████████████▛▜█████▙▄ ",
    "▝███████  ▀█▙▄ ▜▛ ▄▟█▀  ███████▘",
    " ▐██████    ▐█▘  ▝█▌    ██████▌ ",
    "  ▜█████▖   ▝▘    ▝▘   ▗█████▛  ",
    "     ▝███▄▖          ▗▄███▘     ",
    "      ▜█████▛ ▗▖▗▖ ▜█████▛      ",
    "    ▗▄████▀▙▟▀▀  ▀▀▙▟▀████▄▖    ",
    "    ▝████████▄▄  ▄▄████████▘    ",
    "     ▜██████▛▀▀▀▀▀▀▜██████▛     ",
    "      ▀▀▀▀▀▀▘      ▝▀▀▀▀▀▀      ",
]


EMBLEMS = {"burgundy": lambda: BURGUNDY, "league": lambda: LEAGUE}
