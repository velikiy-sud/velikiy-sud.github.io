"""Главный цикл pygame: окно, масштабирование, CRT, смена экранов."""
import os

import pygame

from .. import config
from ..media.audio import Audio
from .screens import BootScreen
from .terminal import CRT, Terminal
from ..i18n import tr


class App:
    def __init__(self, fullscreen=False, sound=True):
        pygame.mixer.pre_init(config.AUDIO_RATE, -16, 1, 512)
        pygame.init()
        pygame.display.set_caption(tr("Великий суд {0}").format(config.VERSION))
        try:
            pygame.display.set_icon(pygame.image.load(os.path.join(config.ASSETS_DIR, "icon.png")))
        except Exception:
            pass
        self.audio = Audio(enabled=sound)
        self.term = Terminal()
        self.crt = CRT(self.term.size)
        w, h = self.crt.size
        info = pygame.display.Info()
        scale = min(1.0, (info.current_w * 0.92) / w, (info.current_h * 0.88) / h) if info.current_w > 0 else 1.0
        self.fullscreen = fullscreen
        self.window_size = (int(w * scale), int(h * scale))
        self._set_mode()
        self.running = True
        self.screen = BootScreen(self, skip_boot=True)   # сразу титульный экран
        self.clock = pygame.time.Clock()

    def _set_mode(self):
        if self.fullscreen:
            self.window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            self.window = pygame.display.set_mode(self.window_size, pygame.RESIZABLE)

    def set_screen(self, screen):
        self.audio.stop_all()
        self.screen = screen

    def _viewport(self):
        ww, wh = self.window.get_size()
        w, h = self.crt.size
        s = min(ww / w, wh / h)
        vw, vh = int(w * s), int(h * s)
        return pygame.Rect((ww - vw) // 2, (wh - vh) // 2, vw, vh)

    def _to_term(self, pos):
        vp = self._viewport()
        w, h = self.crt.size
        return self.crt.to_screen((int((pos[0] - vp.x) * w / max(1, vp.w)), int((pos[1] - vp.y) * h / max(1, vp.h))))

    def run(self):
        while self.running:
            dt = min(0.1, self.clock.tick(30) / 1000.0)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.VIDEORESIZE and not self.fullscreen:
                    self.window_size = event.size
                    self._set_mode()
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                    self.fullscreen = not self.fullscreen
                    self._set_mode()
                else:
                    if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
                        event = pygame.event.Event(event.type, {**event.__dict__, "pos": self._to_term(event.pos)})
                    self.screen.handle(event)
            self.screen.update(dt)
            self.render()
        pygame.quit()

    def render(self):
        self.screen.draw(self.term)
        frame = self.crt.process(self.term.surface, self.clock.get_time() / 1000.0)
        self.window.fill((0, 0, 0))
        vp = self._viewport()
        if vp.size == frame.get_size():
            self.window.blit(frame, vp)
        else:
            self.window.blit(pygame.transform.smoothscale(frame, vp.size), vp)
        pygame.display.flip()
