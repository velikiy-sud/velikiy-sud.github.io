"""Дипломатия: фракции, внутренняя пропаганда, разведка, канал связи с противником."""
from .common import Item, TabView, bar, costly
from ..i18n import tr


def view(game):
    st = game.state
    side_cfg = game.side_cfg
    header = [
        (tr("Дипломатические очки: {0:.0f}   Престиж: {1:.0f}   Разведданные: {2:.0f}   Мировое осуждение: {3:.0f}").format(st.get('dip_points'), st.get('prestige'), st.get('intel'), st.get('world_reaction')), "bright"),
        (tr("Идеологическая чистота: {0} {1:.0f}").format(bar(st.get('ideology'), 20), st.get('ideology')), "normal"),
    ]
    if "leader_power" in st.stats:
        header.append((tr("Власть лидера:          {0} {1:.0f}   Компетентность аппарата: {2:.0f}").format(bar(st.get('leader_power'), 20), st.get('leader_power'), st.get('apparatus')), "normal"))
    header += [("", "normal"), (tr("ФРАКЦИИ И ОТНОШЕНИЯ:"), "bright")]
    items = []
    for key, f in side_cfg["factions"].items():
        rel = st.relations[key]

        def court(key=key, f=f):
            st.add_relation(key, 8)
            st.log_msg(tr("Отношения с фракцией «{0}» улучшены.").format(f['name']))
        items.append(Item(f"{f['name']:<32} {bar(rel, 16)} {rel:3.0f}",
                          [costly(st, tr("Укрепить связи"), {"dip_points": 10}, court)],
                          [f.get("desc", ""), tr("+8 к отношениям за 10 дипломатических очков.")]))

    def home_prop():
        st.add("stability", 4)
        st.add("ideology", 1)
        st.log_msg(tr("Радио и газеты славят режим. Улицы спокойны."))
    items.append(Item(tr("Внутренняя пропаганда"), [costly(st, tr("Запустить кампанию"), {"treasury": 20}, home_prop)],
                      [tr("+4 стабильности, +1 идеологической чистоты.")]))

    def ideology():
        st.add("ideology", 5)
        st.add("stability", -1)
        st.log_msg(tr("Чистка рядов: сомневающихся отстранили от должностей."))
    items.append(Item(tr("Идеологическая чистка"), [costly(st, tr("Провести чистку"), {"dip_points": 8}, ideology)],
                      [tr("+5 идеологической чистоты, -1 стабильности."),
                       tr("Чистота ускоряет пропаганду, но мешает компромиссам.")]))

    def spy():
        st.add("intel", 6)
        st.log_msg(tr("Новые агенты внедрены в штабы противника."))
    items.append(Item(tr("Агентурная сеть у противника"), [costly(st, tr("Внедрить агентов"), {"treasury": 25}, spy)],
                      [tr("+6 разведданных. Чем больше данных, тем точнее оценки армии и арсенала врага.")]))

    def channel():
        st.add("tension", -8)
        st.add("prestige", -1)
        st.log_msg(tr("Тайный канал связи с противником снизил напряжённость."))
    items.append(Item(tr("Тайный канал с противником"),
                      [costly(st, tr("Провести переговоры"), {"dip_points": 15}, channel,
                              not st.war["active"], tr("идёт война"))],
                      [tr("-8 напряжённости, -1 престижа.")]))

    def provoke():
        st.add("tension", 6)
        st.add("prestige", 3)
        st.log_msg(tr("Пограничная провокация: обе стороны обменялись нотами протеста."))
    items.append(Item(tr("Провокация на границе"),
                      [costly(st, tr("Устроить провокацию"), {"treasury": 10}, provoke, not st.war["active"], tr("идёт война"))],
                      [tr("+6 напряжённости, +3 престижа. Приближает войну.")]))
    return TabView(tr("ДИПЛОМАТИЯ"), header, items)
