"""Общий движок расширения: территории, операции (военные, дипломатические, подкуп, пропаганда).

Поглощение Германии (Бургундия) и Объединение России (Чёрная Лига) — это одна механика
с разными данными из data/territories.json и своими ивентами-крючками:
  "on_action_event"   — ивент вместо меню действий при первом обращении к территории
  "on_military_event" — ивент через пару дней после начала военной операции
  "final_event"       — ивент при взятии финальной территории
  "capture_event"     — ивент сразу после взятия территории (расправа над власовцами)
  "no_talks"          — переговоров нет, только война (подсказка в меню)

Брать можно только земли, граничащие с нашими (соседство областей — из data/map_provinces.json,
морские переходы — "sea_links"). Соперники ("rivals") и противник сами захватывают соседние
земли: их операции идут постепенно и видны на карте. Падение столицы соперника отдаёт
победителю все его земли. Рейхскомиссариаты с "shared" есть в списках обеих сторон.
"""
import json
import os
from collections import defaultdict

from .. import config, registry
from . import army
from .common import Action, Item, TabView, bar, costly
from ..i18n import tr

STATUS = {
    "independent": tr("независима"), "contested": tr("спорная"), "infiltrated": tr("агентурная сеть"),
    "annexed": tr("аннексирована"), "puppet": tr("марионетка"), "destroyed": tr("уничтожена"),
    "allied": tr("союзник"), "rival": tr("у соперника"), "enemy": tr("у противника"),
}
OP_SHORT = {"military": tr("штурм"), "diplomatic": tr("переговоры"), "bribe": tr("подкуп"), "propaganda": tr("пропаганда")}
CONTROLLED = ("annexed", "puppet", "destroyed", "allied")

HOME = {"burgundy": "home:burgundy", "league": "home:league"}
RIVAL_MAX = 3      # сколько земель соперник может собрать кроме своей столицы
AI_STATUS = {"me": "player", "enemy": "taken", None: "independent"}

OP_NAMES = {"military": tr("военная операция"), "diplomatic": tr("переговоры о присоединении"),
            "bribe": tr("подкуп элит"), "propaganda": tr("идеологическая обработка")}


def init_territories(state, data):
    side_data = data.get(state.side, {})
    for t in side_data.get("territories", []):
        tt = dict(t)
        tt.setdefault("status", "independent")
        if tt.get("rival"):
            tt["status"], tt["holder"] = "rival", tt["id"]
        tt["progress"] = 0.0
        tt["op"] = None
        state.territories[tt["id"]] = tt


def init_ai(state, data):
    """Противник ведёт свою экспансию (абстрактно): захваты видны на карте и усиливают его армию."""
    for t in data.get(state.enemy_side, {}).get("territories", []):
        state.ai_territories[t["id"]] = "rival:" + t["id"] if t.get("rival") else "independent"


# ---------- кто чем владеет ----------
_ADJ = None


def adjacency(data):
    """Граф соседства территорий: id -> множество соседей (включая "home:<сторона>")."""
    global _ADJ
    if _ADJ is None:
        with open(os.path.join(config.DATA_DIR, "map_provinces.json"), encoding="utf-8") as f:
            provs = json.load(f)["provinces"]

        def node(p):
            return p.get("t") or ("home:burgundy" if p["c"] == "B" else "c:" + p["c"])
        adj = defaultdict(set)
        for p in provs:
            a = node(p)
            for j in p.get("n", []):
                b = node(provs[j])
                if a != b:
                    adj[a].add(b)
        for side in ("burgundy", "league"):
            for a, b in data[side].get("sea_links", []):
                adj[a].add(b)
                adj[b].add(a)
        _ADJ = adj
    return _ADJ


def holder(state, tid):
    """Кто держит территорию: None (ничья), "me", "enemy" или id соперника."""
    t = state.territories.get(tid)
    if t is not None:
        s = t["status"]
        if s in CONTROLLED:
            return "me"
        if s == "rival":
            return t.get("holder")
        return "enemy" if s == "enemy" else None
    v = state.ai_territories.get(tid, "independent")
    if v.startswith("rival:"):
        return v[6:]
    return {"taken": "enemy", "player": "me"}.get(v)


def _set_holder(state, tid, h):
    """Передать территорию (не игроку — для игрока есть set_status)."""
    t = state.territories.get(tid)
    if t is not None:
        if t.get("op"):
            state.log_msg(tr("{0}: наша операция сорвана — земли заняты.").format(t['name']))
        t["op"] = None
        t["progress"] = 0.0
        t["status"] = {"enemy": "enemy", None: "independent"}.get(h, "rival")
        if t["status"] == "rival":
            t["holder"] = h
    if tid in state.ai_territories:
        state.ai_territories[tid] = AI_STATUS.get(h, f"rival:{h}")


def borders(game, actor, tid):
    """Граничит ли территория с землями actor ("me", "enemy" или id соперника)."""
    st = game.state
    if actor == "me":
        mine = {HOME[st.side]}
    elif actor == "enemy":
        mine = {HOME[st.enemy_side]}
    else:
        home = rivals(game).get(actor, (None, {}))[1].get("home")
        mine = {home} if home else set()
    return any(n in mine or (not n.startswith(("home:", "c:")) and holder(st, n) == actor)
               for n in adjacency(game.territory_data).get(tid, ()))


def all_defs(game):
    out = {}
    for side in ("burgundy", "league"):
        for t in game.territory_data[side]["territories"]:
            out.setdefault(t["id"], t)
    return out


def rivals(game):
    """id соперника -> (сторона, настройки)."""
    return {rid: (side, cfg) for side in ("burgundy", "league")
            for rid, cfg in game.territory_data[side].get("rivals", {}).items()}


def actor_name(game, actor):
    if actor == "me":
        return game.state.side_name()
    if actor == "enemy":
        return game.state.side_name(game.state.enemy_side)
    return rivals(game).get(actor, (None, {"name": actor}))[1]["name"]


def _captured(state, tid, captor):
    """После смены владельца: срываем чужие операции; если пала столица соперника — он распадается."""
    game = state.game
    ops = state.vars.setdefault("ai_ops", {})
    for actor, op in list(ops.items()):
        if op["t"] == tid and actor != captor:
            del ops[actor]
    if tid in rivals(game) and captor != tid:
        ops.pop(tid, None)
        lands = [x for x in all_defs(game) if x != tid and holder(state, x) == tid]
        state.log_msg(tr("Соперник «{0}» разгромлен: его земли ({1}) отходят к «{2}».").format(actor_name(game, tid), len(lands), actor_name(game, captor)))
        for x in lands:
            _give(state, x, captor)


def _give(state, tid, captor):
    if captor == "me":
        set_status(state, {}, tid, "annexed")
    else:
        _set_holder(state, tid, captor)
        _captured(state, tid, captor)


def _ai_targets(game, actor, side):
    st = game.state
    busy = {op["t"] for a, op in st.vars.get("ai_ops", {}).items() if a != actor}
    taken = sum(1 for x in all_defs(game) if holder(st, x) == actor)
    out = []
    rgroup = rivals(game).get(actor, (None, {}))[1].get("group")
    for t in game.territory_data[side]["territories"]:
        h = holder(st, t["id"])
        if h in (actor, "me") or t["id"] in busy:
            continue
        if t.get("after_final") and not after_final_open(st, side, actor):
            continue
        if actor != "enemy":
            if h is not None or t.get("final"):
                continue
            if rgroup and group_of(t) != rgroup:
                continue   # Италия берёт только Францию
            if not rgroup and t.get("foreign"):
                continue   # остальные соперники — только ничьи земли своей страны
        if t.get("final") and taken < t.get("requires_controlled", 0):
            continue
        if actor == "enemy" and group_wait(game, t, side) is not None:
            continue
        if shards_left(game, side, actor, t):
            continue
        if borders(game, actor, t["id"]):
            out.append(t)
    return sorted(out, key=lambda t: t["resistance"] * (1.5 if holder(st, t["id"]) else 1.0))


def shards_left(game, side, actor, t):
    """Сколько осколков ещё не взято, если цель открывается только после всех осколков ("requires_all_shards")."""
    if not t.get("requires_all_shards"):
        return 0
    st = game.state
    return sum(1 for x in game.territory_data[side]["territories"]
               if not (x.get("foreign") or x.get("final")) and holder(st, x["id"]) != actor)


def ai_daily(game):
    """Противник и соперники ведут свои захваты: выбирают соседнюю землю и постепенно её занимают."""
    st = game.state
    ops = st.vars.setdefault("ai_ops", {})
    enemy = st.enemy_side
    defs = all_defs(game)
    actors = []
    if ((enemy != "burgundy" or st.has_flag("german_civil_war")) and (enemy != "league" or st.day >= 30)
            and not st.war["active"]):
        actors.append(("enemy", enemy, 1 / 12 if after_final_open(st, enemy, "enemy") else 1 / 30))
    for rid, (side, cfg) in rivals(game).items():
        if not cfg.get("no_core") and holder(st, rid) != rid:
            continue
        if (cfg.get("after_flag") and not st.has_flag(cfg["after_flag"])) or st.day < cfg.get("after_day", 0):
            continue
        if sum(1 for x in defs if holder(st, x) == rid) <= RIVAL_MAX:
            actors.append((rid, side, cfg.get("chance", 1 / 80)))
    for actor, side, chance in actors:
        op = ops.get(actor)
        if op:
            t = defs[op["t"]]
            if holder(st, t["id"]) in (actor, "me"):
                del ops[actor]
                continue
            op["p"] = min(100.0, op["p"] + st.rng.uniform(2.0, 4.5) * 20 / max(10, t["resistance"]))
            if op["p"] >= 100:
                del ops[actor]
                _ai_capture(game, actor, side, t)
            continue
        if st.rng.random() < chance:
            targets = _ai_targets(game, actor, side)
            if targets:
                t = st.rng.choice(targets[:3])
                ops[actor] = {"t": t["id"], "p": 0.0}


def _ai_capture(game, actor, side, t):
    st = game.state
    _set_holder(st, t["id"], actor)
    _captured(st, t["id"], actor)
    if actor == "enemy":
        st.add("enemy_army", 1.8)
        st.log_msg(tr("Разведка: «{0}» под контролем противника ({1}).").format(t['name'], st.side_name(side)))
        if t.get("final"):
            _give_after_final(game, side, "enemy")
            st.set_flag("enemy_endgame")
            st.add("enemy_army", 8)
            st.add("tension", 8)
            st.log_msg(tr("Разведка: ") + st.scenario["sides"][side]["milestone"])
    elif rivals(game).get(actor, (None, {}))[1].get("puppet"):
        st.log_msg(tr("{0} поставила в области «{1}» марионеточное правительство.").format(actor_name(game, actor), t['name']))
    else:
        st.log_msg(tr("Соперник «{0}» занял «{1}».").format(actor_name(game, actor), t['name']))


def group_of(t):
    """Группа целей: "main" (Германия, рейхскомиссариаты, Россия) или отдельная вкладка ("france")."""
    return t.get("group", "main")


def uses_ss(state, t):
    """Германию и рейхскомиссариаты Бургундия берёт войсками СС, Францию — обычной армией."""
    return state.side == "burgundy" and group_of(t) == "main"


def ss_divisions(state):
    """Дивизии СС Бургундии: (всего, заняты в операциях)."""
    total = state.vars.get("ss_divisions", 2)
    busy = sum(1 for t in state.territories.values()
               if t.get("op") and t["op"]["type"] == "military" and uses_ss(state, t))
    return total, busy


def ops_running(state):
    """Операции, которые тянут обычная армия и аппарат (штурмы СС держат свои дивизии)."""
    return sum(1 for t in state.territories.values()
               if t.get("op") and not (t["op"]["type"] == "military" and uses_ss(state, t)))


def army_ops(state):
    return sum(1 for t in state.territories.values()
               if t.get("op") and t["op"]["type"] == "military" and not uses_ss(state, t))


def ops_limit(state):
    """Сколько операций держит страна разом: 2, и ещё одна на каждые 6 взятых земель (не больше 4)."""
    return min(4, 2 + len(controlled(state)) // 6)


def controlled(state):
    return [t for t in state.territories.values() if t["status"] in CONTROLLED]


def eff_resistance(state, t):
    r = t["resistance"] * t.get("resist_mult", 1.0) * state.mod("resistance")
    if state.has_flag("path_wait") and state.flag_age("path_wait") >= 30:
        r *= 0.75
    if t.get("status") == "rival":
        r *= 1.3
    return r


# ---------- функции для ивентов ----------
@registry.predicate("expansion.can_destroy")
def can_destroy(state, ctx, tid):
    t = state.territories[tid]
    return army.strength(state) >= 1.8 * eff_resistance(state, t)


@registry.predicate("expansion.controlled_gte")
def controlled_gte(state, ctx, n):
    return len(controlled(state)) >= n


@registry.action("expansion.set_status")
def set_status(state, ctx, tid, status):
    t = state.territories[tid]
    if t["status"] == "annexed" and status in ("allied", "puppet"):
        return   # уже аннексированное не понижаем до союзника/марионетки (L03 после взятия Вятки)
    was = holder(state, tid)
    t["status"] = status
    t["op"] = None
    if status in CONTROLLED:
        t["progress"] = 100.0
        t["taken_day"] = state.day
        if tid in state.ai_territories:
            state.ai_territories[tid] = "player"
        state.log_msg(f"{t['name']}: {STATUS[status]}.")
        if was != "me":
            _captured(state, tid, "me")
        if t.get("capture_event") and not t.get("capture_event_done"):
            t["capture_event_done"] = True
            _engine(state).fire(t["capture_event"], {"target": tid, "target_name": t["name"]})
        _check_final(state, ctx)


@registry.action("expansion.start_op")
def start_op(state, ctx, tid, kind, mult=1.0):
    t = state.territories[tid]
    t["op"] = {"type": kind, "mult": mult, "days": 0}
    t["progress"] = t.get("progress", 0.0)
    name = tr("операция войск СС") if kind == "military" and uses_ss(state, t) else OP_NAMES[kind]
    state.log_msg(tr("{0}: начата {1}.").format(t['name'], name))
    if kind == "military" and t.get("on_military_event") and not t.get("military_event_done"):
        t["military_event_done"] = True
        _engine(state).schedule(t["on_military_event"], state.day + state.rng.randint(2, 4),
                                {"target": tid, "target_name": t["name"]})


@registry.action("expansion.op_mult")
def op_mult(state, ctx, tid, mult):
    t = state.territories[tid]
    if t.get("op"):
        t["op"]["mult"] *= mult


@registry.action("expansion.resist_mult")
def resist_mult(state, ctx, which, mult):
    for t in state.territories.values():
        if which == "all" or which == t["id"] or (which == "shards" and t.get("shard")):
            t["resist_mult"] = t.get("resist_mult", 1.0) * mult


@registry.action("expansion.add_progress")
def add_progress(state, ctx, tid, amount):
    t = state.territories[tid]
    t["progress"] = min(100.0, t.get("progress", 0) + amount)


def _engine(state):
    # Движок ивентов привязывается к состоянию в game.py (не сохраняется в JSON)
    return state.engine


def after_final_open(st, side, actor):
    """Рейхскомиссариаты "после Берлина" открыты тому, кто взял столицу."""
    return st.vars.get("final_by", {}).get(side) == actor


def _give_after_final(game, side, captor):
    """Падение столицы: ничьи рейхскомиссариаты ("after_final") готовы присягнуть победителю.
    Разом они больше не переходят — их занимают по одному и только по соседству, как любые земли."""
    st = game.state
    st.vars.setdefault("final_by", {})[side] = captor
    got = []
    for x in game.territory_data[side]["territories"]:
        if x.get("after_final") and holder(st, x["id"]) is None:
            got.append(x["name"])
            if x["id"] in st.territories:
                tt = st.territories[x["id"]]
                tt["resist_mult"] = tt.get("resist_mult", 1.0) * 0.6
    if got:
        st.log_msg(tr("Рейхскомиссариаты готовы присягнуть ({0}), но их ещё нужно занять по одному, начиная с соседних: ").format(actor_name(game, captor)) + ", ".join(got) + ".")


def _check_final(state, ctx):
    for t in state.territories.values():
        if t.get("final") and t["status"] in CONTROLLED and not t.get("final_done"):
            t["final_done"] = True
            _give_after_final(state.game, state.side, "me")
            _engine(state).fire(t["final_event"], {"target": t["id"], "target_name": t["name"]})


# ---------- ежедневный тик ----------
def daily(game):
    st = game.state
    d = army.doctrine(st)
    for t in st.territories.values():
        if t["status"] == "puppet":
            st.add("stability", -0.01)
        if t["status"] in ("annexed", "puppet"):
            st.add("treasury", 0.35)
        op = t.get("op")
        if not op:
            continue
        op["days"] += 1
        kind = op["type"]
        mult = op["mult"] * st.mod("expansion_speed")
        res = max(12.0, eff_resistance(st, t))
        hard = 24.0 / res   # мирные способы вязнут в крепких землях так же, как армия
        if kind == "military":
            # армия одна на все операции: обычные войска делятся между штурмами (СС — по дивизиям)
            n_mil = 1 if uses_ss(st, t) else max(1, army_ops(st))
            ratio = army.strength(st) / n_mil / max(1.0, eff_resistance(st, t))
            mult *= d.get("op_speed", 1.0) * st.mod("military_op_speed")
            if uses_ss(st, t):
                mult *= 0.9 + 0.05 * min(8, ss_divisions(st)[0])
            gain = 0.3 if ratio < 0.5 else min(5.0, 2.6 * ratio)
            st.add("treasury", -0.5)
            st.add("manpower", -0.06 * d.get("losses", 1.0))
            st.add("equipment", -0.04)
            if ratio < 0.5:
                st.add("morale", -0.1)
        elif kind == "diplomatic":
            rel = st.relations.get(game.side_cfg["expansion_faction"], 50)
            gain = 1.1 * (0.5 + rel / 100) * st.mod("diplo_speed") * hard
        elif kind == "bribe":
            gain = 2.0 * hard
        else:  # propaganda
            gain = 0.6 * (0.6 + st.get("ideology") / 100) * hard
            st.add("loyalty", 0.03)
        t["progress"] = min(100.0, t["progress"] + gain * mult)
        if t["progress"] >= 100:
            final = {"military": "annexed", "diplomatic": "annexed", "bribe": "annexed",
                     "propaganda": "annexed"}[kind]
            if kind == "propaganda":
                st.add("loyalty", 5)
            if kind == "military":
                st.add("prestige", 2)
            set_status(st, {}, t["id"], final)


# ---------- вкладка ----------
def _territory_actions(game, t):
    st = game.state
    cfg = game.expansion_cfg
    costs = cfg["action_costs"]
    tid = t["id"]
    acts = []
    if t["status"] in CONTROLLED:
        return acts
    if st.has_flag("path_wait") and st.flag_age("path_wait") < 30:
        return [Action(tr("Выжидать"), lambda: None, False, tr("выжидание ещё {0} дн.").format(30 - st.flag_age('path_wait')))]
    if t.get("final"):
        need = t.get("requires_controlled", 0)
        have = len([x for x in controlled(st) if not x.get("final") and group_of(x) == group_of(t)])
        if have < need:
            return [Action(tr("Штурм"), lambda: None, False, tr("нужно взять {0} территорий (сейчас {1})").format(need, have))]
    wait = group_wait(game, t)
    if wait is not None:
        why = (tr("откроется с началом гражданской войны в Германии") if wait < 0
               else tr("войска ещё развёртываются: {0} дн.").format(wait))
        return [Action(tr("Начать операцию"), lambda: None, False, why)]
    if t.get("after_final") and not after_final_open(st, st.side, "me"):
        return [Action(tr("Начать операцию"), lambda: None, False, tr("откроется после падения Берлина"))]
    left = shards_left(game, st.side, "me", t)
    if left:
        return [Action(tr("Начать операцию"), lambda: None, False, tr("сначала возьмите все осколки России (осталось {0})").format(left))]
    if t.get("op"):
        def cancel():
            t["op"] = None
            t["progress"] = 0.0   # брошенная операция пропадает: начинать придётся заново
            st.log_msg(tr("{0}: операция прекращена, достигнутое потеряно.").format(t['name']))
        return [Action(tr("Прекратить операцию"), cancel)]
    h = holder(st, tid)
    if h == "enemy":
        why = tr("берётся только наступлением на фронте") if st.war["active"] else tr("только война (вкладка «Война»)")
        return [Action(tr("Атаковать"), lambda: None, False, tr("земли удерживает {0} — {1}").format(actor_name(game, 'enemy'), why))]
    if not borders(game, "me", tid):
        return [Action(tr("Начать операцию"), lambda: None, False, tr("нет общей границы с нашими землями"))]

    # Первое обращение — сюжетный ивент вместо обычного меню
    if h is None and t.get("on_action_event") and not t.get("action_event_done"):
        def ev():
            t["action_event_done"] = True
            game.engine.fire(t["on_action_event"], {"target": tid, "target_name": t["name"]})
        label = t.get("on_action_label", tr("Вступить в контакт"))
        return [Action(label, ev)]

    allowed = t.get("actions", cfg["actions"])
    if h is not None:   # земли соперника — только сила (и подкуп его офицеров)
        allowed = [k for k in allowed if k in ("military", "spy", "bribe")] or ["military"]
    capital = t.get("final") or (tid in rivals(game) and h == tid)
    if capital:   # столицы не продаются и не сдаются на переговорах — только штурм
        allowed = [k for k in allowed if k in ("military", "spy")] or ["military"]
    res = eff_resistance(st, t)
    busy, limit = ops_running(st), ops_limit(st)
    full = busy >= limit
    full_why = tr("идёт {0} операций из {1} возможных").format(busy, limit)
    for kind in allowed:
        c = dict(costs.get(kind, {}))
        if kind == "military":
            ok = army.strength(st) >= res * 0.5
            why = tr("армия слишком слаба")
            label = tr("Военная операция")
            if uses_ss(st, t):
                total, busy = ss_divisions(st)
                label = tr("Ввести войска СС ({0}/{1} див.)").format(total - busy, total)
                if ok and busy >= total:
                    ok, why = False, tr("все дивизии СС заняты (Армия → сформировать дивизию)")
            if ok and full and not uses_ss(st, t):
                ok, why = False, full_why
            acts.append(costly(st, label, c, lambda: start_op(st, {}, tid, "military"), ok, why))
        elif kind == "diplomatic":
            ok = t["status"] != "contested" and not full
            acts.append(costly(st, tr("Переговоры о присоединении"), c,
                               lambda: start_op(st, {}, tid, "diplomatic"),
                               ok, tr("территория спорная — только сила") if t["status"] == "contested" else full_why))
        elif kind == "bribe":
            c["treasury"] = c.get("treasury", 0) + round(2.5 * res)   # чем крепче власть, тем дороже элиты
            acts.append(costly(st, tr("Подкуп элит"), c, lambda: start_op(st, {}, tid, "bribe"), not full, full_why))
        elif kind == "propaganda":
            def prop():
                st.add("ideology", 1)
                start_op(st, {}, tid, "propaganda")
            acts.append(costly(st, tr("Пропаганда"), c, prop, not full, full_why))
        elif kind == "spy":
            def spy():
                t["spied"] = True
                t["resist_mult"] = t.get("resist_mult", 1.0) * 0.85
                st.add("intel", 3)
                st.log_msg(tr("{0}: агентура вскрыла систему обороны (-15% сопротивления).").format(t['name']))
            acts.append(costly(st, tr("Шпионаж"), c, spy, not t.get("spied"), tr("сеть уже работает")))
    if t.get("no_talks"):
        acts.append(Action(tr("Переговоры"), lambda: None, False, t["no_talks"]))
    return acts


def group_wait(game, t, side=None):
    """Сколько дней ещё ждать, пока группа целей откроется стороне; -1 — не началась, None — открыта."""
    g = game.territory_data[side or game.state.side].get("groups", {}).get(group_of(t))
    if not g or not g.get("open_flag"):
        return None
    st = game.state
    if not st.has_flag(g["open_flag"]):
        return -1
    left = g.get("open_delay", 0) - st.flag_age(g["open_flag"])
    return left if left > 0 else None


def view(game, group="main"):
    st = game.state
    cfg = dict(game.expansion_cfg)
    cfg.update(cfg.get("groups", {}).get(group, {}))
    terrs = [t for t in st.territories.values() if group_of(t) == group]
    # рейхскомиссариаты «после Берлина» в счёт не идут: брать их самому нельзя
    ctrl = [t for t in controlled(st) if group_of(t) == group and not t.get("after_final")]
    total = len([t for t in terrs if not t.get("after_final")])
    header = [
        (tr("{0}   Взято: {1}/{2}   Операции: {3}/{4}   Мощь: {5:.1f}   Лояльность: {6:.0f}").format(cfg['subtitle'], len(ctrl), total, ops_running(st), ops_limit(st), army.strength(st), st.get('loyalty')), "bright"),
        ("", "normal"),
    ]
    if group == "france":
        header.insert(1, (tr("Францию берёт обычная армия, без СС; она делится между штурмами. Только соседние земли."),
                          "normal"))
        if terrs and group_wait(game, terrs[0]) is not None:
            header.insert(2, (tr("Поход откроется с началом гражданской войны в Германии. Италия тоже не будет ждать."),
                              "dim"))
    elif st.side == "burgundy":
        total, busy = ss_divisions(st)
        header.insert(1, (tr("Дивизии СС: {0} (в операциях {1}). Брать можно только соседние с нами земли.").format(total, busy),
                          "normal"))
        wait = group_wait(game, terrs[0]) if terrs else None
        if wait is not None and wait >= 0:
            header.insert(2, (tr("Дивизии СС войдут в Германию через {0} дн. — пока идёт поход во Францию.").format(wait), "dim"))
    else:
        header.insert(1, (tr("Только соседние земли; армия делится между штурмами, столицы берут только силой."), "normal"))
    ai_ops = st.vars.get("ai_ops", {})
    items = []
    for i, t in enumerate(terrs, 1):
        h = holder(st, t["id"])
        status = STATUS[t["status"]]
        if t.get("op"):
            short = tr("СС") if t["op"]["type"] == "military" and uses_ss(st, t) else OP_SHORT[t["op"]["type"]]
            status = f"{short} {t['progress']:.0f}%"
        elif h not in (None, "me", "enemy"):
            status = rivals(game).get(h, (None, {}))[1].get("short", status)
        elif h is None and group_wait(game, t) is not None:
            wait = group_wait(game, t)
            status = tr("после смуты") if wait < 0 else tr("через {0} дн.").format(wait)
        elif h is None and t.get("after_final") and not after_final_open(st, st.side, "me"):
            status = tr("после Берлина")
        elif h is None and shards_left(game, st.side, "me", t):
            status = tr("после осколков")
        elif h is None and not borders(game, "me", t["id"]):
            status = tr("нет границы")
        style = "dim" if t["status"] in CONTROLLED else "normal"
        name = t["name"] if len(t["name"]) <= 24 else t["name"][:23] + "…"
        text = f"{i:>2}. {name:<24} {status}"
        res = eff_resistance(st, t)
        details = [t.get("desc", ""),
                   tr("Сопротивление: {0:.1f}   Прогресс: {1} {2:.0f}%").format(res, bar(t['progress'], 20), t['progress'])]
        if t.get("shard"):
            details.append(tr("Осколок с собственным правительством: ведёт переговоры о капитуляции."))
        if h not in (None, "me", "enemy"):
            details.append(tr("Удерживает: {0}. Только сила (+30% сопротивления).").format(actor_name(game, h)))
            if h == t["id"]:
                details.append(tr("Столица соперника: её падение отдаст нам все его земли."))
        for actor, op in ai_ops.items():
            if op["t"] == t["id"]:
                details.append(tr("Сюда наступает {0}: {1:.0f}%.").format(actor_name(game, actor), op['p']))
        items.append(Item(text, _territory_actions(game, t), details, style))
    tv = TabView(cfg["title"], header, items)
    tv.map = {"kind": "theater", "bounds": cfg["map_bounds"], "group": group}
    return tv
