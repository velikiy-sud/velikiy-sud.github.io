"""Ядерная программа: исследования, добыча, объекты, боезапас, носители, риски."""
from .. import registry
from .common import Action, Item, TabView, bar, costly
from ..i18n import tr

DOCTRINE_NAMES = {"retaliation": tr("Только ответный удар"),
                  "preventive": tr("Превентивный удар при угрозе"),
                  "unlimited": tr("Неограниченное применение")}


@registry.chance("nuclear.incident_chance")
def incident_chance(state, ctx):
    if not state.programs.get("nuke_research") and not state.programs.get("warhead_production"):
        return 0.0
    base = 0.002 + (0.010 if state.has_flag("nuke_forced") else 0.0)
    return base * (1.6 - state.get("nuke_safety") / 100)


@registry.predicate("nuclear.can_strike")
def can_strike(state, ctx):
    return state.get("warheads") > 0 and (state.get("bombers") + state.get("missiles")) > 0


@registry.action("nuclear.found")
def found_program(state, ctx):
    """Учредить ядерный проект (из вкладки или из ивента «Атомный вопрос»)."""
    if state.has_flag("nuke_program"):
        return
    state.set_flag("nuke_program")
    state.programs["nuke_research"] = True
    state.programs["mining"] = True
    state.add("nuke_materials", 3)
    state.log_msg(tr("Учреждён секретный ядерный проект. Рудники урана заработали."))
    state.engine.fire("EVENT_W01")


@registry.action("nuclear.start_production")
def start_production(state, ctx):
    state.programs["warhead_production"] = True
    state.programs["mining"] = True
    state.log_msg(tr("Сборка боеголовок запущена."))


def research_rate(state):
    rate = 0.3 * (1 + 0.3 * state.get("nuke_facilities")) * state.mod("nuke_speed")
    if state.get("nuke_materials") < 0.05:
        rate *= 0.25
    return rate


def daily(game):
    st = game.state
    if st.programs.get("mining"):
        st.add("nuke_materials", 0.3 + 0.05 * st.get("nuke_facilities"))
        st.add("treasury", -1.0)
    if st.programs.get("nuke_research") and not st.has_flag("nuke_tested"):
        st.add("nuke_research", research_rate(st))
        st.add("nuke_materials", -0.04)
        st.add("treasury", -2.2 if st.has_flag("nuke_forced") else -1.5)
        if st.get("nuke_research") >= 100 and "EVENT_W03" not in st.fired:
            st.set_flag("nuke_tested")
            st.programs["nuke_research"] = False
            game.engine.fire("EVENT_W03")
    if st.programs.get("warhead_production"):
        if st.get("nuke_materials") >= 0.2:
            st.add("nuke_materials", -0.2)
            st.add("treasury", -1.5)
            prog = st.vars.get("warhead_progress", 0) + 0.06 * (1 + 0.2 * st.get("nuke_facilities"))
            if prog >= 1:
                prog -= 1
                st.add("warheads", 1)
                st.log_msg(tr("Арсенал пополнен: боеголовок — {0:.0f}.").format(st.get('warheads')))
            st.vars["warhead_progress"] = prog
    # международная реакция медленно остывает
    st.add("world_reaction", -0.02)


def view(game):
    st = game.state
    tested = st.has_flag("nuke_tested")
    started = st.has_flag("nuke_program")
    doc = DOCTRINE_NAMES.get(st.vars.get("nuke_doctrine"), tr("— не определена —"))
    header = [
        (tr("ЯДЕРНЫЙ ПРОЕКТ: {0}").format(tr("ИСПЫТАН — ДЕРЖАВА В КЛУБЕ") if tested else (tr("ИДЁТ") if started else tr("НЕ НАЧАТ"))), "bright"),
        ("", "normal"),
        (tr("Исследования  {0} {1:5.1f}%").format(bar(st.get('nuke_research')), st.get('nuke_research'))
         + ("" if tested or not started else tr("   (+{0:.2f}/день)").format(research_rate(st))), "normal"),
        (tr("Материалы     {0:6.1f} ед.   Объекты: {1:.0f}/6").format(st.get('nuke_materials'), st.get('nuke_facilities')), "normal"),
        (tr("Безопасность  {0} {1:5.1f}").format(bar(st.get('nuke_safety')), st.get('nuke_safety'))
         + (tr("   РЕЖИМ ФОРСИРОВАНИЯ") if st.has_flag("nuke_forced") else ""), "normal"),
        (tr("Боезапас: {0:.0f} боеголовок   Бомбардировщики: {1:.0f}   Ракеты: {2:.0f}").format(st.get('warheads'), st.get('bombers'), st.get('missiles')), "bright" if tested else "dim"),
        (tr("Доктрина: {0}   Цели: {1}").format(doc, tr("промышленность") if st.vars.get('nuke_target') == 'industrial' else tr("военные объекты")),
         "normal" if tested else "dim"),
        (tr("Риск инцидента: {0:.2f}% в день   Мировое осуждение: {1:.0f}").format(incident_chance(st, {}) * 100, st.get('world_reaction')),
         "normal"),
        ("", "normal"),
    ]
    items = []
    if not started:
        items.append(Item(tr("☢ Учредить ядерный проект"),
                          [costly(st, tr("Выделить средства"), {"treasury": 60}, lambda: found_program(st, {}))],
                          [tr("Без бомбы в большой войне не выстоять: противник свою уже строит."),
                           tr("Первые вложения: учёные, лаборатории, урановые рудники."),
                           tr("Ежедневно программа съедает 1.5-2 казны, рудники — ещё 1.")]))
    elif not tested:
        on = st.programs.get("nuke_research")

        def toggle_r():
            st.programs["nuke_research"] = not st.programs.get("nuke_research")
        items.append(Item(tr("Исследования [{0}]").format(tr("ВКЛ") if on else tr("пауза")),
                          [Action(tr("Приостановить") if on else tr("Возобновить"), toggle_r)],
                          [tr("Скорость растёт с числом объектов. Без материалов — в 4 раза медленнее.")]))

    if started:
        on = st.programs.get("mining")

        def toggle_m():
            st.programs["mining"] = not st.programs.get("mining")
            st.log_msg(tr("Рудники урана работают.") if st.programs["mining"] else tr("Добыча урана остановлена."))
        items.append(Item(tr("Добыча урана [{0}]").format(tr("ВКЛ") if on else tr("выкл")), [Action(tr("Переключить"), toggle_m)],
                          [tr("Ежедневно: +0.3 материалов (+ от объектов), -1 казны.")]))

        n = st.get("nuke_facilities")
        cost = {"treasury": 70 + 30 * n}

        def build():
            st.add("nuke_facilities", 1)
            st.log_msg(tr("Введён в строй ядерный объект №{0:.0f}.").format(st.get('nuke_facilities')))
        items.append(Item(tr("Строительство объектов ({0:.0f}/6)").format(n),
                          [costly(st, tr("Строить реактор/завод"), cost, build, n < 6, tr("достигнут предел"))],
                          [tr("Каждый объект: +30% к скорости исследований и производства.")]))

        def safety():
            st.add("nuke_safety", 12)
            st.log_msg(tr("Введены новые меры радиационной безопасности."))
        items.append(Item(tr("Меры безопасности"), [costly(st, tr("Профинансировать"), {"treasury": 30}, safety)],
                          [tr("+12 безопасности: меньше аварий и утечек.")]))

    if tested:
        on = st.programs.get("warhead_production")

        def toggle_w():
            st.programs["warhead_production"] = not st.programs.get("warhead_production")
        items.append(Item(tr("Сборка боеголовок [{0}]").format(tr("ВКЛ") if on else tr("выкл")), [Action(tr("Переключить"), toggle_w)],
                          [tr("Расход: 0.2 материалов и 1.5 казны в день. ~1 боеголовка в 2 недели.")]))

        def bomber():
            st.add("bombers", 1)
            st.log_msg(tr("Сформирована эскадрилья стратегических бомбардировщиков."))
        items.append(Item(tr("Носители: авиация ({0:.0f})").format(st.get('bombers')),
                          [costly(st, tr("Сформировать эскадрилью"), {"treasury": 45}, bomber)],
                          [tr("Бомбардировщики дешевле, но их можно перехватить.")]))

        def missile():
            st.add("missiles", 1)
            st.add("tension", 2)
            st.log_msg(tr("На боевое дежурство встала баллистическая ракета."))
        items.append(Item(tr("Носители: ракеты ({0:.0f})").format(st.get('missiles')),
                          [costly(st, tr("Построить шахту"), {"treasury": 90}, missile,
                                  st.get("nuke_facilities") >= 3, tr("нужно 3 ядерных объекта"))],
                          [tr("Ракеты не перехватить. Каждая шахта нервирует противника (+2 напряжённости).")]))

        def target(kind):
            def fn():
                st.vars["nuke_target"] = kind
                st.log_msg(tr("План удара пересмотрен: ") + (tr("промышленные центры.") if kind == "industrial" else tr("военные объекты.")))
            return fn
        items.append(Item(tr("Планирование целей"),
                          [Action(tr("Цели: военные объекты"), target("military")),
                           Action(tr("Цели: промышленные центры"), target("industrial"))],
                          [tr("Заранее подготовленный план усиливает удар выбранного типа на 25%.")]))
    return TabView(tr("ЯДЕРНАЯ ПРОГРАММА"), header, items)
