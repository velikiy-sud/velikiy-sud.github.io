"""Модель мира: экономика, стабильность, распад Германии, противник, напряжённость."""
from .. import registry
from ..i18n import tr


def daily(game):
    st = game.state
    # Экономика
    income = 3.5 + st.get("stability") / 25 - (1 if st.get("world_reaction") > 50 else 0)
    # содержание армии: каждая тысяча штыков и каждая дивизия СС стоят денег
    upkeep = st.get("manpower") * 0.01 + (0.3 * st.vars.get("ss_divisions", 2) if st.side == "burgundy" else 0)
    st.add("treasury", income - upkeep)
    if st.get("treasury") < 0:   # долги: жалованье задерживают, люди ропщут
        st.add("stability", -0.06)
        st.add("morale", -0.05)
    st.add("stability", (50 - st.get("stability")) * 0.002)
    if st.get("loyalty") < 30:
        st.add("stability", -0.02)
    st.add("dip_points", 0.1 + 0.05 * st.get("prestige") / 50)
    st.add("prestige", -0.01 * st.get("world_reaction") / 50)

    # Лига: власть лидера держит порядок, слабый аппарат теряет деньги
    if "leader_power" in st.stats:
        st.add("stability", (st.get("leader_power") - 50) * 0.0004)
        if st.get("apparatus") < 40:
            st.add("treasury", -(40 - st.get("apparatus")) * 0.03)
        st.add("apparatus", (55 - st.get("apparatus")) * 0.001)

    # Германия гниёт изнутри до начала гражданской войны
    if not st.has_flag("german_civil_war"):
        st.add("germany_stability", -0.5)

    # Противник растёт сам по себе и получает рывок в середине партии
    if not st.war["active"]:
        grow = 0.065 + (0.02 if st.get("tension") > 50 else 0)   # 1.1: игрок богаче — противник тоже
    else:
        grow = 0.05   # мобилизация противника во время войны
    st.add("enemy_army", grow * st.get("enemy_economy", 100) / 100)
    st.add("enemy_nuke_research", 0.16 + (0.08 if st.has_flag("nuke_tested") else 0))
    if st.get("enemy_nuke_research") >= 100:
        if not st.has_flag("enemy_nuke_tested"):
            st.set_flag("enemy_nuke_tested")
            st.add("enemy_nukes", 1)
            st.add("tension", 5)
            st.log_msg(tr("Сейсмостанции зафиксировали ядерное испытание. Противник ({0}) получил бомбу.").format(st.side_name(st.enemy_side)))
            st.engine.fire("SUPEREVENT_W08")
        elif st.rng.random() < (0.09 if st.war["active"] else 0.04) and st.get("enemy_economy", 100) > 30:
            st.add("enemy_nukes", 1)

    # Напряжённость между Бургундией и Лигой: растёт медленно, без подпитки сама остывает
    if not st.war["active"]:
        drift = 0.008
        if st.get("warheads") > 0:
            drift += 0.012
        if st.has_flag("new_burgundian_empire") or st.has_flag("united_league") or st.has_flag("enemy_endgame"):
            drift += 0.03
        if st.has_flag("partition"):
            drift -= 0.06
        if st.get("tension") > 60:
            drift -= 0.015
        if st.has_flag("war_gate"):   # мир поделён: две державы неизбежно упираются друг в друга
            drift += 0.1
        st.add("tension", drift)
        st.add("escalation", -0.05)

    # «Ворота войны»: до этого момента большая война не начнётся сама
    if not st.has_flag("war_gate") and (
            st.day >= 540 or st.has_flag("new_burgundian_empire") or st.has_flag("united_league")
            or st.has_flag("enemy_endgame")):
        st.set_flag("war_gate")
        st.log_msg(tr("Генштабы обеих держав перешли от планов обороны к планам наступления. Большая война стала возможной."))

    # Противник тоже не ждёт вечно: на пике кризиса он может ударить сам
    if st.has_flag("war_gate") and not st.war["active"] and not st.ending and st.get("tension") >= 90:
        if not (st.has_flag("backed_down") and st.flag_age("backed_down") < 180) and st.rng.random() < 1 / 90:
            st.log_msg(tr("{0} не стал дожидаться ультиматумов и перешёл границу!").format(st.side_name(st.enemy_side)))
            st.add("morale", -5)
            registry.ACTIONS["war.start"](st, {}, -10)
