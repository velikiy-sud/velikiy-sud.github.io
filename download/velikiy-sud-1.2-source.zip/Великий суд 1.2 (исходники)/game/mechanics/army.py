"""Армия: набор, учения, снабжение, доктрины, производство вооружений."""
from .common import Action, Item, TabView, bar, costly
from ..i18n import tr

DOCTRINES = {
    "mobile": {"name": tr("Мобильная война"),
               "desc": tr("Танковые клинья и глубокие прорывы. +15% к силе, быстрее операции."),
               "mult": 1.15, "op_speed": 1.2},
    "firepower": {"name": tr("Превосходство огня"),
                  "desc": tr("Артиллерия решает всё. +10% к силе, меньше потерь живой силы."),
                  "mult": 1.10, "losses": 0.7},
    "mass": {"name": tr("Массовое наступление"),
             "desc": tr("Числом, а не умением. Живая сила важнее вооружения."),
             "mult": 1.0, "manpower_weight": 1.35},
}


def doctrine(state):
    return DOCTRINES.get(state.vars.get("army_doctrine"), {})


def strength(state):
    """Условная боевая мощь армии (сопоставима с state['enemy_army'])."""
    d = doctrine(state)
    base = state.get("manpower") / 2 * d.get("manpower_weight", 1.0)
    eq_w = 0.4 if d.get("manpower_weight") else 0.6
    eq = (1 - eq_w) + eq_w * state.get("equipment") / 100
    tr = 0.6 + 0.8 * state.get("training") / 100
    sup = 0.5 + 0.5 * state.get("supply") / 100
    mor = 0.7 + 0.6 * state.get("morale") / 100
    elite = 2.5 * state.vars.get("ss_divisions", 2) if state.side == "burgundy" else 0.0   # дивизии СС — отборные части
    return (base + elite) * eq * tr * sup * mor * d.get("mult", 1.0) * state.mod("army_strength")


def daily(game):
    st = game.state
    if st.programs.get("training"):
        st.add("training", 0.2)
        st.add("treasury", -0.6)
    else:
        st.add("training", -0.02)
    if st.programs.get("production"):
        st.add("equipment", 0.25)
        st.add("treasury", -1.2)
    # Подрастает новый призывной контингент
    st.add("manpower", 0.05)
    # Снабжение медленно деградирует без вложений
    st.add("supply", -0.02)
    # Боевой дух тянется к 50
    st.add("morale", (55 - st.get("morale")) * 0.003)


def _toggle(game, name, on_text, off_text):
    st = game.state

    def fn():
        st.programs[name] = not st.programs.get(name)
        st.log_msg(on_text if st.programs[name] else off_text)
    return fn


def view(game):
    st = game.state
    s = strength(game.state)
    d = doctrine(st)
    header = [
        (tr("БОЕВАЯ МОЩЬ: {0:6.1f}   (оценка противника: {1})").format(s, game.enemy_estimate()), "bright"),
        ("", "normal"),
        (tr("Живая сила   {0:6.0f} тыс.").format(st.get('manpower')), "normal"),
        (tr("Выучка       {0} {1:5.1f}").format(bar(st.get('training')), st.get('training')), "normal"),
        (tr("Снабжение    {0} {1:5.1f}").format(bar(st.get('supply')), st.get('supply')), "normal"),
        (tr("Вооружение   {0} {1:5.1f}").format(bar(st.get('equipment')), st.get('equipment')), "normal"),
        (tr("Боевой дух   {0} {1:5.1f}").format(bar(st.get('morale')), st.get('morale')), "normal"),
        (tr("Доктрина     {0}").format(d.get('name', tr("— не утверждена —"))), "normal"),
        ("", "normal"),
    ]
    items = []

    def recruit():
        st.add("manpower", 15)
        st.add("equipment", -4)
        st.add("stability", -1.5)
        st.vars["recruits"] = st.vars.get("recruits", 0) + 1
        st.log_msg(tr("Объявлен дополнительный призыв: +15 тыс. человек."))
    rcost = 25 + 5 * st.vars.get("recruits", 0)
    items.append(Item(tr("Призыв резервистов"), [costly(st, tr("Объявить призыв"), {"treasury": rcost}, recruit)],
                      [tr("+15 тыс. живой силы, но вооружения на всех не хватает"),
                       tr("(-4 вооружения) и общество недовольно (-1.5 стабильности)."),
                       tr("Каждый следующий призыв дороже.")]))

    if st.side == "burgundy":
        total = st.vars.get("ss_divisions", 2)
        busy = sum(1 for t in st.territories.values() if t.get("op") and t["op"]["type"] == "military")

        def ss():
            st.vars["ss_divisions"] = st.vars.get("ss_divisions", 2) + 1
            st.add("manpower", -5)
            st.add("equipment", -3)
            st.log_msg(tr("Сформирована новая дивизия СС (всего {0}).").format(st.vars['ss_divisions']))
        items.append(Item(tr("Дивизии СС: {0} (в операциях {1})").format(total, busy),
                          [costly(st, tr("Сформировать дивизию СС"), {"treasury": 45 + 10 * total}, ss)],
                          [tr("Земли Германии и рейхскомиссариаты берут только войска СС:"),
                           tr("одна операция занимает одну дивизию. Каждая дивизия ускоряет штурмы."),
                           tr("Дивизии СС усиливают армию и в большой войне."),
                           tr("-5 тыс. живой силы, -3 вооружения, содержание 0.3 казны в день.")]))

    on = st.programs.get("training")
    items.append(Item(tr("Программа учений [{0}]").format(tr("ВКЛ") if on else tr("выкл")),
                      [Action(tr("Выключить учения") if on else tr("Начать учения"),
                              _toggle(game, "training", tr("Начаты масштабные учения."), tr("Учения свёрнуты.")))],
                      [tr("Ежедневно: +0.2 выучки, -0.6 казны.")]))

    on = st.programs.get("production")
    items.append(Item(tr("Военные заводы [{0}]").format(tr("ВКЛ") if on else tr("выкл")),
                      [Action(tr("Остановить производство") if on else tr("Запустить производство"),
                              _toggle(game, "production", tr("Военные заводы переведены на трёхсменную работу."),
                                      tr("Военное производство сокращено.")))],
                      [tr("Ежедневно: +0.25 вооружения, -1.2 казны.")]))

    def depots():
        st.add("supply", 8)
        st.log_msg(tr("Построены новые склады и узловые станции: снабжение улучшено."))
    items.append(Item(tr("Склады и железные дороги"), [costly(st, tr("Строить склады"), {"treasury": 40}, depots)],
                      [tr("+8 снабжения разово. Без вложений снабжение медленно падает.")]))

    def propaganda():
        st.add("morale", 8)
        st.log_msg(tr("Фронтовые газеты и капелланы поднимают дух войск."))
    items.append(Item(tr("Агитация в войсках"), [costly(st, tr("Провести агитацию"), {"treasury": 15}, propaganda)],
                      [tr("+8 боевого духа.")]))

    cur = st.vars.get("army_doctrine")
    for key, dd in DOCTRINES.items():
        mark = "■" if cur == key else "□"
        cost = {"treasury": 50} if cur is None else {"treasury": 100}

        def pick(key=key, dd=dd):
            if st.vars.get("army_doctrine"):
                st.add("training", -10)
            st.vars["army_doctrine"] = key
            st.log_msg(tr("Генштаб утвердил доктрину: «{0}».").format(dd['name']))
        acts = [] if cur == key else [costly(st, tr("Утвердить доктрину"), cost, pick)]
        items.append(Item(tr("{0} Доктрина: {1}").format(mark, dd['name']), acts,
                          [dd["desc"], tr("Смена доктрины стоит 100 казны и -10 выучки.")]))
    return TabView(tr("АРМИЯ"), header, items)
