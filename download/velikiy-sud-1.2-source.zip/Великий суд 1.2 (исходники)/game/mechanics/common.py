"""Общие типы для вкладок механик: действия, строки списка, представление вкладки."""
from ..game_state import STAT_NAMES
from ..i18n import tr


class Action:
    """Кнопка действия. fn() вызывается при выполнении."""

    def __init__(self, label, fn, enabled=True, reason="", cost=None):
        self.label = label
        self.fn = fn
        self.enabled = enabled
        self.reason = reason
        self.cost = cost or {}

    def cost_text(self):
        return fmt_cost(self.cost)


class Item:
    """Выбираемая строка во вкладке; у выбранной строки показываются её действия."""

    def __init__(self, text, actions=None, details=None, style="normal"):
        self.text = text
        self.actions = actions or []
        self.details = details or []
        self.style = style


class TabView:
    def __init__(self, title, header=None, items=None, side_art=None):
        self.title = title
        self.header = header or []     # [(текст, стиль)]
        self.items = items or []
        self.side_art = side_art       # необязательный блок справа: [(текст, стиль)]


def fmt_cost(cost):
    parts = []
    for k, v in cost.items():
        parts.append(f"{STAT_NAMES.get(k, k)} -{v:g}")
    return ", ".join(parts)


def can_afford(state, cost):
    for k, v in cost.items():
        have = state.get(k)
        if k == "treasury":
            if have - v < 0:
                return False
        elif have < v:
            return False
    return True


def pay(state, cost):
    for k, v in cost.items():
        state.add(k, -v)


def costly(state, label, cost, fn, extra_ok=True, reason=""):
    """Действие с ценой: недоступно, если не хватает ресурсов."""
    ok = can_afford(state, cost) and extra_ok
    why = reason if not extra_ok else (tr("не хватает ресурсов") if not can_afford(state, cost) else "")

    def run():
        pay(state, cost)
        fn()
    return Action(label, run, ok, why, cost)


def bar(value, width=20, maximum=100):
    value = max(0, min(maximum, value))
    filled = int(round(width * value / maximum))
    return "█" * filled + "░" * (width - filled)
