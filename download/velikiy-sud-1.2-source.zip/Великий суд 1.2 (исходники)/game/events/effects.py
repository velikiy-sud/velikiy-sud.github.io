"""Язык эффектов вариантов выбора. Эффект — словарь с одним ключом, список — по порядку.

  {"stat": {"stability": 5, "treasury": -20}}  — изменить показатели
  {"set_stat": {"tension": 0}}
  {"relation": {"industrialists": 10}}        — отношения с фракциями
  {"flag": "имя" | [...]}, {"clear_flag": ...}
  {"var": {"имя": значение}}, {"var_add": {"имя": N}}
  {"modifier": {"nuke_speed": 1.8}}           — домножить модификатор механики
  {"schedule": {"event": "ID", "min": 2, "max": 5}}  — отложенный ивент
  {"fire": "ID"}                              — ивент немедленно (в очередь)
  {"unlock_tab": "absorption"}
  {"log": "текст"}
  {"call": "absorption.set_status", "args": ["$target", "puppet"]}
  {"if": условие, "then": [...], "else": [...]}
  {"random": 0.3, "then": [...], "else": [...]}
  {"ending": "pyrrhic"}                       — завершить партию
"""
from .. import registry
from . import conditions
from ..game_state import STAT_NAMES
from ..i18n import tr


def _resolve(arg, ctx):
    if isinstance(arg, str) and arg.startswith("$"):
        return ctx.get(arg[1:])
    return arg


def apply(effects, state, engine, ctx=None):
    ctx = ctx or {}
    if effects is None:
        return
    if isinstance(effects, dict):
        effects = [effects]
    for eff in effects:
        for key, val in eff.items():
            if key in ("then", "else", "args"):
                continue
            _apply_one(key, val, eff, state, engine, ctx)


def _apply_one(key, val, eff, state, engine, ctx):
    if key == "stat":
        for k, v in val.items():
            state.add(k, v)
    elif key == "set_stat":
        for k, v in val.items():
            state.set(k, v)
    elif key == "relation":
        for k, v in val.items():
            state.add_relation(k, v)
    elif key == "flag":
        for f in (val if isinstance(val, list) else [val]):
            state.set_flag(f)
    elif key == "clear_flag":
        for f in (val if isinstance(val, list) else [val]):
            state.clear_flag(f)
    elif key == "var":
        state.vars.update(val)
    elif key == "var_add":
        for k, v in val.items():
            state.vars[k] = state.vars.get(k, 0) + v
    elif key == "modifier":
        for k, v in val.items():
            state.mul_mod(k, v)
    elif key == "schedule":
        lo, hi = val.get("min", 1), val.get("max", val.get("min", 1))
        engine.schedule(val["event"], state.day + state.rng.randint(lo, hi), dict(ctx))
    elif key == "fire":
        engine.fire(val, dict(ctx))
    elif key == "unlock_tab":
        if val not in state.tabs:
            state.tabs.append(val)
            engine.on_tab_unlocked(val)
    elif key == "log":
        state.log_msg(val.format_map(_Safe(ctx)))
    elif key == "call":
        args = [_resolve(a, ctx) for a in eff.get("args", [])]
        registry.ACTIONS[val](state, ctx, *args)
    elif key == "if":
        branch = "then" if conditions.check(val, state, ctx) else "else"
        apply(eff.get(branch), state, engine, ctx)
    elif key == "random":
        branch = "then" if state.rng.random() < val else "else"
        apply(eff.get(branch), state, engine, ctx)
    elif key == "ending":
        state.ending = val
    else:
        raise ValueError(tr("Неизвестный эффект: {0}").format(key))


class _Safe(dict):
    def __missing__(self, key):
        return "{" + key + "}"


def describe(effects, depth=0):
    """Короткая подсказка по эффектам варианта (только прямые изменения показателей)."""
    parts = []
    if isinstance(effects, dict):
        effects = [effects]
    for eff in effects or []:
        if "stat" in eff:
            for k, v in eff["stat"].items():
                name = STAT_NAMES.get(k, k)
                parts.append(f"{name} {'+' if v > 0 else ''}{v:g}")
    return ", ".join(parts)
