"""Движок ивентов: загрузка JSON, проверка триггеров каждый день, очередь, выбор вариантов.

Формат ивента (см. data/events/*.json):
{
  "id": "EVENT_002",
  "title": "Первые донесения разведки",
  "text": "...",                   # поддерживает подстановки {target_name} из контекста
  "superevent": false,             # true — показ в нижнем окне с видео/звуком
  "media": "civil_war",            # id из data/media.json (для суперивентов)
  "side": "burgundy",              # необязательно: только для одной стороны
  "trigger": {...},                # условие (см. conditions.py); нет — только через fire/schedule
  "chance": 0.05 | {"func": ...},  # вероятность в день, когда условие выполнено
  "once": true,                    # по умолчанию true
  "cooldown": 60,                  # для повторяемых: минимум дней между срабатываниями
  "common_effects": [...],        # применяются при любом выборе
  "options": [{"text": "...", "condition": {...}, "effects": [...], "hint": "..."}]
}
"""
import glob
import json
import os

from .. import config, i18n, registry
from . import conditions, effects
from ..i18n import tr


class _Safe(dict):
    def __missing__(self, key):
        return "{" + key + "}"


class EventInstance:
    def __init__(self, data, context):
        self.data = data
        self.context = context or {}

    @property
    def id(self):
        return self.data["id"]

    @property
    def superevent(self):
        return bool(self.data.get("superevent"))

    @property
    def media(self):
        return self.data.get("media")

    def title(self):
        return self.data["title"].format_map(_Safe(self.context))

    def text(self):
        return self.data["text"].format_map(_Safe(self.context))

    def options(self, state):
        """[(индекс, текст, доступен, подсказка)]"""
        out = []
        for i, opt in enumerate(self.data.get("options", [{"text": tr("Продолжить")}])):
            if "visible" in opt and not conditions.check(opt["visible"], state, self.context):
                continue
            ok = conditions.check(opt.get("condition"), state, self.context)
            hint = opt.get("hint") or effects.describe(opt.get("effects"))
            out.append((i, opt["text"].format_map(_Safe(self.context)), ok, hint))
        return out


def load_events(directory=config.EVENTS_DIR):
    events = {}
    for path in sorted(glob.glob(os.path.join(directory, "*.json"))):
        with open(path, encoding="utf-8") as f:
            for ev in i18n.tr_data(json.load(f)):
                if ev["id"] in events:
                    raise ValueError(tr("Дубликат ивента {0} в {1}").format(ev['id'], path))
                events[ev["id"]] = ev
    return events


class EventEngine:
    def __init__(self, state, events=None):
        self.state = state
        self.events = events if events is not None else load_events()
        self.queue = []          # EventInstance, ожидающие решения игрока
        self.tab_hooks = []      # колбэки на открытие вкладки

    # ---------- запуск ----------
    def fire(self, event_id, context=None):
        data = self.events.get(event_id)
        if data is None:
            raise KeyError(tr("Нет ивента {0}").format(event_id))
        if data.get("side") and data["side"] != self.state.side:
            return
        self.state.fired[event_id] = self.state.day
        self.state.fire_count[event_id] = self.state.fire_count.get(event_id, 0) + 1
        inst = EventInstance(data, context)
        # суперивенты встают в начало очереди — они главнее
        if inst.superevent:
            self.queue.insert(0, inst)
        else:
            self.queue.append(inst)

    def schedule(self, event_id, day, context=None):
        self.state.scheduled.append({"day": day, "event": event_id, "context": context or {}})

    def on_tab_unlocked(self, tab):
        for hook in self.tab_hooks:
            hook(tab)

    # ---------- ежедневная проверка ----------
    def daily(self):
        st = self.state
        due = [s for s in st.scheduled if s["day"] <= st.day]
        st.scheduled = [s for s in st.scheduled if s["day"] > st.day]
        for s in due:
            self.fire(s["event"], s.get("context"))

        for ev in self.events.values():
            trig = ev.get("trigger")
            if trig is None:
                continue
            if ev.get("side") and ev["side"] != st.side:
                continue
            eid = ev["id"]
            if eid in st.fired:
                if ev.get("once", True):
                    continue
                if st.day - st.fired[eid] < ev.get("cooldown", 30):
                    continue
            if any(q.id == eid for q in self.queue):
                continue
            if not conditions.check(trig, st):
                continue
            ch = ev.get("chance", 1.0)
            if isinstance(ch, dict):
                ch = registry.CHANCES[ch["func"]](st, {})
            if ch < 1.0 and st.rng.random() >= ch:
                continue
            self.fire(eid)

    # ---------- решение игрока ----------
    def current(self):
        return self.queue[0] if self.queue else None

    def choose(self, option_index):
        inst = self.queue.pop(0)
        opt = inst.data.get("options", [{"text": tr("Продолжить")}])[option_index]
        st = self.state
        st.choices.setdefault(inst.id, []).append(option_index)
        st.history.append({"day": st.day, "date": st.date_str(), "id": inst.id,
                           "title": inst.title(),
                           "option": opt["text"].format_map(_Safe(inst.context))})
        st.log_msg(f"{inst.title()}: «{opt['text'].format_map(_Safe(inst.context))}»")
        effects.apply(inst.data.get("common_effects"), st, self, inst.context)
        effects.apply(opt.get("effects"), st, self, inst.context)
        return inst
