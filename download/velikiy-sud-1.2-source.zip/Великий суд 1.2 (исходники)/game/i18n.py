"""Язык игры: русский (исходные тексты) или английский (data/i18n/en.json).

Все тексты в коде и data/*.json написаны по-русски; tr() подменяет строку переводом из каталога.
Язык выбирается при запуске (saves/settings.json, по умолчанию — файл lang.txt рядом с игрой)
и меняется клавишей L на экране выбора стороны: игра перезапускается.
"""
import json
import os
import re
import subprocess
import sys

from . import config, settings

LANGS = {"ru": "Русский", "en": "English"}
CATALOG_PATH = os.path.join(config.DATA_DIR, "i18n", "en.json")
_CYR = re.compile("[А-Яа-яЁё]")


def _default_lang():
    try:
        with open(os.path.join(config.ROOT, "lang.txt"), encoding="utf-8") as f:
            v = f.read().strip().lower()
        return v if v in LANGS else "ru"
    except OSError:
        return "ru"


LANG = settings.get("lang") or _default_lang()
if LANG not in LANGS:
    LANG = "ru"

_catalog = {}
if LANG == "en":
    try:
        with open(CATALOG_PATH, encoding="utf-8") as f:
            _catalog = {k: v for k, v in json.load(f).items() if v}
    except (OSError, ValueError):
        _catalog = {}


def tr(text):
    """Перевод строки (русская строка — ключ). Нет перевода — остаётся русский текст."""
    return _catalog.get(text, text) if _catalog else text


def tr_data(obj):
    """Перевести все русские строки внутри данных из JSON (ключи и id не трогаются)."""
    if not _catalog:
        return obj
    if isinstance(obj, dict):
        return {k: tr_data(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [tr_data(v) for v in obj]
    if isinstance(obj, str) and _CYR.search(obj):
        return tr(obj)
    return obj


def other_lang():
    keys = list(LANGS)
    return keys[(keys.index(LANG) + 1) % len(keys)]


def switch_and_restart(app):
    """Сменить язык и перезапустить игру (тексты переводятся при запуске)."""
    settings.set("lang", other_lang())
    try:
        subprocess.Popen([sys.executable] + sys.argv, cwd=config.ROOT)
        app.running = False
        return True
    except Exception:
        return False
