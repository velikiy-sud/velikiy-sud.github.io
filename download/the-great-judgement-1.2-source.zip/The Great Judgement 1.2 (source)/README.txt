THE GREAT JUDGEMENT — version 1.2
An 80s-terminal-style strategy game inspired by the TNO mod for Hearts of Iron IV.

HOW TO RUN
1. Unpack the WHOLE archive (do not run it from inside the archive window).
2. Run «The Great Judgement.exe». You do not need to install Python.
3. If Windows says «Windows protected your PC»:
   «More info» → «Run anyway». The game has no paid digital signature.

LANGUAGE
The game starts in English. Press L on the side-selection screen to switch to Russian
(the game restarts); press L again to switch back.

CONTROLS
SPACE — pause, 1–5 and +/- — speed, F1–F8 or TAB — tabs,
arrows and ENTER — select and act, 1–4 in an event — option (press twice),
F5/F9 — save/load, F11 — full screen, M — sound, C — screen colour, ESC — menu.
The mouse works too. On the map: wheel — zoom, drag with the mouse.

TIPS
The final assaults (Berlin, the Kremlin) need a strong army: operations eat up men and equipment,
so replenish the army in the «Army» tab between conquests. The great war almost always
ends in a nuclear exchange — that is by design.

Saves are kept in the saves folder. If the game crashes, the reason will be in crash.log.

WHAT'S NEW IN 1.2
— The League's Great Judgement finale: «Bloody Judgement», the OFN and Japan side with Burgundy, nuclear strikes
  from Africa and from beyond the map, «Revenge on the Traitors» and the end of the world.
— After the collapse Europe's regions go dark one by one, leaving an empty map and TV static.
— An 8-bit «Arise, Great Country» plays during the Great Judgement superevent.
— A new «Reckoning with the Vlasovites»: tribunal animation, the choice affects the start of the Great Judgement.
— Burgundy in Russia: «Cleansing the Eastern Lands».

WHAT'S NEW IN 1.1
— English version of the whole game: events, interface, map, animations, epilogue.
— «The Great Judgement»: a new superevent for the League's war with Burgund; the Reichskommissariats
  and Göring's troops fight alongside the Order as one state. Lands change hands only along the front line.
— Reckoning with the Vlasovites after Samara falls; with Vlasov and the Reichskommissariats — war only.
— Nuclear weapons are more visible: «The Atomic Question» event, the flash of the enemy test, a blinking strike badge.
— Economy: higher income; exercises, factories and operations are cheaper; conquests are faster.

LINKS
Game's Telegram: https://t.me/tnolarp
Support the developer (Boosty): https://boosty.to/tnov
Website: https://velikiy-sud.github.io/en/

CREDITS
A non-commercial fan game. Not affiliated with the TNO Team or Paradox Interactive.
Map — Natural Earth (public domain), font DejaVu Sans Mono,
bundled Python 3.12 (PSF) and pygame 2.6.1 (LGPL 2.1, https://github.com/pygame/pygame).
